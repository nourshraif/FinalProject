"""
Skill Matcher Module

This module matches extracted CV skills with job requirements from scraped jobs.
Uses LLM to extract skills from job descriptions and calculate match scores.
"""

import os
from typing import List, Dict, Optional, Tuple
from dotenv import load_dotenv
from openai import OpenAI
from database import get_connection
import json
import re

load_dotenv()


class SkillMatcher:
    """
    Matches user CV skills with job requirements and provides match scores.
    """
    
    def __init__(self, model_name: Optional[str] = None):
        """
        Initialize the skill matcher.
        
        Args:
            model_name: Hugging Face model to use for skill extraction
        """
        self.model_name = model_name or os.getenv("HF_MODEL", "openai/gpt-oss-120b:groq")
        api_token = os.getenv("HF_TOKEN")
        
        if not api_token:
            raise ValueError("HF_TOKEN not found in environment variables.")
        
        self.client = OpenAI(
            base_url="https://router.huggingface.co/v1",
            api_key=api_token,
        )
        
        self.conn = get_connection()
        self.cur = self.conn.cursor()
    
    def extract_skills_from_job(self, job_description: str) -> List[str]:
        """
        Extract required skills from a job description using LLM.
        
        Args:
            job_description: The job description text
            
        Returns:
            List of extracted skills
        """
        prompt = f"""Extract the required technical skills, tools, and qualifications from this job description.
Return ONLY a Python list format: ['skill1', 'skill2', 'skill3']

Focus on:
- Programming languages
- Frameworks and libraries
- Tools and platforms
- Technical skills
- Certifications

Job Description:
{job_description[:2000]}"""  # Limit to avoid token limits
        
        try:
            completion = self.client.chat.completions.create(
                model=self.model_name,
                messages=[{"role": "user", "content": prompt}],
                max_tokens=500,
                temperature=0.2,
            )
            
            if completion.choices and len(completion.choices) > 0:
                response = completion.choices[0].message.content.strip()
                return self._parse_skills_list(response)
            return []
        
        except Exception as e:
            print(f"Error extracting job skills: {e}")
            return []
    
    def _parse_skills_list(self, response: str) -> List[str]:
        """Parse skills from LLM response."""
        # Try to find a Python list
        list_pattern = r'\[(.*?)\]'
        match = re.search(list_pattern, response, re.DOTALL)
        
        if match:
            list_content = match.group(1)
            skills = re.findall(r'["\']([^"\']+)["\']', list_content)
            return [skill.strip() for skill in skills if skill.strip()]
        
        # Fallback: split by lines and clean
        lines = response.split('\n')
        skills = []
        for line in lines:
            line = re.sub(r'^[-*•\d.\s]+', '', line.strip())
            if line and len(line) > 2:
                skills.append(line)
        
        return skills[:20]  # Limit to 20 skills
    
    def calculate_match_score(self, cv_skills: List[str], job_skills: List[str]) -> Dict:
        """
        Calculate match score between CV skills and job requirements.
        
        Args:
            cv_skills: List of skills from user's CV
            job_skills: List of required skills from job
            
        Returns:
            Dictionary with match details
        """
        cv_skills_lower = [s.lower().strip() for s in cv_skills]
        job_skills_lower = [s.lower().strip() for s in job_skills]
        
        # Find exact matches
        exact_matches = []
        for cv_skill in cv_skills:
            for job_skill in job_skills:
                if cv_skill.lower() == job_skill.lower():
                    exact_matches.append(cv_skill)
        
        # Find partial matches (one skill contains another)
        partial_matches = []
        for cv_skill in cv_skills:
            for job_skill in job_skills:
                cv_lower = cv_skill.lower()
                job_lower = job_skill.lower()
                if cv_lower != job_lower:
                    if cv_lower in job_lower or job_lower in cv_lower:
                        partial_matches.append((cv_skill, job_skill))
        
        # Calculate score
        total_required = len(job_skills)
        if total_required == 0:
            return {
                'score': 0,
                'percentage': 0,
                'exact_matches': [],
                'partial_matches': [],
                'missing_skills': [],
                'total_required': 0
            }
        
        exact_count = len(exact_matches)
        partial_count = len(partial_matches)
        
        # Score: exact matches = 1 point, partial matches = 0.5 points
        score = exact_count + (partial_count * 0.5)
        percentage = (score / total_required) * 100
        
        # Find missing skills
        matched_job_skills = set([s.lower() for s in exact_matches])
        for cv_s, job_s in partial_matches:
            matched_job_skills.add(job_s.lower())
        
        missing_skills = [s for s in job_skills if s.lower() not in matched_job_skills]
        
        return {
            'score': round(score, 2),
            'percentage': round(percentage, 1),
            'exact_matches': list(set(exact_matches)),
            'partial_matches': partial_matches,
            'missing_skills': missing_skills,
            'total_required': total_required,
            'matched_count': exact_count + partial_count
        }
    
    def find_matching_jobs(self, cv_skills: List[str], 
                          min_match_percentage: float = 30,
                          limit: int = 50,
                          sources: Optional[List[str]] = None) -> List[Dict]:
        """
        Find jobs that match user's CV skills.
        
        Args:
            cv_skills: List of skills from user's CV
            min_match_percentage: Minimum match percentage to include job (default 30%)
            limit: Maximum number of jobs to return
            sources: Optional list of job sources to filter by
            
        Returns:
            List of matching jobs with match scores
        """
        # Build query
        query = """
            SELECT id, source, job_title, company, location, description, job_url, scraped_at
            FROM jobs
            WHERE is_active = TRUE
                AND description IS NOT NULL
                AND description != ''
        """
        
        params = []
        if sources:
            placeholders = ','.join(['%s'] * len(sources))
            query += f" AND source IN ({placeholders})"
            params.extend(sources)
        
        query += " ORDER BY scraped_at DESC LIMIT %s"
        params.append(limit * 2)  # Get more jobs initially for filtering
        
        self.cur.execute(query, params)
        jobs = self.cur.fetchall()
        
        matching_jobs = []
        
        print(f"\nAnalyzing {len(jobs)} jobs for skill matches...")
        print(f"Your skills: {', '.join(cv_skills[:10])}{'...' if len(cv_skills) > 10 else ''}")
        print("-" * 70)
        
        for i, (job_id, source, title, company, location, description, url, scraped_at) in enumerate(jobs):
            # Extract skills from job description
            job_skills = self.extract_skills_from_job(description)
            
            if not job_skills:
                continue
            
            # Calculate match
            match_result = self.calculate_match_score(cv_skills, job_skills)
            
            if match_result['percentage'] >= min_match_percentage:
                matching_jobs.append({
                    'job_id': job_id,
                    'source': source,
                    'title': title,
                    'company': company,
                    'location': location,
                    'url': url,
                    'scraped_at': scraped_at,
                    'required_skills': job_skills,
                    'match_score': match_result['score'],
                    'match_percentage': match_result['percentage'],
                    'exact_matches': match_result['exact_matches'],
                    'partial_matches': match_result['partial_matches'],
                    'missing_skills': match_result['missing_skills'],
                    'total_required': match_result['total_required']
                })
                
                print(f"✓ {title} at {company} - {match_result['percentage']:.1f}% match")
            
            # Progress indicator
            if (i + 1) % 10 == 0:
                print(f"  Processed {i + 1}/{len(jobs)} jobs...")
        
        # Sort by match percentage
        matching_jobs.sort(key=lambda x: x['match_percentage'], reverse=True)
        
        print(f"\nFound {len(matching_jobs)} matching jobs (>{min_match_percentage}% match)")
        print("-" * 70)
        
        return matching_jobs[:limit]
    
    def save_match_results(self, user_id: str, cv_skills: List[str], 
                          matching_jobs: List[Dict]) -> None:
        """
        Save match results to database for later reference.
        
        Args:
            user_id: Unique identifier for the user
            cv_skills: List of user's CV skills
            matching_jobs: List of matching jobs with scores
        """
        try:
            # Create matches table if it doesn't exist
            self.cur.execute("""
                CREATE TABLE IF NOT EXISTS job_matches (
                    id SERIAL PRIMARY KEY,
                    user_id VARCHAR(255) NOT NULL,
                    job_id INTEGER REFERENCES jobs(id),
                    match_percentage FLOAT NOT NULL,
                    match_score FLOAT NOT NULL,
                    exact_matches TEXT[],
                    missing_skills TEXT[],
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                );
            """)
            
            self.cur.execute("""
                CREATE INDEX IF NOT EXISTS idx_matches_user 
                ON job_matches(user_id);
            """)
            
            self.cur.execute("""
                CREATE INDEX IF NOT EXISTS idx_matches_score 
                ON job_matches(match_percentage DESC);
            """)
            
            # Save each match
            for job in matching_jobs:
                self.cur.execute("""
                    INSERT INTO job_matches 
                    (user_id, job_id, match_percentage, match_score, exact_matches, missing_skills)
                    VALUES (%s, %s, %s, %s, %s, %s)
                    ON CONFLICT DO NOTHING;
                """, (
                    user_id,
                    job['job_id'],
                    job['match_percentage'],
                    job['match_score'],
                    job['exact_matches'],
                    job['missing_skills']
                ))
            
            self.conn.commit()
            print(f"✓ Saved {len(matching_jobs)} job matches for user {user_id}")
        
        except Exception as e:
            print(f"Error saving match results: {e}")
            self.conn.rollback()
    
    def get_skill_gap_analysis(self, cv_skills: List[str], 
                               top_n_jobs: int = 20) -> Dict:
        """
        Analyze skill gaps based on top matching jobs.
        
        Args:
            cv_skills: List of user's CV skills
            top_n_jobs: Number of top jobs to analyze
            
        Returns:
            Dictionary with skill gap analysis
        """
        matching_jobs = self.find_matching_jobs(cv_skills, min_match_percentage=20, limit=top_n_jobs)
        
        # Collect all missing skills
        all_missing = []
        for job in matching_jobs:
            all_missing.extend(job['missing_skills'])
        
        # Count frequency of missing skills
        skill_frequency = {}
        for skill in all_missing:
            skill_lower = skill.lower()
            skill_frequency[skill_lower] = skill_frequency.get(skill_lower, 0) + 1
        
        # Sort by frequency
        top_missing = sorted(skill_frequency.items(), key=lambda x: x[1], reverse=True)
        
        return {
            'total_jobs_analyzed': len(matching_jobs),
            'your_current_skills': cv_skills,
            'top_missing_skills': [
                {'skill': skill, 'frequency': count, 'percentage': (count / len(matching_jobs)) * 100}
                for skill, count in top_missing[:15]
            ],
            'average_match_percentage': sum(j['match_percentage'] for j in matching_jobs) / len(matching_jobs) if matching_jobs else 0
        }
    
    def close(self):
        """Close database connection."""
        if self.cur:
            self.cur.close()
        if self.conn:
            self.conn.close()


def format_job_match(job: Dict) -> str:
    """Format a job match for display."""
    output = []
    output.append(f"\n{'='*70}")
    output.append(f"Job: {job['title']}")
    output.append(f"Company: {job['company']}")
    output.append(f"Location: {job['location']}")
    output.append(f"Source: {job['source']}")
    output.append(f"Match: {job['match_percentage']:.1f}% ({job['match_score']:.1f}/{job['total_required']} skills)")
    output.append(f"URL: {job['url']}")
    
    if job['exact_matches']:
        output.append(f"\n✓ Your Matching Skills ({len(job['exact_matches'])}):")
        for skill in job['exact_matches'][:10]:
            output.append(f"  • {skill}")
        if len(job['exact_matches']) > 10:
            output.append(f"  ... and {len(job['exact_matches']) - 10} more")
    
    if job['partial_matches']:
        output.append(f"\n≈ Partial Matches ({len(job['partial_matches'])}):")
        for cv_skill, job_skill in job['partial_matches'][:5]:
            output.append(f"  • You: {cv_skill} ≈ Required: {job_skill}")
    
    if job['missing_skills']:
        output.append(f"\n✗ Missing Skills ({len(job['missing_skills'])}):")
        for skill in job['missing_skills'][:8]:
            output.append(f"  • {skill}")
        if len(job['missing_skills']) > 8:
            output.append(f"  ... and {len(job['missing_skills']) - 8} more")
    
    output.append('='*70)
    return '\n'.join(output)


if __name__ == "__main__":
    # Example usage
    matcher = SkillMatcher()
    
    # Example CV skills
    example_skills = [
        "Python", "JavaScript", "React", "Node.js", "SQL",
        "Git", "Docker", "AWS", "REST APIs", "Machine Learning"
    ]
    
    print("="*70)
    print("SKILL MATCHER - Example Usage")
    print("="*70)
    
    # Find matching jobs
    matching_jobs = matcher.find_matching_jobs(
        cv_skills=example_skills,
        min_match_percentage=40,
        limit=10
    )
    
    # Display top 5 matches
    print("\n\nTOP MATCHING JOBS:\n")
    for job in matching_jobs[:5]:
        print(format_job_match(job))
    
    # Get skill gap analysis
    print("\n\nSKILL GAP ANALYSIS:\n")
    gap_analysis = matcher.get_skill_gap_analysis(example_skills, top_n_jobs=20)
    
    print(f"Analyzed {gap_analysis['total_jobs_analyzed']} jobs")
    print(f"Average match: {gap_analysis['average_match_percentage']:.1f}%")
    print(f"\nTop Skills to Learn:")
    for item in gap_analysis['top_missing_skills'][:10]:
        print(f"  • {item['skill'].title()}: appears in {item['percentage']:.0f}% of jobs")
    
    matcher.close()
