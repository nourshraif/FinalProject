# 🎯 AI-Powered CV Skill Matcher & Job Finder

A complete end-to-end system that:
1. **Extracts skills from your CV** using AI (Hugging Face LLMs)
2. **Scrapes jobs** from multiple remote job boards (LinkedIn, Upwork, We Work Remotely, etc.)
3. **Matches your skills** with job requirements using intelligent algorithms
4. **Provides recommendations** and skill gap analysis

---

## 🌟 Features

### 📄 CV Processing
- Upload CV as PDF
- AI-powered skill extraction using state-of-the-art LLMs
- Support for multiple models (GPT, Mistral, Llama)

### 🔍 Job Scraping
- **Web scrapers** for 5+ job boards (no API keys needed)
- **API scrapers** for 4+ job platforms (optional, more reliable)
- Automated scraping with scheduling
- PostgreSQL database for job storage

### 🎯 Intelligent Matching
- AI extracts required skills from job descriptions
- Calculates match scores (exact + partial matches)
- Shows missing skills (skill gap analysis)
- Ranks jobs by match percentage

### 📊 Analytics
- Match score visualization
- Skill gap analysis
- Top skills to learn
- Company statistics

---

## 🚀 Quick Start

### Prerequisites

```bash
# Python 3.8+
python --version

# PostgreSQL 12+
psql --version
```

### Installation

1. **Clone or download this project**

2. **Install Python dependencies**:
```bash
pip install -r requirements_integrated.txt
```

3. **Set up PostgreSQL database**:
```bash
# Create database
createdb jobs_db

# Or using psql
psql -U postgres
CREATE DATABASE jobs_db;
\q
```

4. **Configure database connection**:
Edit `database.py` with your credentials:
```python
def get_connection():
    return psycopg2.connect(
        host="localhost",
        database="jobs_db",
        user="your_username",
        password="your_password",
        port="5432"
    )
```

5. **Set up database tables**:
```bash
python setup_database.py
```

6. **Configure API tokens**:
Create `.env` file:
```env
# Required: Hugging Face Token
HF_TOKEN=your_huggingface_token_here

# Optional: Default model
HF_MODEL=openai/gpt-oss-120b:groq

# Optional: Job API keys (for enhanced scraping)
ADZUNA_APP_ID=your_adzuna_id
ADZUNA_APP_KEY=your_adzuna_key
REED_API_KEY=your_reed_key
```

Get your Hugging Face token: https://huggingface.co/settings/tokens

---

## 📖 Usage Guide

### Step 1: Scrape Jobs

First, populate your database with jobs:

```bash
# Option A: Run all scrapers once
python run_scraper.py --mode all

# Option B: Web scrapers only (no API keys needed)
python run_scraper.py --mode web

# Option C: Schedule regular scraping (every 6 hours)
python run_scraper.py --mode schedule --interval 6
```

**Expected Results**: 200-500+ jobs per run

### Step 2: Run the Integrated App

```bash
streamlit run integrated_app.py
```

This will open the complete skill matching system in your browser.

### Step 3: Use the App

1. **Upload your CV** (PDF format)
2. **Click "Extract Skills"** - AI analyzes your CV
3. **Click "Find Matching Jobs"** - System matches your skills with jobs
4. **View Results**:
   - See jobs ranked by match percentage
   - View exact skill matches
   - Identify skills to learn
   - Get personalized recommendations

---

## 🛠️ Advanced Usage

### Monitor Job Database

```bash
# View statistics
python monitor.py

# Search for specific jobs
python monitor.py --search "python developer"

# Interactive search mode
python monitor.py --search
```

### Run Original CV Extractor Only

```bash
streamlit run app.py
```

### Customize Scrapers

Add new job sources by editing `job_scraper.py` or `api_job_scraper.py`.

Example:
```python
def scrape_new_source(self):
    url = "https://newjobboard.com/remote"
    response = requests.get(url, headers=self.headers, timeout=10)
    soup = BeautifulSoup(response.text, "html.parser")
    
    # Your scraping logic
    for job in soup.find_all("div", class_="job"):
        title = job.find("h2").text
        company = job.find("span", class_="company").text
        link = job.find("a")["href"]
        
        self.save_job("newsource", title, company, "Remote", None, link)
```

---

## 📁 Project Structure

```
cv-skill-matcher/
│
├── Core CV Processing
│   ├── app.py                    # Original CV skill extractor
│   ├── main.py                   # Hugging Face API integration
│   ├── pdf_utils.py              # PDF text extraction
│
├── Job Scraping
│   ├── job_scraper.py            # Web scrapers (5+ sources)
│   ├── api_job_scraper.py        # API scrapers (4+ sources)
│   ├── comprehensive_scraper.py  # Combined scraper
│   ├── run_scraper.py            # Scraper runner with scheduling
│
├── Skill Matching
│   ├── skill_matcher.py          # Core matching algorithm
│   ├── integrated_app.py         # Complete Streamlit app
│
├── Database
│   ├── database.py               # PostgreSQL connection
│   ├── setup_database.py         # Table creation
│   ├── monitor.py                # Statistics & monitoring
│
├── Configuration
│   ├── .env                      # API tokens (create this)
│   ├── requirements.txt          # Original dependencies
│   └── requirements_integrated.txt # All dependencies
│
└── README.md                     # This file
```

---

## 🔧 Configuration Options

### Skill Matcher Settings

In `integrated_app.py`:

```python
min_match_percentage = 30  # Minimum match % to show jobs (0-100)
max_jobs = 20             # Maximum jobs to analyze
selected_model = "openai/gpt-oss-120b:groq"  # AI model for extraction
```

### Scraper Settings

In `run_scraper.py`:

```python
schedule_interval = 6  # Hours between scrapes
timeout = 10          # Request timeout in seconds
delay = 2             # Delay between sources (seconds)
```

---

## 📊 Database Schema

### Jobs Table
```sql
CREATE TABLE jobs (
    id SERIAL PRIMARY KEY,
    source VARCHAR(50) NOT NULL,
    job_title VARCHAR(255) NOT NULL,
    company VARCHAR(255) NOT NULL,
    location VARCHAR(255),
    description TEXT,
    job_url VARCHAR(500) UNIQUE NOT NULL,
    scraped_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    is_active BOOLEAN DEFAULT TRUE
);
```

### Job Matches Table (Auto-created)
```sql
CREATE TABLE job_matches (
    id SERIAL PRIMARY KEY,
    user_id VARCHAR(255) NOT NULL,
    job_id INTEGER REFERENCES jobs(id),
    match_percentage FLOAT NOT NULL,
    match_score FLOAT NOT NULL,
    exact_matches TEXT[],
    missing_skills TEXT[],
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

---

## 🎯 How the Matching Works

### 1. Skill Extraction
- **From CV**: AI model extracts skills from your resume text
- **From Jobs**: AI model extracts required skills from job descriptions

### 2. Matching Algorithm
```python
# Exact Match: 1 point
cv_skill = "Python"
job_skill = "Python"
→ Perfect match! +1.0 points

# Partial Match: 0.5 points
cv_skill = "React"
job_skill = "React.js"
→ Partial match! +0.5 points

# No Match: 0 points
cv_skill = "Java"
job_skill = "Python"
→ No match
```

### 3. Score Calculation
```
Match Percentage = (Total Points / Required Skills) × 100

Example:
- Job requires 10 skills
- You have 7 exact matches = 7 points
- You have 2 partial matches = 1 point
- Total = 8 points
- Match = (8 / 10) × 100 = 80%
```

---

## 🔍 Job Sources

### Web Scrapers (Free)
1. **WeWorkRemotely** - 6 category pages
2. **Remote OK** - Main board + API
3. **Remotive** - Curated listings
4. **FlexJobs** - Public listings
5. **Jobspresso** - Tech-focused

### API Scrapers (Some require keys)
6. **Remote OK API** - FREE, structured data
7. **Arbeitnow API** - FREE, European jobs
8. **Adzuna API** - Requires free key
9. **Reed.co.uk API** - Requires free key

---

## ⚡ Performance Tips

1. **First Run**: Initial scraping takes 1-2 minutes, gets 200-500 jobs
2. **Regular Scraping**: Run every 6-12 hours for fresh jobs
3. **Skill Matching**: Analyzing 50 jobs takes ~2-3 minutes (LLM processing)
4. **Database**: Add indexes for better performance (already included in setup)

---

## 🐛 Troubleshooting

### Issue: "HF_TOKEN not found"
**Solution**: Create `.env` file with your Hugging Face token

### Issue: "Database connection failed"
**Solution**: Check PostgreSQL is running and credentials in `database.py` are correct
```bash
# Start PostgreSQL
sudo service postgresql start  # Linux
brew services start postgresql # Mac
```

### Issue: "No jobs found"
**Solution**: Run scrapers first:
```bash
python run_scraper.py --mode web
```

### Issue: "AI extraction fails"
**Solution**: 
- Check your Hugging Face token is valid
- Try a different model
- Check internet connection

### Issue: "Slow matching"
**Solution**: 
- Reduce `max_jobs` parameter
- Use faster model like `gpt2`
- Limit jobs to specific sources

---

## 📈 Future Enhancements

Potential improvements:
- [ ] Add more job boards (Indeed, Glassdoor, etc.)
- [ ] Email notifications for new matching jobs
- [ ] Resume/CV builder integration
- [ ] Application tracking system
- [ ] Skill learning path recommendations
- [ ] Salary information integration
- [ ] Export matches to PDF/Excel
- [ ] User authentication and profiles

---

## 🤝 Contributing

To add new features:

1. **New Job Source**: Edit `job_scraper.py` or `api_job_scraper.py`
2. **Matching Algorithm**: Edit `skill_matcher.py`
3. **UI Enhancements**: Edit `integrated_app.py`

---

## 📄 License

This project is for educational and personal use. Please respect:
- Terms of service of job boards you scrape
- Rate limiting and robots.txt
- API usage limits

---

## 🆘 Support

For issues or questions:
1. Check the troubleshooting section
2. Review the job scraper README
3. Check Hugging Face documentation: https://huggingface.co/docs

---

## 🎉 Credits

Built with:
- **Streamlit** - UI framework
- **Hugging Face** - AI models
- **PostgreSQL** - Database
- **BeautifulSoup** - Web scraping
- **OpenAI SDK** - API integration

---

**Happy Job Hunting! 🎯**

*Built to help you find your perfect remote job match*
