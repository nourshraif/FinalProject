"""
Vector-Based CV Skill Matcher - Streamlit App

Uses semantic vector embeddings for intelligent job matching.
Much better than keyword matching - understands context and meaning!
"""

import streamlit as st
from pdf_utils import extract_text_from_pdf
from main import call_huggingface_api, parse_skills_from_response
from vector_skill_matcher import VectorSkillMatcher, format_vector_match
import pandas as pd
from datetime import datetime
import time

# Page configuration
st.set_page_config(
    page_title="AI Job Matcher (Vector Embeddings)",
    page_icon="🧠",
    layout="wide"
)

# Custom CSS
st.markdown("""
<style>
    .similarity-high {
        background-color: #4caf50;
        color: white;
        padding: 0.25rem 0.75rem;
        border-radius: 1rem;
        font-weight: bold;
    }
    .similarity-medium {
        background-color: #ff9800;
        color: white;
        padding: 0.25rem 0.75rem;
        border-radius: 1rem;
        font-weight: bold;
    }
    .similarity-low {
        background-color: #f44336;
        color: white;
        padding: 0.25rem 0.75rem;
        border-radius: 1rem;
        font-weight: bold;
    }
    .skill-tag {
        display: inline-block;
        padding: 0.25rem 0.5rem;
        margin: 0.25rem;
        border-radius: 0.25rem;
        background-color: #e3f2fd;
        color: #1976d2;
        font-size: 0.875rem;
    }
    .vector-badge {
        background-color: #9c27b0;
        color: white;
        padding: 0.25rem 0.5rem;
        border-radius: 0.25rem;
        font-size: 0.75rem;
        font-weight: bold;
    }
</style>
""", unsafe_allow_html=True)

# Title
st.title("🧠 AI Job Matcher with Vector Embeddings")
st.markdown("""
Advanced semantic matching using AI - understands context, not just keywords!
<span class="vector-badge">SEMANTIC MATCHING</span>
""", unsafe_allow_html=True)

# Sidebar
with st.sidebar:
    st.header("🧠 How Vector Matching Works")
    st.markdown("""
    **Traditional matching**: Looks for exact keywords
    - "React" only matches "React"
    
    **Vector matching**: Understands meaning
    - "React" matches "Frontend framework", "UI development", "JavaScript library"
    
    ✨ **Much more intelligent matching!**
    """)
    
    st.markdown("---")
    st.header("⚙️ Settings")
    
    # Model selection
    available_models = [
        "openai/gpt-oss-120b:groq",
        "meta-llama/Llama-3.1-8B-Instruct",
        "mistralai/Mistral-7B-Instruct-v0.2",
    ]
    
    selected_model = st.selectbox(
        "🤖 CV Extraction Model",
        options=available_models,
        index=0
    )
    
    st.markdown("---")
    st.subheader("Matching Parameters")
    
    matching_mode = st.radio(
        "Matching Mode",
        options=["Hybrid (Recommended)", "Vector Only", "Keywords Only"],
        help="Hybrid combines vector similarity with keyword matching"
    )
    
    if matching_mode == "Hybrid (Recommended)":
        vector_weight = st.slider("Vector Weight", 0.0, 1.0, 0.7, 0.1)
        keyword_weight = 1.0 - vector_weight
        st.caption(f"Keyword Weight: {keyword_weight:.1f}")
    
    similarity_threshold = st.slider(
        "Minimum Similarity",
        min_value=0.0,
        max_value=1.0,
        value=0.3,
        step=0.05,
        help="Minimum cosine similarity score (0-1)"
    )
    
    max_jobs = st.slider(
        "Max Results",
        min_value=10,
        max_value=100,
        value=30,
        step=10
    )
    
    st.markdown("---")
    st.info("💡 **Note**: First run generates embeddings for all jobs (~2-3 minutes one-time)")

# Initialize session state
if 'cv_text' not in st.session_state:
    st.session_state.cv_text = None
if 'cv_skills' not in st.session_state:
    st.session_state.cv_skills = None
if 'matching_jobs' not in st.session_state:
    st.session_state.matching_jobs = None
if 'recommendations' not in st.session_state:
    st.session_state.recommendations = None
if 'embeddings_generated' not in st.session_state:
    st.session_state.embeddings_generated = False

# Main content
col1, col2 = st.columns([1, 1])

with col1:
    st.header("📄 Step 1: Upload CV")
    uploaded_file = st.file_uploader("Choose PDF file", type=['pdf'])
    
    if uploaded_file is not None:
        st.success(f"✅ {uploaded_file.name}")
        
        with st.spinner("Extracting text..."):
            cv_text = extract_text_from_pdf(uploaded_file)
            
            if cv_text:
                st.session_state.cv_text = cv_text
                st.success("✅ Text extracted!")
                
                with st.expander("View CV Text"):
                    st.text_area("", cv_text, height=150, disabled=True, label_visibility="collapsed")

with col2:
    st.header("🧠 Step 2: Extract Skills")
    
    if st.session_state.cv_text:
        if st.button("🚀 Extract Skills", type="primary", use_container_width=True):
            with st.spinner("AI analyzing CV..."):
                try:
                    api_response = call_huggingface_api(
                        cv_text=st.session_state.cv_text,
                        model_name=selected_model
                    )
                    
                    if api_response:
                        skills = parse_skills_from_response(api_response)
                        st.session_state.cv_skills = skills
                        st.success(f"✅ Extracted {len(skills)} skills!")
                        
                        skill_html = "".join([f'<span class="skill-tag">{s}</span>' for s in skills])
                        st.markdown(skill_html, unsafe_allow_html=True)
                    else:
                        st.error("❌ No response from AI")
                
                except Exception as e:
                    st.error(f"❌ {str(e)}")
                    if "402" in str(e):
                        st.info("Try manual entry below instead!")

# Manual entry
if not st.session_state.cv_skills:
    st.markdown("---")
    st.subheader("✍️ Or Enter Skills Manually")
    
    manual_skills = st.text_area(
        "One skill per line",
        placeholder="Python\nReact\nDocker\nAWS",
        height=100
    )
    
    if st.button("Use These Skills"):
        if manual_skills:
            skills = [s.strip() for s in manual_skills.split('\n') if s.strip()]
            st.session_state.cv_skills = skills
            st.success(f"✅ Added {len(skills)} skills!")
            st.rerun()

# Vector matching
st.markdown("---")
st.header("🎯 Step 3: Find Matching Jobs")

if st.session_state.cv_skills:
    
    # Generate embeddings button
    if not st.session_state.embeddings_generated:
        st.warning("⚠️ Embeddings need to be generated first (one-time setup)")
        
        if st.button("🔄 Generate Job Embeddings", type="primary"):
            with st.spinner("Generating embeddings for all jobs... This may take 2-3 minutes..."):
                try:
                    matcher = VectorSkillMatcher()
                    matcher.generate_job_embeddings()
                    matcher.close()
                    
                    st.session_state.embeddings_generated = True
                    st.success("✅ Embeddings generated! Now you can find matches.")
                    st.rerun()
                
                except Exception as e:
                    st.error(f"❌ Error: {str(e)}")
                    st.info("""
                    **Make sure you have:**
                    1. Installed pgvector: `pip install pgvector`
                    2. Enabled extension in PostgreSQL
                    3. sentence-transformers: `pip install sentence-transformers`
                    """)
    
    else:
        col_match1, col_match2 = st.columns([2, 1])
        
        with col_match1:
            if st.button("🔍 Find Semantic Matches", type="primary", use_container_width=True):
                with st.spinner(f"Finding semantic matches using {matching_mode}..."):
                    start_time = time.time()
                    
                    try:
                        matcher = VectorSkillMatcher()
                        
                        if matching_mode == "Hybrid (Recommended)":
                            matches = matcher.find_matching_jobs_hybrid(
                                cv_skills=st.session_state.cv_skills,
                                top_k=max_jobs,
                                vector_weight=vector_weight,
                                keyword_weight=keyword_weight
                            )
                        else:  # Vector Only
                            matches = matcher.find_similar_jobs(
                                cv_skills=st.session_state.cv_skills,
                                top_k=max_jobs,
                                similarity_threshold=similarity_threshold
                            )
                        
                        st.session_state.matching_jobs = matches
                        
                        # Get recommendations
                        recs = matcher.get_skill_recommendations(
                            cv_skills=st.session_state.cv_skills,
                            n_jobs=min(50, len(matches))
                        )
                        st.session_state.recommendations = recs
                        
                        matcher.close()
                        
                        elapsed = time.time() - start_time
                        st.success(f"✅ Found {len(matches)} matches in {elapsed:.1f}s!")
                    
                    except Exception as e:
                        st.error(f"❌ Error: {str(e)}")
        
        with col_match2:
            st.metric("Your Skills", len(st.session_state.cv_skills))
            if st.session_state.matching_jobs:
                st.metric("Matches Found", len(st.session_state.matching_jobs))

# Display results
if st.session_state.matching_jobs:
    st.markdown("---")
    
    tab1, tab2, tab3 = st.tabs(["🎯 Job Matches", "📊 Analytics", "💡 Recommendations"])
    
    with tab1:
        st.header("Semantic Job Matches")
        
        for i, job in enumerate(st.session_state.matching_jobs, 1):
            score = job.get('match_percentage', job.get('similarity_score', 0) * 100)
            
            if score >= 70:
                badge_class = "similarity-high"
            elif score >= 50:
                badge_class = "similarity-medium"
            else:
                badge_class = "similarity-low"
            
            with st.container():
                col_j1, col_j2 = st.columns([3, 1])
                
                with col_j1:
                    st.markdown(f"### {i}. {job['title']}")
                    st.markdown(f"**{job['company']}** • {job['location']}")
                
                with col_j2:
                    st.markdown(f'<div class="{badge_class}">{score:.1f}%</div>', unsafe_allow_html=True)
                    
                    if 'vector_similarity' in job:
                        st.caption(f"Vector: {job['vector_similarity']*100:.0f}%")
                        st.caption(f"Keywords: {job['keyword_score']*100:.0f}%")
                
                with st.expander("📋 Details"):
                    st.markdown(f"**Source:** {job['source']}")
                    st.markdown(f"**URL:** [{job['url']}]({job['url']})")
                    
                    if job.get('description'):
                        st.markdown("**Description Preview:**")
                        st.text(job['description'][:300] + "...")
                
                st.markdown("---")
    
    with tab2:
        st.header("Match Analytics")
        
        df = pd.DataFrame(st.session_state.matching_jobs)
        
        col_a1, col_a2, col_a3 = st.columns(3)
        
        with col_a1:
            avg_score = df['match_percentage'].mean() if 'match_percentage' in df else 0
            st.metric("Average Match", f"{avg_score:.1f}%")
        
        with col_a2:
            best_score = df['match_percentage'].max() if 'match_percentage' in df else 0
            st.metric("Best Match", f"{best_score:.1f}%")
        
        with col_a3:
            st.metric("Total Matches", len(df))
        
        # Visualizations
        st.subheader("Score Distribution")
        st.bar_chart(df.set_index('title')['match_percentage']if 'match_percentage' in df else df.set_index('title')['similarity_score'])
        
        st.subheader("Top Companies")
        company_counts = df['company'].value_counts().head(10)
        st.bar_chart(company_counts)
    
    with tab3:
        st.header("Skill Recommendations")
        
        if st.session_state.recommendations:
            recs = st.session_state.recommendations
            
            st.metric("Jobs Analyzed", recs['jobs_analyzed'])
            
            st.subheader("Top Skills to Learn")
            st.markdown("Based on semantic analysis of similar job postings")
            
            for rec in recs['recommendations'][:15]:
                col_r1, col_r2 = st.columns([3, 1])
                
                with col_r1:
                    st.markdown(f"**{rec['skill']}**")
                
                with col_r2:
                    st.progress(min(rec['percentage'] / 100, 1.0))
                    st.caption(f"{rec['percentage']:.0f}%")

elif st.session_state.cv_skills:
    st.info("👆 Generate embeddings first, then find matches!")

# Footer
st.markdown("---")
st.markdown(
    "<div style='text-align: center; color: gray;'>Powered by Sentence Transformers & pgvector<br>🧠 Semantic matching for intelligent job discovery</div>",
    unsafe_allow_html=True
)