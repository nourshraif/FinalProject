"""
Enhanced Streamlit App - CV Skill Extraction + Job Matching (FREE VERSION)

Complete workflow using FREE pattern matching - NO API COSTS for job matching!
1. Upload CV and extract skills (uses API once)
2. Find matching jobs from database (FREE - pattern matching)
3. Show match scores and recommendations
4. Provide skill gap analysis
"""

import streamlit as st
from pdf_utils import extract_text_from_pdf
from main import call_huggingface_api, parse_skills_from_response
from skill_matcher import SkillMatcherFree, format_job_match
import pandas as pd
from datetime import datetime

# Page configuration
st.set_page_config(
    page_title="CV Skill Matcher & Job Finder",
    page_icon="🎯",
    layout="wide"
)

# Custom CSS
st.markdown("""
<style>
    .job-card {
        padding: 1.5rem;
        border-radius: 0.5rem;
        border: 1px solid #e0e0e0;
        margin-bottom: 1rem;
        background-color: #f9f9f9;
    }
    .match-badge {
        display: inline-block;
        padding: 0.25rem 0.75rem;
        border-radius: 1rem;
        font-weight: bold;
        margin-right: 0.5rem;
    }
    .match-high {
        background-color: #4caf50;
        color: white;
    }
    .match-medium {
        background-color: #ff9800;
        color: white;
    }
    .match-low {
        background-color: #f44336;
        color: white;
    }
    .skill-tag {
        display: inline-block;
        padding: 0.25rem 0.5rem;
        margin: 0.25rem;
        border-radius: 0.25rem;
        background-color: #e3f2fd;
        color: #1976d2;
        font-size: 0.875rem;
    }
    .missing-skill {
        background-color: #ffebee;
        color: #c62828;
    }
    .free-badge {
        background-color: #4caf50;
        color: white;
        padding: 0.25rem 0.5rem;
        border-radius: 0.25rem;
        font-size: 0.75rem;
        font-weight: bold;
    }
</style>
""", unsafe_allow_html=True)

# Title
st.title("🎯 AI CV Skill Matcher & Job Finder")
st.markdown("""
Upload your CV, extract skills with AI, and find matching jobs - **100% FREE job matching!**
<span class="free-badge">NO API COSTS</span>
""", unsafe_allow_html=True)

# Sidebar
with st.sidebar:
    st.header("📋 How It Works")
    st.markdown("""
    **Step 1**: Upload your CV (PDF)
    
    **Step 2**: AI extracts your skills (one-time API call)
    
    **Step 3**: Match your skills with 559 jobs (FREE - pattern matching)
    
    **Step 4**: View results & recommendations
    
    ✨ **NEW**: Job matching is 100% FREE - no API costs!
    """)
    
    st.markdown("---")
    st.header("⚙️ Settings")
    
    # Model selection for CV extraction only
    available_models = [
        "openai/gpt-oss-120b:groq",
        "meta-llama/Llama-3.1-8B-Instruct",
        "mistralai/Mistral-7B-Instruct-v0.2",
    ]
    
    selected_model = st.selectbox(
        "🤖 AI Model (for CV extraction)",
        options=available_models,
        index=0,
        help="Model for extracting skills from your CV"
    )
    
    min_match = st.slider(
        "Minimum Match %",
        min_value=0,
        max_value=100,
        value=20,
        step=5,
        help="Only show jobs with at least this match percentage"
    )
    
    max_jobs = st.slider(
        "Max Jobs to Analyze",
        min_value=50,
        max_value=500,
        value=100,
        step=50,
        help="More jobs = better results but slower"
    )
    
    st.markdown("---")
    st.info("💡 **Tip**: Job matching uses FREE pattern matching - unlimited matches!")

# Initialize session state
if 'cv_text' not in st.session_state:
    st.session_state.cv_text = None
if 'cv_skills' not in st.session_state:
    st.session_state.cv_skills = None
if 'matching_jobs' not in st.session_state:
    st.session_state.matching_jobs = None
if 'skill_gap' not in st.session_state:
    st.session_state.skill_gap = None

# Main content area
col1, col2 = st.columns([1, 1])

with col1:
    st.header("📄 Step 1: Upload Your CV")
    uploaded_file = st.file_uploader(
        "Choose a PDF file",
        type=['pdf'],
        help="Select your CV in PDF format"
    )
    
    if uploaded_file is not None:
        st.success(f"✅ Uploaded: {uploaded_file.name}")
        
        # Extract text
        with st.spinner("Extracting text from PDF..."):
            cv_text = extract_text_from_pdf(uploaded_file)
            
            if cv_text:
                st.session_state.cv_text = cv_text
                st.success("✅ Text extracted!")
                
                with st.expander("📄 View CV Text"):
                    st.text_area("", cv_text, height=200, disabled=True, label_visibility="collapsed")
            else:
                st.error("❌ Failed to extract text from PDF")

with col2:
    st.header("🧠 Step 2: Extract Skills")
    
    if st.session_state.cv_text:
        if st.button("🚀 Extract Skills with AI", type="primary", use_container_width=True):
            with st.spinner(f"AI is analyzing your CV..."):
                try:
                    api_response = call_huggingface_api(
                        cv_text=st.session_state.cv_text,
                        model_name=selected_model
                    )
                    
                    if api_response:
                        skills = parse_skills_from_response(api_response)
                        st.session_state.cv_skills = skills
                        st.success(f"✅ Extracted {len(skills)} skills!")
                        
                        # Display skills
                        st.markdown("**Your Skills:**")
                        skill_html = "".join([f'<span class="skill-tag">{skill}</span>' for skill in skills])
                        st.markdown(skill_html, unsafe_allow_html=True)
                    else:
                        st.error("❌ No response from AI")
                
                except Exception as e:
                    error_msg = str(e)
                    st.error(f"❌ Error: {error_msg}")
                    
                    if "402" in error_msg or "credit" in error_msg.lower():
                        st.warning("⚠️ **Out of Hugging Face credits?**")
                        st.info("""
                        **Solution**: Manually enter your skills below instead!
                        
                        Or use a free alternative:
                        - Try a different model
                        - Get more HF credits
                        - Use local extraction
                        """)
    else:
        st.info("👆 Please upload a CV first")

# Manual skill entry option
if not st.session_state.cv_skills:
    st.markdown("---")
    st.subheader("✍️ Or Enter Skills Manually")
    
    manual_skills = st.text_area(
        "Enter your skills (one per line or comma-separated)",
        placeholder="Python\nJavaScript\nReact\nNode.js\nDocker",
        height=100
    )
    
    if st.button("Use These Skills", use_container_width=True):
        if manual_skills:
            # Parse skills from text
            skills = []
            if '\n' in manual_skills:
                skills = [s.strip() for s in manual_skills.split('\n') if s.strip()]
            elif ',' in manual_skills:
                skills = [s.strip() for s in manual_skills.split(',') if s.strip()]
            else:
                skills = [manual_skills.strip()]
            
            st.session_state.cv_skills = skills
            st.success(f"✅ Added {len(skills)} skills!")
            st.rerun()

# Job Matching Section
st.markdown("---")
st.header("🎯 Step 3: Find Matching Jobs")

if st.session_state.cv_skills:
    col_left, col_right = st.columns([2, 1])
    
    with col_left:
        st.markdown('<span class="free-badge">FREE - NO API COSTS</span>', unsafe_allow_html=True)
        
        if st.button("🔍 Find Matching Jobs (FREE)", type="primary", use_container_width=True):
            with st.spinner(f"Analyzing up to {max_jobs} jobs using FREE pattern matching..."):
                try:
                    matcher = SkillMatcherFree()
                    
                    # Find matching jobs (FREE!)
                    matching_jobs = matcher.find_matching_jobs(
                        cv_skills=st.session_state.cv_skills,
                        min_match_percentage=min_match,
                        limit=max_jobs
                    )
                    
                    st.session_state.matching_jobs = matching_jobs
                    
                    # Get skill gap analysis
                    if matching_jobs:
                        gap_analysis = matcher.get_skill_gap_analysis(
                            cv_skills=st.session_state.cv_skills,
                            top_n_jobs=min(50, len(matching_jobs))
                        )
                        st.session_state.skill_gap = gap_analysis
                    
                    matcher.close()
                    
                    st.success(f"✅ Found {len(matching_jobs)} matching jobs!")
                
                except Exception as e:
                    st.error(f"❌ Error: {str(e)}")
                    st.info("Make sure your database is set up correctly. Run `python setup_database.py`")
    
    with col_right:
        st.metric("Your Skills", len(st.session_state.cv_skills))
        if st.session_state.matching_jobs:
            st.metric("Matching Jobs", len(st.session_state.matching_jobs))

# Display Results
if st.session_state.matching_jobs:
    st.markdown("---")
    
    # Create tabs
    tab1, tab2, tab3 = st.tabs(["📊 Job Matches", "📈 Statistics", "💡 Skill Gap Analysis"])
    
    with tab1:
        st.header("🎯 Your Matching Jobs")
        
        for i, job in enumerate(st.session_state.matching_jobs, 1):
            # Determine match level
            if job['match_percentage'] >= 60:
                match_class = "match-high"
                match_label = "Excellent Match"
            elif job['match_percentage'] >= 40:
                match_class = "match-medium"
                match_label = "Good Match"
            else:
                match_class = "match-low"
                match_label = "Moderate Match"
            
            with st.container():
                col_job1, col_job2 = st.columns([3, 1])
                
                with col_job1:
                    st.markdown(f"### {i}. {job['title']}")
                    st.markdown(f"**{job['company']}** • {job['location']} • *{job['source']}*")
                
                with col_job2:
                    st.markdown(f'<div class="match-badge {match_class}">{job["match_percentage"]:.0f}% Match</div>', unsafe_allow_html=True)
                    st.markdown(f"**{job['match_score']:.0f}** / {job['total_required']} skills")
                
                # Expandable details
                with st.expander("📋 View Details"):
                    col_detail1, col_detail2 = st.columns(2)
                    
                    with col_detail1:
                        if job['exact_matches']:
                            st.markdown("**✅ Your Matching Skills:**")
                            for skill in job['exact_matches'][:10]:
                                st.markdown(f'<span class="skill-tag">{skill}</span>', unsafe_allow_html=True)
                        
                        if job['partial_matches']:
                            st.markdown("**≈ Partial Matches:**")
                            for cv_s, job_s in job['partial_matches'][:3]:
                                st.markdown(f"• You: **{cv_s}** ≈ Required: **{job_s}**")
                    
                    with col_detail2:
                        if job['missing_skills']:
                            st.markdown("**❌ Skills to Learn:**")
                            for skill in job['missing_skills'][:8]:
                                st.markdown(f'<span class="skill-tag missing-skill">{skill}</span>', unsafe_allow_html=True)
                    
                    st.markdown(f"**🔗 [Apply Here]({job['url']})**")
                
                st.markdown("---")
    
    with tab2:
        st.header("📈 Match Statistics")
        
        # Create DataFrame
        df = pd.DataFrame(st.session_state.matching_jobs)
        
        col_stat1, col_stat2, col_stat3 = st.columns(3)
        
        with col_stat1:
            avg_match = df['match_percentage'].mean()
            st.metric("Average Match", f"{avg_match:.1f}%")
        
        with col_stat2:
            best_match = df['match_percentage'].max()
            st.metric("Best Match", f"{best_match:.1f}%")
        
        with col_stat3:
            total_jobs = len(df)
            st.metric("Total Matches", total_jobs)
        
        # Chart
        st.subheader("Match Score Distribution")
        st.bar_chart(df.set_index('title')['match_percentage'])
        
        # Top companies
        st.subheader("Top Companies")
        company_counts = df['company'].value_counts().head(10)
        st.bar_chart(company_counts)
    
    with tab3:
        st.header("💡 Skill Gap Analysis")
        
        if st.session_state.skill_gap:
            gap = st.session_state.skill_gap
            
            st.subheader("📊 Overview")
            col_gap1, col_gap2 = st.columns(2)
            
            with col_gap1:
                st.metric("Jobs Analyzed", gap['total_jobs_analyzed'])
            
            with col_gap2:
                st.metric("Average Match", f"{gap['average_match_percentage']:.1f}%")
            
            st.markdown("---")
            st.subheader("🎯 Top Skills to Learn")
            st.markdown("*Skills most frequently required in your target jobs*")
            
            for item in gap['top_missing_skills'][:15]:
                col_skill1, col_skill2 = st.columns([3, 1])
                
                with col_skill1:
                    st.markdown(f"**{item['skill']}**")
                
                with col_skill2:
                    st.progress(min(item['percentage'] / 100, 1.0))
                    st.caption(f"{item['percentage']:.0f}% of jobs")

elif st.session_state.cv_skills:
    st.info("👆 Click 'Find Matching Jobs' to see your matches!")
else:
    st.info("👆 Please extract or enter your skills first!")

# Footer
st.markdown("---")
st.markdown(
    "<div style='text-align: center; color: gray;'>Made with ❤️ using Streamlit & PostgreSQL<br>✨ Job matching is 100% FREE - unlimited matches!</div>",
    unsafe_allow_html=True
)