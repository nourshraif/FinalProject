--
-- PostgreSQL database dump
--

\restrict z67HVPgNFpih6NvLR7NTHOBuhCGotxb2hrhkeFC6WQCo7zvKOkI8OrgtlYKmKkg

-- Dumped from database version 18.1
-- Dumped by pg_dump version 18.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: jobs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.jobs (
    id integer NOT NULL,
    source character varying(50) NOT NULL,
    job_title character varying(255) NOT NULL,
    company character varying(255) NOT NULL,
    location character varying(255),
    description text,
    job_url character varying(500) NOT NULL,
    scraped_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    is_active boolean DEFAULT true
);


ALTER TABLE public.jobs OWNER TO postgres;

--
-- Name: job_statistics; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.job_statistics AS
 SELECT source,
    count(*) AS total_jobs,
    count(
        CASE
            WHEN (scraped_at > (now() - '24:00:00'::interval)) THEN 1
            ELSE NULL::integer
        END) AS jobs_last_24h,
    count(
        CASE
            WHEN (scraped_at > (now() - '7 days'::interval)) THEN 1
            ELSE NULL::integer
        END) AS jobs_last_week,
    max(scraped_at) AS last_scraped
   FROM public.jobs
  WHERE (is_active = true)
  GROUP BY source
  ORDER BY (count(*)) DESC;


ALTER VIEW public.job_statistics OWNER TO postgres;

--
-- Name: jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.jobs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.jobs_id_seq OWNER TO postgres;

--
-- Name: jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.jobs_id_seq OWNED BY public.jobs.id;


--
-- Name: recent_jobs; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.recent_jobs AS
 SELECT id,
    source,
    job_title,
    company,
    location,
    job_url,
    scraped_at,
    created_at
   FROM public.jobs
  WHERE ((is_active = true) AND (scraped_at > (now() - '7 days'::interval)))
  ORDER BY scraped_at DESC;


ALTER VIEW public.recent_jobs OWNER TO postgres;

--
-- Name: jobs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.jobs ALTER COLUMN id SET DEFAULT nextval('public.jobs_id_seq'::regclass);


--
-- Data for Name: jobs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.jobs (id, source, job_title, company, location, description, job_url, scraped_at, created_at, is_active) FROM stdin;
1	weworkremotely	Marketing Strategy Advisor	New	Remote		https://weworkremotely.com/remote-jobs/newtonx-marketing-strategy-advisor	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
2	weworkremotely	Remote Inside Sales	New	Remote		https://weworkremotely.com/remote-jobs/report-owl-llc-remote-inside-sales-3	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
3	weworkremotely	Growth Lead	New	Remote		https://weworkremotely.com/remote-jobs/forager-growth-lead	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
4	weworkremotely	Content Marketer, SEO	New	Remote		https://weworkremotely.com/remote-jobs/animalz-content-marketer-seo	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
5	weworkremotely	Senior Content Marketer (Enterprise/Campaigns)	New	Remote		https://weworkremotely.com/remote-jobs/animalz-senior-content-marketer-enterprise-campaigns-2	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
6	weworkremotely	Founder's Associate - Biz Dev - UK-based remote - £36-42k	Ellipsis®	Remote		https://weworkremotely.com/remote-jobs/ellipsis-founder-s-associate-biz-dev-uk-based-remote-36-42k	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
7	weworkremotely	Student Private Jet Broker	EchoJet Limited	Remote		https://weworkremotely.com/remote-jobs/echojet-limited-student-private-jet-broker	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
8	weworkremotely	Remote Inside Sales	Your Resource Group LLC	Remote		https://weworkremotely.com/remote-jobs/your-resource-group-llc-remote-inside-sales	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
9	weworkremotely	Director of Revenue	18d	Remote		https://weworkremotely.com/remote-jobs/yoko-co-director-of-revenue-1	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
10	weworkremotely	Video Editor (Full Time, Remote)	22d	Remote		https://weworkremotely.com/remote-jobs/forward-push-law-firm-marketing-video-editor-full-time-remote	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
11	weworkremotely	Account Executive	22d	Remote		https://weworkremotely.com/remote-jobs/arc-dev-account-executive	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
12	weworkremotely	Remote Sales Representative	24d	Remote		https://weworkremotely.com/remote-jobs/credit-joy-remote-sales-representative	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
13	weworkremotely	Inside Sales Contractor	26d	Remote		https://weworkremotely.com/remote-jobs/report-owl-llc-inside-sales-contractor	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
14	weworkremotely	Performance Marketing Specialist	New	Remote		https://weworkremotely.com/remote-jobs/the-careside-performance-marketing-specialist	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
15	weworkremotely	Story-Driven Video Editor (YouTube & Shorts)	New	Remote		https://weworkremotely.com/remote-jobs/keshav-bhatt-story-driven-video-editor-youtube-shorts	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
16	weworkremotely	Director - WMS Implementation (Blue Yonder)	New	Remote		https://weworkremotely.com/remote-jobs/kenco-director-wms-implementation-blue-yonder	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
17	weworkremotely	Senior Marketing Specialist (Growth & Conversion) (100% Remote – Chicago Area Preferred)	New	Remote		https://weworkremotely.com/remote-jobs/win-home-inspection-senior-marketing-specialist-growth-conversion-100-remote-chicago-area-preferred	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
18	weworkremotely	Sr. Field Marketing Manager	New	Remote		https://weworkremotely.com/remote-jobs/rimini-street-sr-field-marketing-manager	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
19	weworkremotely	Analytics Engineer	New	Remote		https://weworkremotely.com/remote-jobs/amplify-education-analytics-engineer	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
20	weworkremotely	Sales Development Representative	New	Remote		https://weworkremotely.com/remote-jobs/chief-rebel-sales-development-representative	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
21	weworkremotely	Global Partner Acquirer (Growth Marketing & Sales, Remote)	Lifeinion	Remote		https://weworkremotely.com/remote-jobs/lifeinion-global-partner-acquirer-growth-marketing-sales-remote	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
22	weworkremotely	Social Media Manager (Home Improvement)	Expedock	Remote		https://weworkremotely.com/remote-jobs/expedock-social-media-manager-home-improvement	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
23	weworkremotely	Marketing Coordinator (Upswing)	Bellota Labs	Remote		https://weworkremotely.com/remote-jobs/bellota-labs-marketing-coordinator-upswing	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
24	weworkremotely	Fashion and Beauty Ambassador	Acosta	Remote		https://weworkremotely.com/remote-jobs/acosta-fashion-and-beauty-ambassador-1	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
25	weworkremotely	Director of Product Marketing, API Security, Remote	Planet Green Search	Remote		https://weworkremotely.com/remote-jobs/planet-green-search-director-of-product-marketing-api-security-remote-1	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
26	weworkremotely	Senior Python Backend Developer	New	Remote		https://weworkremotely.com/remote-jobs/skycatchfire-senior-python-backend-developer	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
27	weworkremotely	Senior PHP Developer	OnTheGoSystems	Remote		https://weworkremotely.com/remote-jobs/onthegosystems-senior-php-developer-3	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
28	weworkremotely	Senior Backend Engineer - Full Remote	Zencastr	Remote		https://weworkremotely.com/remote-jobs/zencastr-senior-backend-engineer-full-remote	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
29	weworkremotely	PHP Developer (Spanish, French or German speakers)	23d	Remote		https://weworkremotely.com/remote-jobs/onthegosystems-php-developer-spanish-french-or-german-speakers	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
30	weworkremotely	Senior Network Automation Engineer (M/W/D)	New	Remote		https://weworkremotely.com/remote-jobs/anexia-internetdienstleistungs-senior-network-automation-engineer-m-w-d	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
31	weworkremotely	SR. Sitecore Front End Web Developer - Publix.com (Remote)	New	Remote		https://weworkremotely.com/remote-jobs/publix-super-markets-sr-sitecore-front-end-web-developer-publix-com-remote	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
32	weworkremotely	Senior Web Developer - Figma & Webflow Expertise	New	Remote		https://weworkremotely.com/remote-jobs/adoreal-senior-web-developer-figma-webflow-expertise	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
33	weworkremotely	WordPress Developer	Uncanny Owl	Remote		https://weworkremotely.com/remote-jobs/uncanny-owl-wordpress-developer	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
34	weworkremotely	ASP.NET Developer (C#, MVC, SQL Server, JavaScript)	Linkage Web Development	Remote		https://weworkremotely.com/remote-jobs/linkage-web-development-asp-net-developer-c-mvc-sql-server-javascript	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
35	weworkremotely	Senior Web Developer	Zipdev	Remote		https://weworkremotely.com/remote-jobs/zipdev-senior-web-developer	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
36	weworkremotely	Enterprise Account Executive - West	Webflow	Remote		https://weworkremotely.com/remote-jobs/webflow-enterprise-account-executive-west	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
37	weworkremotely	Senior Web Developer (Remote)	Walker Smith	Remote		https://weworkremotely.com/remote-jobs/walker-smith-senior-web-developer-remote	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
38	weworkremotely	Web Developer	DreamRider Productions Careers	Remote		https://weworkremotely.com/remote-jobs/dreamrider-productions-careers-web-developer	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
39	weworkremotely	Full Stack Developer (Javascript)	Codekeeper	Remote		https://weworkremotely.com/remote-jobs/codekeeper-full-stack-developer-javascript	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
40	weworkremotely	Manager, Web Development	ServiceTitan	Remote		https://weworkremotely.com/remote-jobs/servicetitan-manager-web-development	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
41	weworkremotely	Web Developer (Contract)	10d	Remote		https://weworkremotely.com/remote-jobs/madeo-web-developer-contract	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
42	weworkremotely	Freelance Agent Evaluation Engineer	12d	Remote		https://weworkremotely.com/remote-jobs/mindrift-freelance-agent-evaluation-engineer	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
43	weworkremotely	Freelance Senior Python Developer / Functional Test Frameworks	12d	Remote		https://weworkremotely.com/remote-jobs/mindrift-freelance-senior-python-developer-functional-test-frameworks	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
44	weworkremotely	Core Software Engineer (C++) - Remote	18d	Remote		https://weworkremotely.com/remote-jobs/clickhouse-core-software-engineer-c-remote	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
45	weworkremotely	Senior Software Engineer - Backend/Python - USA Only (100% Remote)	20d	Remote		https://weworkremotely.com/remote-jobs/close-senior-software-engineer-backend-python-usa-only-100-remote-1	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
46	weworkremotely	Senior Backend Engineer	21d	Remote		https://weworkremotely.com/remote-jobs/proton-ai-senior-backend-engineer	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
47	weworkremotely	Senior Python & LLM /AI Engineer	23d	Remote		https://weworkremotely.com/remote-jobs/lemon-io-senior-python-llm-ai-engineer	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
48	weworkremotely	Senior Backend Developer (Node.js / Nest.js)	24d	Remote		https://weworkremotely.com/remote-jobs/proxify-ab-senior-backend-developer-node-js-nest-js-1	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
49	weworkremotely	Senior Backend Developer (Python)	24d	Remote		https://weworkremotely.com/remote-jobs/proxify-ab-senior-backend-developer-python-6	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
50	weworkremotely	Contract Software Engineer (AI x Biology)	24d	Remote		https://weworkremotely.com/remote-jobs/great-good-contract-software-engineer-ai-x-biology	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
51	weworkremotely	Operations Supervisor (Remote, US-Based) – Early-Stage Tech Startup	New	Remote		https://weworkremotely.com/remote-jobs/stealth-mode-tech-startup-operations-supervisor-remote-us-based-early-stage-tech-startup	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
52	weworkremotely	Virtual Assistant	New	Remote		https://weworkremotely.com/remote-jobs/toptal-virtual-assistant	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
53	weworkremotely	Personal Assistant	New	Remote		https://weworkremotely.com/remote-jobs/toptal-personal-assistant	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
54	weworkremotely	Executive Assistant	New	Remote		https://weworkremotely.com/remote-jobs/toptal-executive-assistant	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
55	weworkremotely	Customer Service Representative	New	Remote		https://weworkremotely.com/remote-jobs/toptal-customer-service-representative	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
56	weworkremotely	ESL Content Creator at Startup (Arno - goarno.io)	New	Remote		https://weworkremotely.com/remote-jobs/arno-esl-content-creator-at-startup-arno-goarno-io	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
57	weworkremotely	FT/PT Remote AI Prompt Engineering & Evaluation - Will Train	New	Remote		https://weworkremotely.com/remote-jobs/dataannotation-tech-ft-pt-remote-ai-prompt-engineering-evaluation-will-train	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
58	weworkremotely	Software Engineer, Platform	Speechify Inc	Remote		https://weworkremotely.com/remote-jobs/speechify-inc-software-engineer-platform	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
59	weworkremotely	Strategic IT Advisor	NewtonX	Remote		https://weworkremotely.com/remote-jobs/newtonx-strategic-it-advisor-2	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
60	weworkremotely	Junior Crypto Analyst & Trader	Elemental Terra	Remote		https://weworkremotely.com/remote-jobs/elemental-terra-junior-crypto-analyst-trader	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
61	weworkremotely	AI Internet Rater - English (United States)	Welo Data	Remote		https://weworkremotely.com/remote-jobs/welo-data-ai-internet-rater-english-united-states	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
62	weworkremotely	Senior Machine Learning Engineer	Zencastr	Remote		https://weworkremotely.com/remote-jobs/zencastr-senior-machine-learning-engineer	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
63	weworkremotely	Investor Onboarding Specialist – Private Equity Real Estate	Walter	Remote		https://weworkremotely.com/remote-jobs/walter-investor-onboarding-specialist-private-equity-real-estate-1	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
64	weworkremotely	Online English Teacher	Native Camp	Remote		https://weworkremotely.com/remote-jobs/native-camp-online-english-teacher-30	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
65	weworkremotely	Managing Editor	The Swiftest	Remote		https://weworkremotely.com/remote-jobs/the-swiftest-managing-editor	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
66	weworkremotely	Full-Stack Engineer (Python/React/GenAI)	Toptal	Remote		https://weworkremotely.com/remote-jobs/toptal-full-stack-engineer-python-react-genai	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
67	weworkremotely	Freelance Writer	16d	Remote		https://weworkremotely.com/remote-jobs/prowritersites-freelance-writer	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
68	weworkremotely	Embedded firmware developer	23d	Remote		https://weworkremotely.com/remote-jobs/toptal-embedded-firmware-developer	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
69	weworkremotely	Network Engineer for AI automotive product	23d	Remote		https://weworkremotely.com/remote-jobs/toptal-network-engineer-for-ai-automotive-product	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
70	weworkremotely	Financial Model and Prompt Creator with Spreadsheet Expertise	25d	Remote		https://weworkremotely.com/remote-jobs/toptal-financial-model-and-prompt-creator-with-spreadsheet-expertise	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
71	weworkremotely	AI Development Advisor	25d	Remote		https://weworkremotely.com/remote-jobs/newtonx-ai-development-advisor	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
72	weworkremotely	Remote Data Entry Clerk	29d	Remote		https://weworkremotely.com/remote-jobs/nogigiddy-remote-data-entry-clerk-7	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
73	weworkremotely	(Virtual Tutor) Teach Studens in the United States (English Required)	New	Remote		https://weworkremotely.com/remote-jobs/papaya-tutor-virtual-tutor-teach-studens-in-the-united-states-english-required	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
74	weworkremotely	UI/UX Designer (Part-Time, Remote, Latin America)	New	Remote		https://weworkremotely.com/remote-jobs/bluelight-consulting-ui-ux-designer-part-time-remote-latin-america	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
75	weworkremotely	Inhouse Consultant für SAP / Schwerpunkt OTC international – teilweise remote (m/w/d)	New	Remote		https://weworkremotely.com/remote-jobs/vossloh-inhouse-consultant-fur-sap-schwerpunkt-otc-international-teilweise-remote-m-w-d	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
76	weworkremotely	Account Executive | Sênior (11844)	New	Remote		https://weworkremotely.com/remote-jobs/sensedia-account-executive-senior-11844	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
77	weworkremotely	Full Stack Analytics DevOps Engineer	New	Remote		https://weworkremotely.com/remote-jobs/guidehouse-full-stack-analytics-devops-engineer	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
78	weworkremotely	DevOps Engineer - 100% remote	New	Remote		https://weworkremotely.com/remote-jobs/tether-operations-limited-devops-engineer-100-remote	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
79	weworkremotely	Senior DevOps Engineer	New	Remote		https://weworkremotely.com/remote-jobs/3pillar-senior-devops-engineer	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
80	weworkremotely	Devops	New	Remote		https://weworkremotely.com/remote-jobs/remotely-works-devops	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
81	weworkremotely	DevOps Engineer	S-Pro	Remote		https://weworkremotely.com/remote-jobs/s-pro-devops-engineer	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
82	weworkremotely	Senior Site Reliability Engineer / DevOps - REMOTE (US Citizenship required)	Oracle	Remote		https://weworkremotely.com/remote-jobs/oracle-senior-site-reliability-engineer-devops-remote-us-citizenship-required	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
83	weworkremotely	DevOps Engineer (Client)	CrewBloom	Remote		https://weworkremotely.com/remote-jobs/crewbloom-devops-engineer-client	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
84	weworkremotely	Salesforce Admin+Devops_3+ years_Remote	Coders Brain Technology	Remote		https://weworkremotely.com/remote-jobs/coders-brain-technology-salesforce-admin-devops_3-years_remote	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
85	weworkremotely	Senior Software Engineer (Full Stack/DevOps) - India	Aspire	Remote		https://weworkremotely.com/remote-jobs/aspire-senior-software-engineer-full-stack-devops-india	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
86	weworkremotely	Lead Platform Engineer	Updater	Remote		https://weworkremotely.com/remote-jobs/updater-lead-platform-engineer	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
87	weworkremotely	Senior Cloud (DevOps) Engineer - Guatemala	nClouds	Remote		https://weworkremotely.com/remote-jobs/nclouds-senior-cloud-devops-engineer-guatemala	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
88	weworkremotely	Senior DataOps Engineer	dLocal	Remote		https://weworkremotely.com/remote-jobs/dlocal-senior-dataops-engineer	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
89	weworkremotely	DevOps Engineer (w/m/d)	Transfermarkt	Remote		https://weworkremotely.com/remote-jobs/transfermarkt-devops-engineer-w-m-d	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
90	weworkremotely	Principal DevOps Engineer - Seattle, WA or Arlington, VA (50% remote)	Oracle	Remote		https://weworkremotely.com/remote-jobs/oracle-principal-devops-engineer-seattle-wa-or-arlington-va-50-remote	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
91	weworkremotely	Remote Full time SRE DevOps Engagement Lead & Cloud Platform Architect	CapB InfoteK	Remote		https://weworkremotely.com/remote-jobs/capb-infotek-remote-full-time-sre-devops-engagement-lead-cloud-platform-architect	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
92	weworkremotely	Senior DevOps (Full remote)	Blackfluo.ai	Remote		https://weworkremotely.com/remote-jobs/blackfluo-ai-senior-devops-full-remote	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
93	weworkremotely	DevOps Engineer (Poland Remote)	Turnitin	Remote		https://weworkremotely.com/remote-jobs/turnitin-devops-engineer-poland-remote	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
94	weworkremotely	DevOps Engineer	Inco	Remote		https://weworkremotely.com/remote-jobs/inco-devops-engineer	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
95	weworkremotely	DevOps Engineer	Graham Healthcare Group	Remote		https://weworkremotely.com/remote-jobs/graham-healthcare-group-devops-engineer	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
96	weworkremotely	Senior Cloud Infrastructure Engineer	17d	Remote		https://weworkremotely.com/remote-jobs/digioh-senior-cloud-infrastructure-engineer	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
97	weworkremotely	Senior DevOps Engineer	23d	Remote		https://weworkremotely.com/remote-jobs/marketerx-senior-devops-engineer	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
98	weworkremotely	QA automation/Devops engineer for MKE4K	23d	Remote		https://weworkremotely.com/remote-jobs/mirantis-qa-automation-devops-engineer-for-mke4k	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
99	weworkremotely	Utleiemegleren Forvaltning AS	23d	Remote		https://weworkremotely.com/remote-jobs/intro-io-utleiemegleren-forvaltning-as	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
100	weworkremotely	Google Cloud Platform DevOps Engineer	24d	Remote		https://weworkremotely.com/remote-jobs/lmg-staffing-solutions-google-cloud-platform-devops-engineer	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
101	weworkremotely	Product Designer / UX Expert (US-Remote)	New	Remote		https://weworkremotely.com/remote-jobs/contra-product-designer-ux-expert-us-remote-1	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
102	weworkremotely	Product Designer / UX Expert (US-Remote)	New	Remote		https://weworkremotely.com/remote-jobs/contra-product-designer-ux-expert-us-remote	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
103	weworkremotely	Product Designer (Hardware / 3D CAD)	10d	Remote		https://weworkremotely.com/remote-jobs/kys-norway-product-designer-hardware-3d-cad	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
104	weworkremotely	Lead Product Designer	New	Remote		https://weworkremotely.com/remote-jobs/rare-days-lead-product-designer	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
105	weworkremotely	Senior Talent Partner — Product & Design	Fueled	Remote		https://weworkremotely.com/remote-jobs/fueled-senior-talent-partner-product-design	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
106	weworkremotely	Product Design Engineer	xponentiate	Remote		https://weworkremotely.com/remote-jobs/xponentiate-product-design-engineer	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
107	weworkremotely	Technical Project Manager - Application Design (Physical Access Control & PIAM Systems)	Oracle	Remote		https://weworkremotely.com/remote-jobs/oracle-technical-project-manager-application-design-physical-access-control-piam-systems	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
108	weworkremotely	Surgical Healing Specialist (North Boston, MA)	Solventum	Remote		https://weworkremotely.com/remote-jobs/solventum-surgical-healing-specialist-north-boston-ma	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
109	weworkremotely	Post-Acute Wound Healing Specialist (Las Vegas, NV)	Solventum	Remote		https://weworkremotely.com/remote-jobs/solventum-post-acute-wound-healing-specialist-las-vegas-nv	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
110	weworkremotely	Virtual Design & Construction (VDC) Designer – Miamisburg, OH (On-Site)	Danis Construction	Remote		https://weworkremotely.com/remote-jobs/danis-construction-virtual-design-construction-vdc-designer-miamisburg-oh-on-site	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
111	weworkremotely	Semiconductor Design Manager	AECOM	Remote		https://weworkremotely.com/remote-jobs/aecom-semiconductor-design-manager	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
112	weworkremotely	Product Manager	Unlayer	Remote		https://weworkremotely.com/remote-jobs/unlayer-product-manager-1	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
113	weworkremotely	Virtual Design and Construction Planner	Miller Electric Company	Remote		https://weworkremotely.com/remote-jobs/miller-electric-company-virtual-design-and-construction-planner	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
114	weworkremotely	Senior Growth Product Manager	Kit	Remote		https://weworkremotely.com/remote-jobs/kit-senior-growth-product-manager	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
115	weworkremotely	Graphic Designer/Social Media Manager	12d	Remote		https://weworkremotely.com/remote-jobs/bbe-marketing-inc-graphic-designer-social-media-manager-1	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
116	weworkremotely	Customer Success Manager, Digital (VSMB/SMB)	17d	Remote		https://weworkremotely.com/remote-jobs/float-customer-success-manager-digital-vsmb-smb	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
117	weworkremotely	Senior Product Manager, Plan	18d	Remote		https://weworkremotely.com/remote-jobs/gitlab-senior-product-manager-plan	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
118	weworkremotely	Vice President, Acquisitions & Business Development – Caribbean and Latin America (CALA)	24d	Remote		https://weworkremotely.com/remote-jobs/davidson-hospitality-group-vice-president-acquisitions-business-development-caribbean-and-latin-america-cala	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
119	weworkremotely	Amazon Graphic Designer	24d	Remote		https://weworkremotely.com/remote-jobs/adaptive-teams-amazon-graphic-designer	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
120	weworkremotely	UX Researcher (Contract)	24d	Remote		https://weworkremotely.com/remote-jobs/anatta-design-ux-researcher-contract	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
121	weworkremotely	Automation Design Engineer	23d	Remote		https://weworkremotely.com/remote-jobs/globetek-automation-design-engineer	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
122	weworkremotely	Design Engineer	24d	Remote		https://weworkremotely.com/remote-jobs/elevenlabs-design-engineer	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
123	weworkremotely	Freelance Art Director - Brand Design (B2B SaaS Client)	25d	Remote		https://weworkremotely.com/remote-jobs/camping-tv-freelance-art-director-brand-design-b2b-saas-client	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
124	weworkremotely	Civil Design Engineer II	25d	Remote		https://weworkremotely.com/remote-jobs/revamp-engineering-civil-design-engineer-ii	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
125	weworkremotely	Home Design Lead	25d	Remote		https://weworkremotely.com/remote-jobs/higharc-home-design-lead	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
126	weworkremotely	Senior Fullstack Developer	Zencastr	Remote		https://weworkremotely.com/remote-jobs/zencastr-senior-fullstack-developer	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
127	weworkremotely	Senior Software Engineer	10d	Remote		https://weworkremotely.com/remote-jobs/walter-senior-software-engineer	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
128	weworkremotely	Senior Ruby on Rails Developer	16d	Remote		https://weworkremotely.com/remote-jobs/onthegosystems-senior-ruby-on-rails-developer	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
129	weworkremotely	Software engineer	17d	Remote		https://weworkremotely.com/remote-jobs/sticker-mule-software-engineer-2	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
130	weworkremotely	Full Stack Engineer - Ruby on Rails and React	25d	Remote		https://weworkremotely.com/remote-jobs/planning-center-full-stack-engineer-ruby-on-rails-and-react	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
131	weworkremotely	Senior Independent Software Developer ($90-$170/hr)	New	Remote		https://weworkremotely.com/remote-jobs/a-team-senior-independent-software-developer-90-170-hr	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
132	weworkremotely	Web Entwickler mit Schwerpunkt PHP (m/w/d)	New	Remote		https://weworkremotely.com/remote-jobs/kosatec-empowering-global-innovation-web-entwickler-mit-schwerpunkt-php-m-w-d	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
133	weworkremotely	Product Designer (UI/UX – Web Application)	New	Remote		https://weworkremotely.com/remote-jobs/gofasti-product-designer-ui-ux-web-application	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
134	weworkremotely	QA Engineer III (Selenium/Playwright)	New	Remote		https://weworkremotely.com/remote-jobs/realpage-qa-engineer-iii-selenium-playwright	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
135	weworkremotely	Outreach Manager, Political Campaigns	New	Remote		https://weworkremotely.com/remote-jobs/wevote-outreach-manager-political-campaigns	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
136	weworkremotely	Digital Designer - Web & UI/UX	New	Remote		https://weworkremotely.com/remote-jobs/oneil-interactive-digital-designer-web-ui-ux	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
137	weworkremotely	Software Engineer - Test	New	Remote		https://weworkremotely.com/remote-jobs/subscript-software-engineer-test	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
138	weworkremotely	Fundraiser, Volunteer Ambassador	WeVote	Remote		https://weworkremotely.com/remote-jobs/wevote-fundraiser-volunteer-ambassador	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
139	weworkremotely	Senior Penetration Tester (WebApp and Network)	Rapid Strategy	Remote		https://weworkremotely.com/remote-jobs/rapid-strategy-senior-penetration-tester-webapp-and-network	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
140	weworkremotely	Software Engineer	Cortes 23	Remote		https://weworkremotely.com/remote-jobs/cortes-23-software-engineer-3	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
141	weworkremotely	Senior Shopify Developer (Remote + Flexible)	Storetasker	Remote		https://weworkremotely.com/remote-jobs/storetasker-senior-shopify-developer-remote-flexible-3	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
142	weworkremotely	AI Software Engineer	10d	Remote		https://weworkremotely.com/remote-jobs/slidespeak-ai-software-engineer	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
143	weworkremotely	Senior Software Engineer, Growth	13d	Remote		https://weworkremotely.com/remote-jobs/clerk-senior-software-engineer-growth	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
144	weworkremotely	Senior Web Application Developer	13d	Remote		https://weworkremotely.com/remote-jobs/details-senior-web-application-developer	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
145	weworkremotely	Optimization Specialist	13d	Remote		https://weworkremotely.com/remote-jobs/oneil-interactive-optimization-specialist	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
146	weworkremotely	Product Marketing Lead	13d	Remote		https://weworkremotely.com/remote-jobs/wevote-product-marketing-lead	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
147	weworkremotely	Full Stack Developer	13d	Remote		https://weworkremotely.com/remote-jobs/qinetiq-us-full-stack-developer	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
148	weworkremotely	Experienced Full-Stack Software Engineer (.NET/React), 80–100% (f/m/x), fully remote	15d	Remote		https://weworkremotely.com/remote-jobs/comparis-ch-experienced-full-stack-software-engineer-net-react-80-100-f-m-x-fully-remote	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
149	weworkremotely	Senior Software Engineer	18d	Remote		https://weworkremotely.com/remote-jobs/fonio-senior-software-engineer	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
150	weworkremotely	Senior Software Engineer	20d	Remote		https://weworkremotely.com/remote-jobs/stellar-ai-senior-software-engineer	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
151	weworkremotely	Software Engineer, iOS Core Product	Speechify Inc	Remote		https://weworkremotely.com/remote-jobs/speechify-inc-software-engineer-ios-core-product	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
152	weworkremotely	Software Engineer, macOS Core Product	New	Remote		https://weworkremotely.com/remote-jobs/speechify-inc-software-engineer-macos-core-product	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
153	weworkremotely	2Nd Level Support - Virtualization Stack (M/W/D)	New	Remote		https://weworkremotely.com/remote-jobs/anexia-internetdienstleistungs-2nd-level-support-virtualization-stack-m-w-d	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
154	weworkremotely	Web Developer	New	Remote		https://weworkremotely.com/remote-jobs/engineering-comfort-solutions-web-developer	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
155	weworkremotely	Estrategista Comercial (Inside Sales)	New	Remote		https://weworkremotely.com/remote-jobs/gentia-estrategista-comercial-inside-sales	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
156	weworkremotely	Front End Developer (HTML & CSS)	New	Remote		https://weworkremotely.com/remote-jobs/startupz-com-front-end-developer-html-css	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
157	weworkremotely	QA Engineer (M/W/D)	Anexia Internetdienstleistungs	Remote		https://weworkremotely.com/remote-jobs/anexia-internetdienstleistungs-qa-engineer-m-w-d	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
158	weworkremotely	Regional Sales Executive (Account Manager)	Dealer eProcess	Remote		https://weworkremotely.com/remote-jobs/dealer-eprocess-regional-sales-executive-account-manager-1	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
159	weworkremotely	FPGA Development Engineer	NuTechs	Remote		https://weworkremotely.com/remote-jobs/nutechs-fpga-development-engineer	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
160	weworkremotely	Commerce Tools + Node JS + Cloud	ALIQAN Technologies	Remote		https://weworkremotely.com/remote-jobs/aliqan-technologies-commerce-tools-node-js-cloud	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
161	weworkremotely	Senior Back-End Web Developer	Eran Group	Remote		https://weworkremotely.com/remote-jobs/eran-group-senior-back-end-web-developer	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
162	weworkremotely	Data Engineer (M/W/D)	Anexia Internetdienstleistungs	Remote		https://weworkremotely.com/remote-jobs/anexia-internetdienstleistungs-data-engineer-m-w-d	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
163	weworkremotely	Ai/Ml Engineer – LLM Systems (M/W/D)	Anexia Internetdienstleistungs	Remote		https://weworkremotely.com/remote-jobs/anexia-internetdienstleistungs-ai-ml-engineer-llm-systems-m-w-d	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
164	weworkremotely	JetBrains Web Developer Advocate (Developer Advocacy)	JetBrains	Remote		https://weworkremotely.com/remote-jobs/jetbrains-jetbrains-web-developer-advocate-developer-advocacy	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
165	weworkremotely	Web Designer	13d	Remote		https://weworkremotely.com/remote-jobs/hex-technologies-web-designer	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
166	weworkremotely	Head of Web Dev	12d	Remote		https://weworkremotely.com/remote-jobs/activate-talent-head-of-web-dev	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
167	weworkremotely	Marketing Web Developer	12d	Remote		https://weworkremotely.com/remote-jobs/jobgether-marketing-web-developer	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
168	weworkremotely	Sr. Engineer, Frontend (UX Eng)	18d	Remote		https://weworkremotely.com/remote-jobs/zappier-sr-engineer-frontend-ux-eng	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
169	weworkremotely	Senior Next.js Developer	27d	Remote		https://weworkremotely.com/remote-jobs/proxify-ab-senior-next-js-developer-4	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
170	weworkremotely	Frontend Engineer	28d	Remote		https://weworkremotely.com/remote-jobs/mobena-frontend-engineer	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
171	weworkremotely	Curam Business Analyst	30d	Remote		https://weworkremotely.com/remote-jobs/ahu-technologies-curam-business-analyst	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
172	weworkremotely	FTG Engineer	30d	Remote		https://weworkremotely.com/remote-jobs/aliqan-technologies-ftg-engineer	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
173	weworkremotely	Java / Web Developer with German	30d	Remote		https://weworkremotely.com/remote-jobs/european-dynamics-java-web-developer-with-german	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
174	weworkremotely	Web Designer	30d	Remote		https://weworkremotely.com/remote-jobs/truv-web-designer	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
175	weworkremotely	Web graphic designer	30d	Remote		https://weworkremotely.com/remote-jobs/productive-shop-web-graphic-designer	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
176	weworkremotely	Customer Support Agent (Remote)	CRAE GROUP LTD	Remote		https://weworkremotely.com/remote-jobs/crae-group-ltd-customer-support-agent-remote	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
177	weworkremotely	Freelancer (m/w/d) im Customer Service Inbound - weltweit - 100% Remote	hey contact heroes GmbH	Remote		https://weworkremotely.com/remote-jobs/hey-contact-heroes-gmbh-freelancer-m-w-d-im-customer-service-inbound-weltweit-100-remote	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
178	weworkremotely	$1k Weekly Work from Home Job Position	14d	Remote		https://weworkremotely.com/remote-jobs/best-estimate-pro-1k-weekly-work-from-home-job-position	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
179	weworkremotely	Live Technical Support Representative — Full-Time (40 hrs/week, Sat–Sun required, Tues-Wed off) — $40,000/year + Benefits — Locations: CA, ID, OR, TX, WA	26d	Remote		https://weworkremotely.com/remote-jobs/porkbun-live-technical-support-representative-full-time-40-hrs-week-sat-sun-required-tues-wed-off-40-000-year	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
180	weworkremotely	Customer Onboarding/Success	New	Remote		https://weworkremotely.com/remote-jobs/rn-pad-customer-onboarding-success	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
181	weworkremotely	Veeva CRM Business Analyst - Remote, US	Slipstream IT	Remote		https://weworkremotely.com/remote-jobs/slipstream-it-veeva-crm-business-analyst-remote-us	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
182	weworkremotely	DACH Contract Manager, Upmarket - German Speaker	HubSpot	Remote		https://weworkremotely.com/remote-jobs/hubspot-dach-contract-manager-upmarket-german-speaker	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
183	weworkremotely	Personal Assistant - Research, CRM & Takeoffs	Remote VA	Remote		https://weworkremotely.com/remote-jobs/remote-va-personal-assistant-research-crm-takeoffs	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
184	weworkremotely	Sales Systems & CRM Support Associate	Outsourced Pro Global	Remote		https://weworkremotely.com/remote-jobs/outsourced-pro-global-sales-systems-crm-support-associate	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
185	weworkremotely	Founding Technical ISV Alliance Lead	Hightouch	Remote		https://weworkremotely.com/remote-jobs/hightouch-founding-technical-isv-alliance-lead	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
186	weworkremotely	Amazon Seller Central Expert (Flat Files)	Amazowl	Remote		https://weworkremotely.com/remote-jobs/amazowl-amazon-seller-central-expert-flat-files-1	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
187	weworkremotely	CRM & Ecommerce Designer (Braze + Shopify) - Contractor	Paired	Remote		https://weworkremotely.com/remote-jobs/paired-crm-ecommerce-designer-braze-shopify-contractor	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
188	weworkremotely	Estagiário em CRM Marketing	Nação Digital	Remote		https://weworkremotely.com/remote-jobs/nacao-digital-estagiario-em-crm-marketing	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
189	weworkremotely	Senior Director, Talent Acquisition Operations & Programs	HubSpot	Remote		https://weworkremotely.com/remote-jobs/hubspot-senior-director-talent-acquisition-operations-programs	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
190	weworkremotely	CRM Manager	11d	Remote		https://weworkremotely.com/remote-jobs/goodjuju-marketing-crm-manager	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
905	arbeitnow	Senior Solutions Architect	Automat-it	Berlin	Remote	https://www.arbeitnow.com/jobs/companies/automat-it/remote-senior-solutions-architect-berlin-463550	2026-02-08 21:45:54.384296	2026-02-08 21:45:54.384296	t
191	weworkremotely	Customer Onboarding Specialist for Company Incorporations (Full Time)	11d	Remote		https://weworkremotely.com/remote-jobs/flag-theory-customer-onboarding-specialist-for-company-incorporations-full-time-2	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
192	weworkremotely	Simplero Support Specialist (Full-Time, Remote)	11d	Remote		https://weworkremotely.com/remote-jobs/simplero-simplero-support-specialist-full-time-remote	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
193	weworkremotely	Business Development Representative - Italy	13d	Remote		https://weworkremotely.com/remote-jobs/hubspot-business-development-representative-italy	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
194	weworkremotely	CRM ServiceNow Technology Consultant	13d	Remote		https://weworkremotely.com/remote-jobs/servicenow-crm-servicenow-technology-consultant	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
195	weworkremotely	Senior Manager / Lead – Sanctions & Financial Crime Risk Management (FCRM) - 0122 SS #4	13d	Remote		https://weworkremotely.com/remote-jobs/navitaspartners-senior-manager-lead-sanctions-financial-crime-risk-management-fcrm-0122	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
196	weworkremotely	Microsoft Dynamics CRM Developer	13d	Remote		https://weworkremotely.com/remote-jobs/hastree-technologies-microsoft-dynamics-crm-developer	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
197	weworkremotely	Senior Customer Success Manager, TOLA (Spanish speaking)	18d	Remote		https://weworkremotely.com/remote-jobs/abnormal-senior-customer-success-manager-tola-spanish-speaking	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
198	weworkremotely	Digital Agency Account Manager	20d	Remote		https://weworkremotely.com/remote-jobs/icarus-digital-marketing-digital-agency-account-manager	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
199	weworkremotely	Dynamics 365 CRM Developer	23d	Remote		https://weworkremotely.com/remote-jobs/isolutions-dynamics-365-crm-developer	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
200	weworkremotely	Principal Engineer, CRM & MarTech	23d	Remote		https://weworkremotely.com/remote-jobs/stitch-fix-principal-engineer-crm-martech	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
201	weworkremotely	Head of Community	11d	Remote		https://weworkremotely.com/remote-jobs/the-tech-tribe-head-of-community	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
202	weworkremotely	Senior WordPress Developer	18d	Remote		https://weworkremotely.com/remote-jobs/wpforms-senior-wordpress-developer-1	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
203	weworkremotely	Senior Independent Product Manager/Product Designer ($90-$170/hr)	New	Remote		https://weworkremotely.com/remote-jobs/a-team-senior-independent-product-manager-product-designer-90-170-hr	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
204	weworkremotely	Senior Account Executive, SaaS, Remote	New	Remote		https://weworkremotely.com/remote-jobs/planet-green-search-senior-account-executive-saas-remote-2	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
205	weworkremotely	Growth Partner	New	Remote		https://weworkremotely.com/remote-jobs/victorious-growth-partner	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
206	weworkremotely	Software Engineering Manager (Backend SaaS)	New	Remote		https://weworkremotely.com/remote-jobs/canonical-software-engineering-manager-backend-saas	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
207	weworkremotely	Senior Account Executive, SaaS, Remote	Planet Green Search	Remote		https://weworkremotely.com/remote-jobs/planet-green-search-senior-account-executive-saas-remote-1	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
208	weworkremotely	Tier 1 Support Engineer	Avoxi	Remote		https://weworkremotely.com/remote-jobs/avoxi-tier-1-support-engineer	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
209	weworkremotely	Account Executive 🚀 Lima📍 (SaaS Enterprise)	Minderest	Remote		https://weworkremotely.com/remote-jobs/minderest-account-executive-lima-saas-enterprise	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
210	weworkremotely	Enterprise Account Executive	Applied Systems	Remote		https://weworkremotely.com/remote-jobs/applied-systems-enterprise-account-executive	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
211	weworkremotely	Senior DevSecOps Engineer	Element 84	Remote		https://weworkremotely.com/remote-jobs/element-84-senior-devsecops-engineer	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
212	weworkremotely	Product Engineer (100% Remote)	17d	Remote		https://weworkremotely.com/remote-jobs/tether-product-engineer-100-remote	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
213	weworkremotely	Product Developer / Engineer @ Fun Ecom Co | Great People & Flexible Hours	19d	Remote		https://weworkremotely.com/remote-jobs/jls-trading-co-product-developer-engineer-fun-ecom-co-great-people	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
214	weworkremotely	Werkstudent für Verkehrsdatenanalyse (m/w/d)	23d	Remote		https://weworkremotely.com/remote-jobs/ptv-group-werkstudent-fur-verkehrsdatenanalyse-m-w-d	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
215	weworkremotely	Director of Sales – Platform Revenue (SaaS | ERP + Labor Management + Payments)	23d	Remote		https://weworkremotely.com/remote-jobs/silo-director-of-sales-platform-revenue-saas-erp-labor-management-payments	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
216	weworkremotely	Sr. Oracle SCM Functional Specialist, Global SaaS & Apps Delivery	23d	Remote		https://weworkremotely.com/remote-jobs/oracle-sr-oracle-scm-functional-specialist-global-saas-apps-delivery	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
217	weworkremotely	Enterprise Account Executive (Remote)	23d	Remote		https://weworkremotely.com/remote-jobs/visit-org-enterprise-account-executive-remote	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
218	weworkremotely	Client Support Supervisor	23d	Remote		https://weworkremotely.com/remote-jobs/soma-global-client-support-supervisor	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
219	weworkremotely	Product Lead (Contract)	26d	Remote		https://weworkremotely.com/remote-jobs/jumpspeak-product-lead-contract	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
220	weworkremotely	QA Analyst	29d	Remote		https://weworkremotely.com/remote-jobs/wealthbox-crm-qa-analyst	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
221	weworkremotely	Senior Account Executive – Aviation & Compliance SaaS (Remote)	29d	Remote		https://weworkremotely.com/remote-jobs/urrly-senior-account-executive-aviation-compliance-saas-remote	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
222	weworkremotely	Sales Manager - Senior	30d	Remote		https://weworkremotely.com/remote-jobs/softswiss-sales-manager-senior	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
223	weworkremotely	Senior Account Executive, SaaS, Remote	30d	Remote		https://weworkremotely.com/remote-jobs/planet-green-search-senior-account-executive-saas-remote	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
224	weworkremotely	Business Development Representative (SaaS)	29d	Remote		https://weworkremotely.com/remote-jobs/team-satchel-business-development-representative-saas	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
225	weworkremotely	Managing Director - FP&A SaaS - Private Equity Advisory	30d	Remote		https://weworkremotely.com/remote-jobs/crosscountry-consulting-managing-director-fp-a-saas-private-equity-advisory	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
226	weworkremotely	Project Manager	16d	Remote		https://weworkremotely.com/remote-jobs/spiralyze-project-manager	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
227	weworkremotely	Development Manager	19d	Remote		https://weworkremotely.com/remote-jobs/wpforms-development-manager	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
228	weworkremotely	Vice President, Commercial Underwriting - Resort Finance	New	Remote		https://weworkremotely.com/remote-jobs/western-alliance-bank-vice-president-commercial-underwriting-resort-finance	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
229	weworkremotely	Manager, Financial Information Systems (Remote)	New	Remote		https://weworkremotely.com/remote-jobs/ryan-manager-financial-information-systems-remote	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
230	weworkremotely	Engineering Technician - Lift and Crane Talent Pool	New	Remote		https://weworkremotely.com/remote-jobs/allianz-engineering-technician-lift-and-crane-talent-pool	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
231	weworkremotely	CX Global Account Manager | Financial Svs | US Virtual	New	Remote		https://weworkremotely.com/remote-jobs/avaya-avaya-cx-global-account-manager-financial-svs-us-virtual	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
232	weworkremotely	Market Area Manager - Hempstead, NY	New	Remote		https://weworkremotely.com/remote-jobs/credit-acceptance-corporation-market-area-manager-hempstead-ny	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
233	weworkremotely	Accountant	Xenali	Remote		https://weworkremotely.com/remote-jobs/xenali-accountant	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
234	weworkremotely	Procurement & Purchasing Specialist	Xenali	Remote		https://weworkremotely.com/remote-jobs/xenali-procurement-purchasing-specialist	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
235	weworkremotely	Dealer Relationship Manager - CO/NM	Axos Bank	Remote		https://weworkremotely.com/remote-jobs/axos-bank-dealer-relationship-manager-co-nm	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
236	weworkremotely	Virtual Banker - Evenings	OneMCI	Remote		https://weworkremotely.com/remote-jobs/onemci-virtual-banker-evenings	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
237	weworkremotely	Life Insurance Sales Agent	Peterson Agency	Remote		https://weworkremotely.com/remote-jobs/peterson-agency-life-insurance-sales-agent-2	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
238	weworkremotely	Senior Advisor, Supervision- Supervisory Solutions	Raymond James	Remote		https://weworkremotely.com/remote-jobs/raymond-james-senior-advisor-supervision-supervisory-solutions	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
239	weworkremotely	Finance & Accounting Manager	Rippleworks	Remote		https://weworkremotely.com/remote-jobs/rippleworks-finance-accounting-manager	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
240	weworkremotely	Transformation Executive Senior Director (Financial Services Sector) Remote	NTT Data	Remote		https://weworkremotely.com/remote-jobs/ntt-data-transformation-executive-senior-director-financial-services-sector-remote	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
241	weworkremotely	Finance Manager	Compass Group	Remote		https://weworkremotely.com/remote-jobs/compass-group-finance-manager	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
242	weworkremotely	Virtual Insurance Customer Service Representative- NO COLD CALLS / Work from Home	Meron Financial Agency	Remote		https://weworkremotely.com/remote-jobs/meron-financial-agency-virtual-insurance-customer-service-representative-no-cold-calls-work-from-home	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
243	weworkremotely	Future Opportunities	Monarch Money	Remote		https://weworkremotely.com/remote-jobs/monarch-money-future-opportunities	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
244	weworkremotely	SAP Finance (FI/CO) Migration Architect (m/w/d)	Natuvion	Remote		https://weworkremotely.com/remote-jobs/natuvion-sap-finance-fi-co-migration-architect-m-w-d	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
245	weworkremotely	Vice President of Finance (Remote US)	Maximus Health	Remote		https://weworkremotely.com/remote-jobs/maximus-health-vice-president-of-finance-remote-us	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
246	weworkremotely	Remote Stock & Options Trader (Funded Capital Program)	12d	Remote		https://weworkremotely.com/remote-jobs/maverick-trading-remote-stock-options-trader-funded-capital-program	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
247	weworkremotely	VP, Regional Wealth Management Consultant	13d	Remote		https://weworkremotely.com/remote-jobs/american-century-investments-vp-regional-wealth-management-consultant	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
248	weworkremotely	Manager, Finance & Strategy - Product Finance	13d	Remote		https://weworkremotely.com/remote-jobs/doordash-usa-manager-finance-strategy-product-finance	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
249	weworkremotely	Healthcare Managed Care and Financial Strategy , Managing Consultant	13d	Remote		https://weworkremotely.com/remote-jobs/guidehouse-healthcare-managed-care-and-financial-strategy-managing-consultant	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
250	weworkremotely	Bilingual Financial Customer Service Representative - April 2026	13d	Remote		https://weworkremotely.com/remote-jobs/empower-retirement-bilingual-financial-customer-service-representative-april-2026	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
251	remotive	Software Development	Remotive	Remote		https://remotive.com/remote-jobs/software-development	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
252	remotive	Customer Service	Remotive	Remote		https://remotive.com/remote-jobs/customer-service	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
253	remotive	Design	Remotive	Remote		https://remotive.com/remote-jobs/design	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
254	remotive	Marketing	Remotive	Remote		https://remotive.com/remote-jobs/marketing	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
255	remotive	Sales / Business	Remotive	Remote		https://remotive.com/remote-jobs/sales-business	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
256	remotive	Product	Remotive	Remote		https://remotive.com/remote-jobs/product	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
257	remotive	Project Management	Remotive	Remote		https://remotive.com/remote-jobs/project-management	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
258	remotive	AI / ML	Remotive	Remote		https://remotive.com/remote-jobs/ai-ml	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
259	remotive	Data Analysis	Remotive	Remote		https://remotive.com/remote-jobs/data	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
260	remotive	Devops / Sysadmin	Remotive	Remote		https://remotive.com/remote-jobs/devops	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
261	remotive	Finance	Remotive	Remote		https://remotive.com/remote-jobs/finance	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
262	remotive	Human Resources	Remotive	Remote		https://remotive.com/remote-jobs/human-resources	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
263	remotive	Writing	Remotive	Remote		https://remotive.com/remote-jobs/writing	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
264	remotive	Medical	Remotive	Remote		https://remotive.com/remote-jobs/medical	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
265	remotive	Education	Remotive	Remote		https://remotive.com/remote-jobs/education	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
266	remotive	All Others	Remotive	Remote		https://remotive.com/remote-jobs/all-others	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
267	remotive	Remotive Jobs Public API	RSS Feeds	Remote		https://remotive.com/remote-jobs/api	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
268	remotive	RSS Feeds	Remotive Jobs Public API	Remote		https://remotive.com/remote-jobs/rss-feed	2026-02-08 13:58:04.782072	2026-02-08 13:58:04.782072	t
890	remoteok_api	Licensed Professional Counselor	Brave Health		recruiter, support, growth, video, education, senior, medical, health, healthcare	https://remoteok.comhttps://remoteOK.com/remote-jobs/remote-licensed-professional-counselor-brave-health-1130039	2026-02-08 21:45:54.384296	2026-02-08 21:45:54.384296	t
891	remoteok_api	Staff Frontend Engineer	Alpaca		frontend, design, crypto, react, technical, strategist, developer, financial, investment, api, leader, strategy, engineer, engineering, digital nomad	https://remoteok.comhttps://remoteOK.com/remote-jobs/remote-staff-frontend-engineer-alpaca-1130038	2026-02-08 21:45:54.384296	2026-02-08 21:45:54.384296	t
892	remoteok_api	Product Director Cards	Crypto.com	United States	director, crypto, cryptocurrency, support, financial, management, recruitment	https://remoteok.comhttps://remoteOK.com/remote-jobs/remote-product-director-cards-crypto-com-1130037	2026-02-08 21:45:54.384296	2026-02-08 21:45:54.384296	t
893	remoteok_api	Software Engineer	OneStudyTeam	United States	software, technical, developer, code, lead, excel, health, engineer, digital nomad	https://remoteok.comhttps://remoteOK.com/remote-jobs/remote-software-engineer-onestudyteam-1130036	2026-02-08 21:45:54.384296	2026-02-08 21:45:54.384296	t
894	remoteok_api	Job 27268 Mid level DDL DML Developer Brazil	CI&amp;T	Brazil	developer, design, software, cloud, digital nomad	https://remoteok.comhttps://remoteOK.com/remote-jobs/remote-job-27268-mid-level-ddl-dml-developer-brazil-ciampt-1130035	2026-02-08 21:45:54.384296	2026-02-08 21:45:54.384296	t
895	remoteok_api	Social Media Manager Platform	Digital Media Management	United States	manager, training, copywriting, growth, video, strategy, exec, management, content, marketing, analytics, health	https://remoteok.comhttps://remoteOK.com/remote-jobs/remote-social-media-manager-platform-digital-media-management-1130034	2026-02-08 21:45:54.384296	2026-02-08 21:45:54.384296	t
896	remoteok_api	Social Media Manager Temporary	Digital Media Management	United States	manager, copywriting, growth, video, strategy, exec, management, content, marketing, analytics	https://remoteok.comhttps://remoteOK.com/remote-jobs/remote-social-media-manager-temporary-digital-media-management-1130033	2026-02-08 21:45:54.384296	2026-02-08 21:45:54.384296	t
897	remoteok_api	Job 27246 DevOps Strategy &amp; Culture Lead Brazil	CI&amp;T	Brazil	design, consulting, technical, support, developer, code, devops, cloud, api, strategy, lead, reliability, health, engineering, executive, digital nomad	https://remoteok.comhttps://remoteOK.com/remote-jobs/remote-job-27246-devops-strategy-amp-culture-lead-brazil-ciampt-1130032	2026-02-08 21:45:54.384296	2026-02-08 21:45:54.384296	t
898	remoteok_api	Pre Sales Engineer	Ajax Systems	Guadalajara	design, security, technical, support, software, test, travel, manager, video, git, sales, engineer, digital nomad	https://remoteok.comhttps://remoteOK.com/remote-jobs/remote-pre-sales-engineer-ajax-systems-1130031	2026-02-08 21:45:54.384296	2026-02-08 21:45:54.384296	t
899	remoteok_api	Senior Full Stack Engineer Ruby React	Ubiminds	Remote	react, design, system, support, software, testing, code, devops, ruby, admin, senior, engineer, engineering, backend, digital nomad	https://remoteok.comhttps://remoteOK.com/remote-jobs/remote-senior-full-stack-engineer-ruby-react-ubiminds-1130030	2026-02-08 21:45:54.384296	2026-02-08 21:45:54.384296	t
900	remoteok_api	Social Media Analyst Platform	Digital Media Management	United States	analyst, training, support, growth, video, strategy, exec, management, lead, marketing, analytics, health	https://remoteok.comhttps://remoteOK.com/remote-jobs/remote-social-media-analyst-platform-digital-media-management-1130029	2026-02-08 21:45:54.384296	2026-02-08 21:45:54.384296	t
901	arbeitnow	Cloud Engineer mit Karriereambitionen - jetzt mit uns voll durchstarten!	Auralis Group	Grünwald	Remote, System and Network Administration	https://www.arbeitnow.com/jobs/companies/auralis-group/cloud-engineer-mit-karriereambitionen-jetzt-mit-uns-voll-durchstarten-grunwald-2685	2026-02-08 21:45:54.384296	2026-02-08 21:45:54.384296	t
902	arbeitnow	Betriebsleiter / Klimatechnikermeister (m/w/d) - Deutschlandweiter Aufbau	Eneto GmbH	Berlin	Remote, Engineering	https://www.arbeitnow.com/jobs/companies/eneto-gmbh/betriebsleiter-klimatechnikermeister-deutschlandweiter-aufbau-berlin-143221	2026-02-08 21:45:54.384296	2026-02-08 21:45:54.384296	t
903	arbeitnow	Marketing Student	SolarEdge	Munich	Remote	https://www.arbeitnow.com/jobs/companies/solaredge/remote-marketing-student-munich-370408	2026-02-08 21:45:54.384296	2026-02-08 21:45:54.384296	t
904	arbeitnow	Senior Solutions Architect	Automat-it	Munich	Remote	https://www.arbeitnow.com/jobs/companies/automat-it/remote-senior-solutions-architect-munich-14575	2026-02-08 21:45:54.384296	2026-02-08 21:45:54.384296	t
906	arbeitnow	Senior Solutions Architect	Automat-it	Berlin	Remote	https://www.arbeitnow.com/jobs/companies/automat-it/remote-senior-solutions-architect-berlin-321927	2026-02-08 21:45:54.384296	2026-02-08 21:45:54.384296	t
907	arbeitnow	Marketing Student	SolarEdge	Munich	Remote	https://www.arbeitnow.com/jobs/companies/solaredge/remote-marketing-student-munich-399572	2026-02-08 21:45:54.384296	2026-02-08 21:45:54.384296	t
908	arbeitnow	AI Marketing Growth Hacker (m/w/d)	Endo Health GmbH	Chemnitz	Remote, Online Marketing	https://www.arbeitnow.com/jobs/companies/endo-health-gmbh/ai-marketing-growth-hacker-chemnitz-55662	2026-02-08 21:45:54.384296	2026-02-08 21:45:54.384296	t
909	arbeitnow	Werkstudent / Praktikant (m/w/d) - Technische Dokumentation ERP-Prozesse (Odoo)	Lakefields GmbH	Gottmadingen	Remote, IT	https://www.arbeitnow.com/jobs/companies/lakefields-gmbh/werkstudent-praktikant-technische-dokumentation-erp-prozesse-odoo-gottmadingen-231944	2026-02-08 21:45:54.384296	2026-02-08 21:45:54.384296	t
910	arbeitnow	Senior Backend Engineer - AI Agents - Climate Tech (all genders)	Global Changer	Berlin	Remote, Data Scientist	https://www.arbeitnow.com/jobs/companies/global-changer/senior-backend-engineer-ai-agents-all-genders-climate-tech-berlin-297346	2026-02-08 21:45:54.384296	2026-02-08 21:45:54.384296	t
911	arbeitnow	UGC Engineer | Viral Marketing	Vyral Labs	Berlin	Remote, Social Media Manager	https://www.arbeitnow.com/jobs/companies/vyral-labs/ugc-engineer-viral-marketing-berlin-114215	2026-02-08 21:45:54.384296	2026-02-08 21:45:54.384296	t
912	arbeitnow	Technical Account Manager - DACH	SolarEdge	Munich	Remote	https://www.arbeitnow.com/jobs/companies/solaredge/remote-technical-account-manager-dach-munich-31540	2026-02-08 21:45:54.384296	2026-02-08 21:45:54.384296	t
913	arbeitnow	Technical Account Manager - DACH	SolarEdge	Munich	Remote	https://www.arbeitnow.com/jobs/companies/solaredge/remote-technical-account-manager-dach-munich-179823	2026-02-08 21:45:54.384296	2026-02-08 21:45:54.384296	t
914	arbeitnow	Recruiter / Personalberater (gn) - 100% remote - VZ oder TZ	Talent Partner GmbH	Munich	Remote, Recruitment and Selection	https://www.arbeitnow.com/jobs/companies/talent-partner-gmbh/recruiter-personalberater-gn-100-remote-vz-oder-tz-munich-472459	2026-02-08 21:45:54.384296	2026-02-08 21:45:54.384296	t
915	arbeitnow	(Senior) Campaign Manager (m/w/d) - Accounts mit großen Google Ads Budgets	Searchperts Deutschland GmbH	Düsseldorf	Remote, Online Marketing	https://www.arbeitnow.com/jobs/companies/searchperts-deutschland-gmbh/senior-sea-campaign-manager-accounts-mit-grossen-google-budgets-dusseldorf-200860	2026-02-08 21:45:54.384296	2026-02-08 21:45:54.384296	t
916	arbeitnow	HR Business Partnerin / HR Business Partner (m/w/d) | 100 % Ehrenamt | 100 % Remote | ca. 5-8 Stunden/Woche	Deutscher Hilfsbund e.V.	Berlin	Remote, Administration	https://www.arbeitnow.com/jobs/companies/deutscher-hilfsbund-ev/hr-business-partnerin-hr-business-partner-100-ehrenamt-100-remote-ca-5-8-stunden-woche-berlin-474746	2026-02-08 21:45:54.384296	2026-02-08 21:45:54.384296	t
917	arbeitnow	Content Manager (Website / Social Media) (m/w/d) | 100 % Ehrenamt | 100 % Remote | ca. 5-8 Stunden/Woche	Deutscher Hilfsbund e.V.	Berlin	Remote, Online Marketing	https://www.arbeitnow.com/jobs/companies/deutscher-hilfsbund-ev/content-manager-website-social-media-100-ehrenamt-100-remote-ca-5-8-stunden-woche-berlin-334782	2026-02-08 21:45:54.384296	2026-02-08 21:45:54.384296	t
918	arbeitnow	Technical Account Manager - DACH	SolarEdge	Munich	Remote	https://www.arbeitnow.com/jobs/companies/solaredge/remote-technical-account-manager-dach-munich-107517	2026-02-08 21:45:54.384296	2026-02-08 21:45:54.384296	t
919	arbeitnow	(Junior) Creative Strategist*in (m/w/d)	HEY HOLY GmbH	Frankfurt am Main	Remote, Marketing Manager	https://www.arbeitnow.com/jobs/companies/hey-holy-gmbh/junior-creative-strategistin-frankfurt-am-main-30014	2026-02-08 21:45:54.384296	2026-02-08 21:45:54.384296	t
920	arbeitnow	REMOTE Werkstudent (m/w/d) Business Operations & Content	Personal Now	Berlin	Remote, Business Development	https://www.arbeitnow.com/jobs/companies/personal-now/remote-werkstudent-business-operations-content-berlin-33859	2026-02-08 21:45:54.384296	2026-02-08 21:45:54.384296	t
921	arbeitnow	Software Developer - Full Stack	wisepex	Hagen	Remote, Software Development	https://www.arbeitnow.com/jobs/companies/wisepex/software-developer-full-stack-hagen-473559	2026-02-08 21:45:54.384296	2026-02-08 21:45:54.384296	t
922	arbeitnow	Software Developer - Angular	wisepex	Hagen	Remote, Software Development	https://www.arbeitnow.com/jobs/companies/wisepex/software-developer-angular-hagen-463506	2026-02-08 21:45:54.384296	2026-02-08 21:45:54.384296	t
1299	justremote	Remote Companies	Power Search	Remote		https://justremote.co/remote-companies	2026-02-08 21:54:59.878535	2026-02-08 21:54:59.878535	t
1300	justremote	List your position	JustRemote	Remote		https://justremote.co/remote-jobs/new	2026-02-08 21:54:59.878535	2026-02-08 21:54:59.878535	t
1301	justremote	Business/Exec	All	Remote		https://justremote.co/remote-manager-exec-jobs	2026-02-08 21:54:59.878535	2026-02-08 21:54:59.878535	t
1302	justremote	Customer Service	All	Remote		https://justremote.co/remote-customer-service-jobs	2026-02-08 21:54:59.878535	2026-02-08 21:54:59.878535	t
1303	justremote	Developer	All	Remote		https://justremote.co/remote-developer-jobs	2026-02-08 21:54:59.878535	2026-02-08 21:54:59.878535	t
1304	justremote	Devops & Sysadmin	All	Remote		https://justremote.co/remote-devops-sysadmin-jobs	2026-02-08 21:54:59.878535	2026-02-08 21:54:59.878535	t
1305	justremote	Design	All	Remote		https://justremote.co/remote-design-jobs	2026-02-08 21:54:59.878535	2026-02-08 21:54:59.878535	t
1306	justremote	Editing	All	Remote		https://justremote.co/remote-editing-jobs	2026-02-08 21:54:59.878535	2026-02-08 21:54:59.878535	t
1307	justremote	Marketing	All	Remote		https://justremote.co/remote-marketing-jobs	2026-02-08 21:54:59.878535	2026-02-08 21:54:59.878535	t
1308	justremote	Project Manager	All	Remote		https://justremote.co/remote-project-manager-jobs	2026-02-08 21:54:59.878535	2026-02-08 21:54:59.878535	t
1309	justremote	Recruiter	All	Remote		https://justremote.co/remote-recruiter-jobs	2026-02-08 21:54:59.878535	2026-02-08 21:54:59.878535	t
1310	justremote	Sales	All	Remote		https://justremote.co/remote-sales-jobs	2026-02-08 21:54:59.878535	2026-02-08 21:54:59.878535	t
1311	justremote	Social Media	All	Remote		https://justremote.co/remote-social-media-jobs	2026-02-08 21:54:59.878535	2026-02-08 21:54:59.878535	t
1312	justremote	Writing	All	Remote		https://justremote.co/remote-writing-jobs	2026-02-08 21:54:59.878535	2026-02-08 21:54:59.878535	t
1313	justremote	Australia	Austria	Remote		https://justremote.co/remote-jobs-in-australia	2026-02-08 21:54:59.878535	2026-02-08 21:54:59.878535	t
1314	justremote	Austria	Australia	Remote		https://justremote.co/remote-jobs-in-austria	2026-02-08 21:54:59.878535	2026-02-08 21:54:59.878535	t
1315	justremote	Belgium	Australia	Remote		https://justremote.co/remote-jobs-in-belgium	2026-02-08 21:54:59.878535	2026-02-08 21:54:59.878535	t
1316	justremote	Brazil	Australia	Remote		https://justremote.co/remote-jobs-in-brazil	2026-02-08 21:54:59.878535	2026-02-08 21:54:59.878535	t
1317	justremote	Canada	Australia	Remote		https://justremote.co/remote-jobs-in-canada	2026-02-08 21:54:59.878535	2026-02-08 21:54:59.878535	t
1318	justremote	China	Australia	Remote		https://justremote.co/remote-jobs-in-china	2026-02-08 21:54:59.878535	2026-02-08 21:54:59.878535	t
1319	justremote	Colombia	Australia	Remote		https://justremote.co/remote-jobs-in-colombia	2026-02-08 21:54:59.878535	2026-02-08 21:54:59.878535	t
1320	justremote	Denmark	Australia	Remote		https://justremote.co/remote-jobs-in-denmark	2026-02-08 21:54:59.878535	2026-02-08 21:54:59.878535	t
1321	justremote	Estonia	Australia	Remote		https://justremote.co/remote-jobs-in-estonia	2026-02-08 21:54:59.878535	2026-02-08 21:54:59.878535	t
1322	justremote	Finland	Australia	Remote		https://justremote.co/remote-jobs-in-finland	2026-02-08 21:54:59.878535	2026-02-08 21:54:59.878535	t
1323	justremote	France	Australia	Remote		https://justremote.co/remote-jobs-in-france	2026-02-08 21:54:59.878535	2026-02-08 21:54:59.878535	t
1324	justremote	Germany	Australia	Remote		https://justremote.co/remote-jobs-in-germany	2026-02-08 21:54:59.878535	2026-02-08 21:54:59.878535	t
1325	justremote	Greece	Australia	Remote		https://justremote.co/remote-jobs-in-greece	2026-02-08 21:54:59.878535	2026-02-08 21:54:59.878535	t
1326	justremote	Ireland	Australia	Remote		https://justremote.co/remote-jobs-in-ireland	2026-02-08 21:54:59.878535	2026-02-08 21:54:59.878535	t
1327	justremote	Italy	Australia	Remote		https://justremote.co/remote-jobs-in-italy	2026-02-08 21:54:59.878535	2026-02-08 21:54:59.878535	t
1328	justremote	Japan	Australia	Remote		https://justremote.co/remote-jobs-in-japan	2026-02-08 21:54:59.878535	2026-02-08 21:54:59.878535	t
1329	justremote	Latvia	Australia	Remote		https://justremote.co/remote-jobs-in-latvia	2026-02-08 21:54:59.878535	2026-02-08 21:54:59.878535	t
1330	justremote	Malta	Australia	Remote		https://justremote.co/remote-jobs-in-malta	2026-02-08 21:54:59.878535	2026-02-08 21:54:59.878535	t
1331	justremote	Netherlands	Australia	Remote		https://justremote.co/remote-jobs-in-netherlands	2026-02-08 21:54:59.878535	2026-02-08 21:54:59.878535	t
1332	justremote	Norway	Australia	Remote		https://justremote.co/remote-jobs-in-norway	2026-02-08 21:54:59.878535	2026-02-08 21:54:59.878535	t
1333	justremote	Poland	Australia	Remote		https://justremote.co/remote-jobs-in-poland	2026-02-08 21:54:59.878535	2026-02-08 21:54:59.878535	t
1334	justremote	Portugal	Australia	Remote		https://justremote.co/remote-jobs-in-portugal	2026-02-08 21:54:59.878535	2026-02-08 21:54:59.878535	t
1335	justremote	Romania	Australia	Remote		https://justremote.co/remote-jobs-in-romania	2026-02-08 21:54:59.878535	2026-02-08 21:54:59.878535	t
1336	justremote	Serbia	Australia	Remote		https://justremote.co/remote-jobs-in-serbia	2026-02-08 21:54:59.878535	2026-02-08 21:54:59.878535	t
1337	justremote	Spain	Australia	Remote		https://justremote.co/remote-jobs-in-spain	2026-02-08 21:54:59.878535	2026-02-08 21:54:59.878535	t
1338	justremote	Sweden	Australia	Remote		https://justremote.co/remote-jobs-in-sweden	2026-02-08 21:54:59.878535	2026-02-08 21:54:59.878535	t
1339	justremote	Ukraine	Australia	Remote		https://justremote.co/remote-jobs-in-ukraine	2026-02-08 21:54:59.878535	2026-02-08 21:54:59.878535	t
1340	justremote	United Kingdom	Australia	Remote		https://justremote.co/remote-jobs-in-united-kingdom	2026-02-08 21:54:59.878535	2026-02-08 21:54:59.878535	t
1341	justremote	United States	Australia	Remote		https://justremote.co/remote-jobs-in-united-states	2026-02-08 21:54:59.878535	2026-02-08 21:54:59.878535	t
1342	justremote	Vietnam	Australia	Remote		https://justremote.co/remote-jobs-in-vietnam	2026-02-08 21:54:59.878535	2026-02-08 21:54:59.878535	t
1343	justremote	Remote Copywriter Jobs	JustRemote	Remote		https://justremote.co/remote-copywriter-jobs	2026-02-08 21:54:59.878535	2026-02-08 21:54:59.878535	t
1344	powertofly	Deals - Financial Due Diligence, Manager - East	PowerToFly	Remote		https://powertofly.com/jobs/detail/2448578	2026-02-08 21:54:59.878535	2026-02-08 21:54:59.878535	t
1345	powertofly	Financial Due Diligence	PowerToFly	Remote		https://powertofly.com/jobs/?keywords=Financial+Due+Diligence	2026-02-08 21:54:59.878535	2026-02-08 21:54:59.878535	t
1346	powertofly	Mergers and Acquisitions	PowerToFly	Remote		https://powertofly.com/jobs/?keywords=Mergers+and+Acquisitions	2026-02-08 21:54:59.878535	2026-02-08 21:54:59.878535	t
1347	powertofly	Divestitures	PowerToFly	Remote		https://powertofly.com/jobs/?keywords=Divestitures	2026-02-08 21:54:59.878535	2026-02-08 21:54:59.878535	t
1348	powertofly	Restructuring	PowerToFly	Remote		https://powertofly.com/jobs/?keywords=Restructuring	2026-02-08 21:54:59.878535	2026-02-08 21:54:59.878535	t
1349	powertofly	Analyzing financial information	PowerToFly	Remote		https://powertofly.com/jobs/?keywords=Analyzing+financial+information	2026-02-08 21:54:59.878535	2026-02-08 21:54:59.878535	t
1350	powertofly	Quality of earnings	PowerToFly	Remote		https://powertofly.com/jobs/?keywords=Quality+of+earnings	2026-02-08 21:54:59.878535	2026-02-08 21:54:59.878535	t
1351	linkedin	Digital Designer	LinkedIn	Remote		https://www.linkedin.com/jobs/view/digital-designer-at-under-armour-4370344497?position=1&pageNum=0&refId=nn04ido2XDmtkZ7tlel4kA%3D%3D&trackingId=SQ2ZW%2BX%2Bdw3%2FGo5DvRjOqw%3D%3D	2026-02-08 21:54:59.878535	2026-02-08 21:54:59.878535	t
1352	linkedin	Sr. Recruiter	LinkedIn	Remote		https://www.linkedin.com/jobs/view/sr-recruiter-at-petdesk-4369974104?position=2&pageNum=0&refId=nn04ido2XDmtkZ7tlel4kA%3D%3D&trackingId=WXVYdNAr%2BUpb4FRuTwGQ3A%3D%3D	2026-02-08 21:54:59.878535	2026-02-08 21:54:59.878535	t
1353	linkedin	Tutors Needed for All Subjects and Test Prep	LinkedIn	Remote		https://www.linkedin.com/jobs/view/tutors-needed-for-all-subjects-and-test-prep-at-connectprep-4369979535?position=3&pageNum=0&refId=nn04ido2XDmtkZ7tlel4kA%3D%3D&trackingId=%2BemmEDSuABcKuzMk%2BPUR6g%3D%3D	2026-02-08 21:54:59.878535	2026-02-08 21:54:59.878535	t
1354	linkedin	HR Operations Specialist | Remote	LinkedIn	Remote		https://www.linkedin.com/jobs/view/hr-operations-specialist-remote-at-crossing-hurdles-4369897975?position=4&pageNum=0&refId=nn04ido2XDmtkZ7tlel4kA%3D%3D&trackingId=PNsmMJa0ZoEfJDLA2%2FHEcw%3D%3D	2026-02-08 21:54:59.878535	2026-02-08 21:54:59.878535	t
1355	linkedin	Relationship Manager - Remote	LinkedIn	Remote		https://www.linkedin.com/jobs/view/relationship-manager-remote-at-experian-4363721538?position=5&pageNum=0&refId=nn04ido2XDmtkZ7tlel4kA%3D%3D&trackingId=ybGzrkZg9c7vHKUzIC9Yxw%3D%3D	2026-02-08 21:54:59.878535	2026-02-08 21:54:59.878535	t
1356	linkedin	Designer, Accolades	LinkedIn	Remote		https://www.linkedin.com/jobs/view/designer-accolades-at-forbes-4369959800?position=6&pageNum=0&refId=nn04ido2XDmtkZ7tlel4kA%3D%3D&trackingId=K1ahzcupM8qm3fNCXN%2BYLA%3D%3D	2026-02-08 21:54:59.878535	2026-02-08 21:54:59.878535	t
1357	linkedin	Marketing Data Analyst, Accolades	LinkedIn	Remote		https://www.linkedin.com/jobs/view/marketing-data-analyst-accolades-at-forbes-4369978050?position=7&pageNum=0&refId=nn04ido2XDmtkZ7tlel4kA%3D%3D&trackingId=xeXyAkdm18%2BwsEX%2BfEih8w%3D%3D	2026-02-08 21:54:59.878535	2026-02-08 21:54:59.878535	t
1358	linkedin	Data Entry Specialist - Medical Records (Remote)	LinkedIn	Remote		https://www.linkedin.com/jobs/view/data-entry-specialist-medical-records-remote-at-lensa-4370302396?position=8&pageNum=0&refId=nn04ido2XDmtkZ7tlel4kA%3D%3D&trackingId=TFPqgm29Xt6MID%2F8lf42gw%3D%3D	2026-02-08 21:54:59.878535	2026-02-08 21:54:59.878535	t
1359	linkedin	HR Manager	LinkedIn	Remote		https://www.linkedin.com/jobs/view/hr-manager-at-alliance-for-justice-4369939879?position=9&pageNum=0&refId=nn04ido2XDmtkZ7tlel4kA%3D%3D&trackingId=Bio3DUknS5dJa0PeC4UA9A%3D%3D	2026-02-08 21:54:59.878535	2026-02-08 21:54:59.878535	t
1360	linkedin	HR Administrative Assistant	LinkedIn	Remote		https://www.linkedin.com/jobs/view/hr-administrative-assistant-at-orchestrate-consulting-group-4370088004?position=10&pageNum=0&refId=nn04ido2XDmtkZ7tlel4kA%3D%3D&trackingId=igMcm0lfnZtkmpOkhM%2Fjqw%3D%3D	2026-02-08 21:54:59.878535	2026-02-08 21:54:59.878535	t
1361	linkedin	Procurement Coordinator | Remote	LinkedIn	Remote		https://www.linkedin.com/jobs/view/procurement-coordinator-remote-at-crossing-hurdles-4370074759?position=11&pageNum=0&refId=nn04ido2XDmtkZ7tlel4kA%3D%3D&trackingId=4XXwXHVG8aYj%2BDGYymM0xA%3D%3D	2026-02-08 21:54:59.878535	2026-02-08 21:54:59.878535	t
1362	linkedin	Remote Scheduler	LinkedIn	Remote		https://www.linkedin.com/jobs/view/remote-scheduler-at-qp-group-4369814867?position=12&pageNum=0&refId=nn04ido2XDmtkZ7tlel4kA%3D%3D&trackingId=EaxCAJnIrleWJ2a49np6yA%3D%3D	2026-02-08 21:54:59.878535	2026-02-08 21:54:59.878535	t
1363	linkedin	REMOTE - HR Representative	LinkedIn	Remote		https://www.linkedin.com/jobs/view/remote-hr-representative-at-lensa-4370300398?position=13&pageNum=0&refId=nn04ido2XDmtkZ7tlel4kA%3D%3D&trackingId=GYLPckU32EiLGEuCC%2Bl5cA%3D%3D	2026-02-08 21:54:59.878535	2026-02-08 21:54:59.878535	t
1364	linkedin	Casting Director, UGC Creators	LinkedIn	Remote		https://www.linkedin.com/jobs/view/casting-director-ugc-creators-at-everyday-dose-4370175989?position=14&pageNum=0&refId=nn04ido2XDmtkZ7tlel4kA%3D%3D&trackingId=ohVJeNJIyEuDLDoa7O%2BNDw%3D%3D	2026-02-08 21:54:59.878535	2026-02-08 21:54:59.878535	t
1365	linkedin	Procurement Specialist | Remote	LinkedIn	Remote		https://www.linkedin.com/jobs/view/procurement-specialist-remote-at-crossing-hurdles-4370086489?position=15&pageNum=0&refId=nn04ido2XDmtkZ7tlel4kA%3D%3D&trackingId=8nv4HW3qyLpSCstiUEWlIw%3D%3D	2026-02-08 21:54:59.878535	2026-02-08 21:54:59.878535	t
1366	linkedin	Human Resources Assistant	LinkedIn	Remote		https://www.linkedin.com/jobs/view/human-resources-assistant-at-helic-co-4369779431?position=16&pageNum=0&refId=nn04ido2XDmtkZ7tlel4kA%3D%3D&trackingId=aFFYzoBsO9N2V7zawA4JXA%3D%3D	2026-02-08 21:54:59.878535	2026-02-08 21:54:59.878535	t
1367	linkedin	Proofreader/Copy Editor (Remote, Contract)	LinkedIn	Remote		https://www.linkedin.com/jobs/view/proofreader-copy-editor-remote-contract-at-infuse-4370168641?position=17&pageNum=0&refId=nn04ido2XDmtkZ7tlel4kA%3D%3D&trackingId=4EdN%2FHH8T1fnbMeKBYzdwA%3D%3D	2026-02-08 21:54:59.878535	2026-02-08 21:54:59.878535	t
1368	linkedin	Tutors Needed for All Subjects and Test Prep	LinkedIn	Remote		https://www.linkedin.com/jobs/view/tutors-needed-for-all-subjects-and-test-prep-at-connectprep-4369976628?position=18&pageNum=0&refId=nn04ido2XDmtkZ7tlel4kA%3D%3D&trackingId=zI1FmpI9l3hi340VkrpM%2FQ%3D%3D	2026-02-08 21:54:59.878535	2026-02-08 21:54:59.878535	t
1369	linkedin	Staff Writer, Education	LinkedIn	Remote		https://www.linkedin.com/jobs/view/staff-writer-education-at-forbes-4364041274?position=19&pageNum=0&refId=nn04ido2XDmtkZ7tlel4kA%3D%3D&trackingId=fhvwcq9NoZLQW1Ux1qT05g%3D%3D	2026-02-08 21:54:59.878535	2026-02-08 21:54:59.878535	t
1370	linkedin	Director, Customer Experience	LinkedIn	Remote		https://www.linkedin.com/jobs/view/director-customer-experience-at-alma-4363755133?position=20&pageNum=0&refId=nn04ido2XDmtkZ7tlel4kA%3D%3D&trackingId=c9cvprVdhP3sMiJq6L07Ng%3D%3D	2026-02-08 21:54:59.878535	2026-02-08 21:54:59.878535	t
1371	linkedin	Talent Coordinator (Remote)	LinkedIn	Remote		https://www.linkedin.com/jobs/view/talent-coordinator-remote-at-lensa-4370195546?position=21&pageNum=0&refId=nn04ido2XDmtkZ7tlel4kA%3D%3D&trackingId=%2BIzRLl%2BDz4JruXN4CWhKBw%3D%3D	2026-02-08 21:54:59.878535	2026-02-08 21:54:59.878535	t
1372	linkedin	File Clerk | Remote	LinkedIn	Remote		https://www.linkedin.com/jobs/view/file-clerk-remote-at-crossing-hurdles-4370069658?position=22&pageNum=0&refId=nn04ido2XDmtkZ7tlel4kA%3D%3D&trackingId=CPlRPdMKGCm8SNuH6Lfldg%3D%3D	2026-02-08 21:54:59.878535	2026-02-08 21:54:59.878535	t
1373	linkedin	Purchasing Associate | Remote	LinkedIn	Remote		https://www.linkedin.com/jobs/view/purchasing-associate-remote-at-crossing-hurdles-4370070813?position=23&pageNum=0&refId=nn04ido2XDmtkZ7tlel4kA%3D%3D&trackingId=IwjXom9i%2Btf9NBhLUwxa%2BQ%3D%3D	2026-02-08 21:54:59.878535	2026-02-08 21:54:59.878535	t
1374	linkedin	Senior Manager of Talent Acquisition	LinkedIn	Remote		https://www.linkedin.com/jobs/view/senior-manager-of-talent-acquisition-at-karbon-4369906209?position=24&pageNum=0&refId=nn04ido2XDmtkZ7tlel4kA%3D%3D&trackingId=510QsF3Dz98RpwqH2Ot0lw%3D%3D	2026-02-08 21:54:59.878535	2026-02-08 21:54:59.878535	t
1375	linkedin	Creator - Short Form Video - TikTok/Instagram/Meta - Contract	LinkedIn	Remote		https://www.linkedin.com/jobs/view/creator-short-form-video-tiktok-instagram-meta-contract-at-sola-wood-flowers-4369832417?position=25&pageNum=0&refId=nn04ido2XDmtkZ7tlel4kA%3D%3D&trackingId=uC2MFQVwnJIQ6ygAOuTdyw%3D%3D	2026-02-08 21:54:59.878535	2026-02-08 21:54:59.878535	t
1376	linkedin	Medical Scheduler (Remote)	LinkedIn	Remote		https://www.linkedin.com/jobs/view/medical-scheduler-remote-at-cyber-focus-ai-4370082149?position=26&pageNum=0&refId=nn04ido2XDmtkZ7tlel4kA%3D%3D&trackingId=huDbxAUC%2ByxyFZOL1wXWMw%3D%3D	2026-02-08 21:54:59.878535	2026-02-08 21:54:59.878535	t
1377	linkedin	Human Resources Specialist (Healthcare)	LinkedIn	Remote		https://www.linkedin.com/jobs/view/human-resources-specialist-healthcare-at-tammira-4369892240?position=27&pageNum=0&refId=nn04ido2XDmtkZ7tlel4kA%3D%3D&trackingId=Ha3Koes2%2FHoKbuUSTBnFWA%3D%3D	2026-02-08 21:54:59.878535	2026-02-08 21:54:59.878535	t
1378	remoteok_api	Talent Development Manager CDD	Pennylane	Paris	manager, hr, system, training, technical, recruiter, support, software, test, growth, accounting, financial, finance, management, lead, legal, healthcare	https://remoteok.comhttps://remoteOK.com/remote-jobs/remote-talent-development-manager-cdd-pennylane-1130151	2026-02-10 10:30:04.33236	2026-02-10 10:30:04.33236	t
1379	remoteok_api	Account Executive Southeast Region DroneSense	Versaterm		growth, operational, marketing, sales, engineering, executive	https://remoteok.comhttps://remoteOK.com/remote-jobs/remote-account-executive-southeast-region-dronesense-versaterm-1130150	2026-02-10 10:30:04.33236	2026-02-10 10:30:04.33236	t
1380	remoteok_api	Business Development Executive	Halter	Manawatu	support, growth, travel, manager, lead, operations, sales, health, executive	https://remoteok.comhttps://remoteOK.com/remote-jobs/remote-business-development-executive-halter-1130149	2026-02-10 10:30:04.33236	2026-02-10 10:30:04.33236	t
1381	remoteok_api	Customer Success Manager DroneSense	Versaterm		manager, support, growth, operations, operational	https://remoteok.comhttps://remoteOK.com/remote-jobs/remote-customer-success-manager-dronesense-versaterm-1130148	2026-02-10 10:30:04.33236	2026-02-10 10:30:04.33236	t
1382	remoteok_api	DevSecOps Engineer DroneSense	Versaterm	U.S.	security, growth, devops, engineer, engineering	https://remoteok.comhttps://remoteOK.com/remote-jobs/remote-devsecops-engineer-dronesense-versaterm-1130147	2026-02-10 10:30:04.33236	2026-02-10 10:30:04.33236	t
1383	remoteok_api	Matillion Enterprise Account Executive Saudi Arabia	Matillion	Dubai	support, growth, sales, executive	https://remoteok.comhttps://remoteOK.com/remote-jobs/remote-matillion-enterprise-account-executive-saudi-arabia-matillion-1130144	2026-02-10 10:30:04.33236	2026-02-10 10:30:04.33236	t
1384	remoteok_api	Wing Assistant Sales & Onboarding Specialist	Wing	Manila	assistant, technical, support, sales	https://remoteok.comhttps://remoteOK.com/remote-jobs/remote-wing-assistant-sales-onboarding-specialist-wing-1130143	2026-02-10 10:30:04.33236	2026-02-10 10:30:04.33236	t
1385	remoteok_api	Partner Sales Manager	Acceldata		manager, saas, salesforce, system, technical, support, travel, cloud, microsoft, leader, strategy, lead, marketing, excel, sales, executive	https://remoteok.comhttps://remoteOK.com/remote-jobs/remote-partner-sales-manager-acceldata-1130142	2026-02-10 10:30:04.33236	2026-02-10 10:30:04.33236	t
1386	remoteok_api	Carrier Messaging Compliance Lead	EZTexting		training, code, education, mobile, leader, management, lead, operations, operational, marketing, non tech	https://remoteok.comhttps://remoteOK.com/remote-jobs/remote-carrier-messaging-compliance-lead-eztexting-1130141	2026-02-10 10:30:04.33236	2026-02-10 10:30:04.33236	t
1387	remoteok_api	Launch Operations Lead	Arketa	Mexico City	saas, technical, support, manager, lead, operations, operational, reliability, go, engineering	https://remoteok.comhttps://remoteOK.com/remote-jobs/remote-launch-operations-lead-arketa-1130140	2026-02-10 10:30:04.33236	2026-02-10 10:30:04.33236	t
1388	remoteok_api	Senior DevOps Engineer	Anduril Industries	Reston	ansible, system, security, 3d, software, testing, code, devops, lead, senior, operations, engineer, engineering	https://remoteok.comhttps://remoteOK.com/remote-jobs/remote-senior-devops-engineer-anduril-industries-1130139	2026-02-10 10:30:04.33236	2026-02-10 10:30:04.33236	t
877	remoteok_api	Complaint Analyst USA	Calyxo		analyst, system, management, sales, healthcare	https://remoteok.comhttps://remoteOK.com/remote-jobs/remote-complaint-analyst-usa-calyxo-1130054	2026-02-10 10:30:04.33236	2026-02-08 21:45:54.384296	t
805	remoteok_api	Growth Marketing Lead	Gaia Family Inc		growth, testing, manager, financial, ads, lead, content, operations, marketing	https://remoteok.comhttps://remoteOK.com/remote-jobs/remote-growth-marketing-lead-gaia-family-inc-1130138	2026-02-10 10:30:04.33236	2026-02-08 21:45:54.384296	t
806	remoteok_api	Social Media Specialist	MyShell	APAC	growth, video, content, marketing	https://remoteok.comhttps://remoteOK.com/remote-jobs/remote-social-media-specialist-myshell-1130137	2026-02-10 10:30:04.33236	2026-02-08 21:45:54.384296	t
807	remoteok_api	Senior Data Engineer	Lalamove	Kuala Lumpur	technical, support, java, senior, operations, engineer, engineering, linux	https://remoteok.comhttps://remoteOK.com/remote-jobs/remote-senior-data-engineer-lalamove-1130136	2026-02-10 10:30:04.33236	2026-02-08 21:45:54.384296	t
808	remoteok_api	Senior Web Developer	Coin Market Cap Ltd		developer, web, crypto, cryptocurrency, technical, support, code, typescript, mobile, senior, digital nomad	https://remoteok.comhttps://remoteOK.com/remote-jobs/remote-senior-web-developer-coin-market-cap-ltd-1130135	2026-02-10 10:30:04.33236	2026-02-08 21:45:54.384296	t
809	remoteok_api	Sales Specialist Arbitrage and Quant	Kpler	Singapore	support, growth, financial, management, lead, senior, sales	https://remoteok.comhttps://remoteOK.com/remote-jobs/remote-sales-specialist-arbitrage-and-quant-kpler-1130134	2026-02-10 10:30:04.33236	2026-02-08 21:45:54.384296	t
810	remoteok_api	Technical Support Engineer Singapore	Dataiku	Singapore	technical, support, growth, engineer, engineering	https://remoteok.comhttps://remoteOK.com/remote-jobs/remote-technical-support-engineer-singapore-dataiku-1130133	2026-02-10 10:30:04.33236	2026-02-08 21:45:54.384296	t
811	remoteok_api	Senior Product Marketer API	CoinGecko	Malaysia	saas, defi, crypto, cryptocurrency, technical, support, growth, voice, financial, education, api, leader, strategy, content, senior, junior, marketer, marketing, sales, educational	https://remoteok.comhttps://remoteOK.com/remote-jobs/remote-senior-product-marketer-api-coingecko-1130132	2026-02-10 10:30:04.33236	2026-02-08 21:45:54.384296	t
812	remoteok_api	UI Developer R01560583	Brillio	Phoenix, Arizona, United States	developer, ui, design, react, reactjs, consultant, web, javascript, html, angular, mobile, strategy, digital nomad	https://remoteok.comhttps://remoteOK.com/remote-jobs/remote-ui-developer-r01560583-brillio-1130131	2026-02-10 10:30:04.33236	2026-02-08 21:45:54.384296	t
813	remoteok_api	Functional Payroll Consultant	Ubiminds	Latin America	consultant, payroll, hr, system, security, recruiter, support, software, growth, operations, full-time	https://remoteok.comhttps://remoteOK.com/remote-jobs/remote-functional-payroll-consultant-ubiminds-1130130	2026-02-10 10:30:04.33236	2026-02-08 21:45:54.384296	t
814	remoteok_api	Audit Partner Quality Control	BPM LLP	United States	system, training, technical, support, accounting, financial, leader, management, lead, senior, health, executive	https://remoteok.comhttps://remoteOK.com/remote-jobs/remote-audit-partner-quality-control-bpm-llp-1130129	2026-02-10 10:30:04.33236	2026-02-08 21:45:54.384296	t
815	remoteok_api	Senior FP&amp;A &amp; Strategic Finance	Access Softek	Remote	saas, training, consulting, software, financial, finance, fintech, banking, leader, senior, excel, health, executive	https://remoteok.comhttps://remoteOK.com/remote-jobs/remote-senior-fpampa-amp-strategic-finance-access-softek-1130128	2026-02-10 10:30:04.33236	2026-02-08 21:45:54.384296	t
816	remoteok_api	Enterprise Account Manager	UiPath		manager, technical, software, growth, leader, strategy, management, senior, marketing, legal, go, executive	https://remoteok.comhttps://remoteOK.com/remote-jobs/remote-enterprise-account-manager-uipath-1130127	2026-02-10 10:30:04.33236	2026-02-08 21:45:54.384296	t
817	remoteok_api	KIP Summer 2026 Operations Intern Foundation for Economic Education	Stand Together	Georgia	training, support, software, testing, education, finance, management, content, operations, operational, marketing, legal, recruitment, internship, full-time, part-time	https://remoteok.comhttps://remoteOK.com/remote-jobs/remote-kip-summer-2026-operations-intern-foundation-for-economic-education-stand-together-1130126	2026-02-10 10:30:04.33236	2026-02-08 21:45:54.384296	t
818	remoteok_api	Associate Preconstruction Project Engineer Battery Storage	Plus Power	Remote	system, engineer	https://remoteok.comhttps://remoteOK.com/remote-jobs/remote-associate-preconstruction-project-engineer-battery-storage-plus-power-1130125	2026-02-10 10:30:04.33236	2026-02-08 21:45:54.384296	t
819	remoteok_api	Partner	Convergent Research	in greater D.C.	design, founder, technical, support, growth, director, voice, manager, strategy, lead, senior, operational, excel, recruiting, digital nomad	https://remoteok.comhttps://remoteOK.com/remote-jobs/remote-partner-convergent-research-1130124	2026-02-10 10:30:04.33236	2026-02-08 21:45:54.384296	t
820	remoteok_api	KIP Summer 2026 Social Media Intern Foundation for Economic Education	Stand Together	Georgia	training, support, voice, video, education, management, content, legal, internship, full-time, part-time, non tech	https://remoteok.comhttps://remoteOK.com/remote-jobs/remote-kip-summer-2026-social-media-intern-foundation-for-economic-education-stand-together-1130123	2026-02-10 10:30:04.33236	2026-02-08 21:45:54.384296	t
821	remoteok_api	Senior Manager Advertising Analytics	Spreetail	Remote	manager, training, technical, support, software, testing, growth, leader, strategy, senior, operational, marketing, analytics, health, recruitment, ecommerce	https://remoteok.comhttps://remoteOK.com/remote-jobs/remote-senior-manager-advertising-analytics-spreetail-1130122	2026-02-10 10:30:04.33236	2026-02-08 21:45:54.384296	t
822	remoteok_api	Solution CAD Engineer III	Unlimited Technology		design, system, security, technical, support, video, management, engineer, engineering, digital nomad	https://remoteok.comhttps://remoteOK.com/remote-jobs/remote-solution-cad-engineer-iii-unlimited-technology-1130121	2026-02-10 10:30:04.33236	2026-02-08 21:45:54.384296	t
823	remoteok_api	Account Executive	GuidePoint Security		infosec, salesforce, security, travel, management, marketing, sales, executive	https://remoteok.comhttps://remoteOK.com/remote-jobs/remote-account-executive-guidepoint-security-1130120	2026-02-10 10:30:04.33236	2026-02-08 21:45:54.384296	t
824	remoteok_api	Senior Cloud Software Engineer Assist	Stack AV	Pittsburgh	software, system, full-stack, video, cloud, senior, engineer	https://remoteok.comhttps://remoteOK.com/remote-jobs/remote-senior-cloud-software-engineer-assist-stack-av-1130119	2026-02-10 10:30:04.33236	2026-02-08 21:45:54.384296	t
825	remoteok_api	Web Developer	Epoch AI	Remote	developer, web, react, full-time, digital nomad	https://remoteok.comhttps://remoteOK.com/remote-jobs/remote-web-developer-epoch-ai-1130118	2026-02-10 10:30:04.33236	2026-02-08 21:45:54.384296	t
826	remoteok_api	Game Product Manager	Mob Entertainment	Remote	game, manager, video, finance, content, non tech	https://remoteok.comhttps://remoteOK.com/remote-jobs/remote-game-product-manager-mob-entertainment-1130117	2026-02-10 10:30:04.33236	2026-02-08 21:45:54.384296	t
827	remoteok_api	Systems Engineer	GOAT Group	Remote US	saas, security, technical, management, junior, operational, reliability, engineer, engineering	https://remoteok.comhttps://remoteOK.com/remote-jobs/remote-systems-engineer-goat-group-1130115	2026-02-10 10:30:04.33236	2026-02-08 21:45:54.384296	t
828	remoteok_api	GTM Automation Engineer	Postscript		design, jira, salesforce, python, training, architect, technical, test, ux, code, web, lead, operations, marketing, sales, engineer, ecommerce, shopify, digital nomad	https://remoteok.comhttps://remoteOK.com/remote-jobs/remote-gtm-automation-engineer-postscript-1130114	2026-02-10 10:30:04.33236	2026-02-08 21:45:54.384296	t
829	remoteok_api	Customer Support Representative West Coast Hours	Comply	United States	saas, consulting, technical, support, software, financial, investment, finance, management, excel, sales	https://remoteok.comhttps://remoteOK.com/remote-jobs/remote-customer-support-representative-west-coast-hours-comply-1130113	2026-02-10 10:30:04.33236	2026-02-08 21:45:54.384296	t
830	remoteok_api	Senior Full Stack AI Engineer	AskVinny		engineer, javascript, typescript, react, ai	https://remoteok.comhttps://remoteOK.com/remote-jobs/remote-senior-full-stack-ai-engineer-askvinny-1130110	2026-02-10 10:30:04.33236	2026-02-08 21:45:54.384296	t
831	remoteok_api	Civil Development Engineer	Intersect	United States	design, technical, support, growth, financial, management, lead, operations, health, engineer, engineering, digital nomad	https://remoteok.comhttps://remoteOK.com/remote-jobs/remote-civil-development-engineer-intersect-1130109	2026-02-10 10:30:04.33236	2026-02-08 21:45:54.384296	t
832	remoteok_api	Senior Full Stack Developer	MicroVentures	Texas	developer, saas, security, full-stack, technical, software, testing, code, travel, laravel, php, nosql, git, api, senior, junior, engineering, digital nomad	https://remoteok.comhttps://remoteOK.com/remote-jobs/remote-senior-full-stack-developer-microventures-1130107	2026-02-10 10:30:04.33236	2026-02-08 21:45:54.384296	t
833	remoteok_api	Pessoa Engenheira de Machine Learning Senior	Banco BV	SÃ£o Paulo	python, senior, engineering	https://remoteok.comhttps://remoteOK.com/remote-jobs/remote-pessoa-engenheira-de-machine-learning-senior-banco-bv-1130106	2026-02-10 10:30:04.33236	2026-02-08 21:45:54.384296	t
834	remoteok_api	Tech Product Manager Data Plataform Products	Neon Pagamentos	Remoto	manager	https://remoteok.comhttps://remoteOK.com/remote-jobs/remote-tech-product-manager-data-plataform-products-neon-pagamentos-1130105	2026-02-10 10:30:04.33236	2026-02-08 21:45:54.384296	t
835	remoteok_api	Video Marketing Intern	Omniscient		saas, growth, video, seo, content, senior, marketing, educational	https://remoteok.comhttps://remoteOK.com/remote-jobs/remote-video-marketing-intern-omniscient-1130104	2026-02-10 10:30:04.33236	2026-02-08 21:45:54.384296	t
836	remoteok_api	Senior Site Reliability Engineer Senior Manager	Accenture Federal Services	Washington, DC	manager, system, training, technical, support, cloud, leader, management, senior, operational, reliability, health, engineer, engineering	https://remoteok.comhttps://remoteOK.com/remote-jobs/remote-senior-site-reliability-engineer-senior-manager-accenture-federal-services-1130102	2026-02-10 10:30:04.33236	2026-02-08 21:45:54.384296	t
837	remoteok_api	Product Designer	PadSplit	Atlanta, GA	design, system, designer, support, test, growth, ux, manager, video, engineering, digital nomad	https://remoteok.comhttps://remoteOK.com/remote-jobs/remote-product-designer-padsplit-1130100	2026-02-10 10:30:04.33236	2026-02-08 21:45:54.384296	t
838	remoteok_api	Data Analyst	Restaurant365	Remote	analyst, saas, python, technical, support, accounting, cloud, senior, operations, operational, excel, analytics, executive	https://remoteok.comhttps://remoteOK.com/remote-jobs/remote-data-analyst-restaurant365-1130099	2026-02-10 10:30:04.33236	2026-02-08 21:45:54.384296	t
839	remoteok_api	QA Analyst	Proof of Play		analyst, jira, ios, crypto, game, support, software, testing, test, qa, mobile, content, go	https://remoteok.comhttps://remoteOK.com/remote-jobs/remote-qa-analyst-proof-of-play-1130098	2026-02-10 10:30:04.33236	2026-02-08 21:45:54.384296	t
840	remoteok_api	Sales Director Enterprise Central	Voxel	Chicago	director, saas, salesforce, security, support, growth, voice, operations, operational, sales	https://remoteok.comhttps://remoteOK.com/remote-jobs/remote-sales-director-enterprise-central-voxel-1130097	2026-02-10 10:30:04.33236	2026-02-08 21:45:54.384296	t
841	remoteok_api	Solutions Engineer	Lumana		design, embedded, security, full-stack, technical, support, software, testing, voice, video, banking, leader, senior, sales, engineer, engineering, digital nomad	https://remoteok.comhttps://remoteOK.com/remote-jobs/remote-solutions-engineer-lumana-1130096	2026-02-10 10:30:04.33236	2026-02-08 21:45:54.384296	t
842	remoteok_api	Solutions Engineer	Gather AI		technical, support, growth, robotics, operational, marketing, sales, engineer	https://remoteok.comhttps://remoteOK.com/remote-jobs/remote-solutions-engineer-gather-ai-1130095	2026-02-10 10:30:04.33236	2026-02-08 21:45:54.384296	t
843	remoteok_api	Senior Full Stack Software Engineer .NET Angular	Ubiminds	Remote	software, design, saas, hr, system, frontend, recruiter, support, testing, growth, code, web, git, angular, senior, engineer, engineering, backend, full-time, digital nomad	https://remoteok.comhttps://remoteOK.com/remote-jobs/remote-senior-full-stack-software-engineer-net-angular-ubiminds-1130094	2026-02-10 10:30:04.33236	2026-02-08 21:45:54.384296	t
844	remoteok_api	Senior Automation Engineer Java	Ubiminds	Remote	hr, system, technical, recruiter, support, software, testing, test, growth, code, java, senior, engineer, engineering, backend, full-time	https://remoteok.comhttps://remoteOK.com/remote-jobs/remote-senior-automation-engineer-java-ubiminds-1130093	2026-02-10 10:30:04.33236	2026-02-08 21:45:54.384296	t
845	remoteok_api	Staff Software Engineer	Acquia		software, design, system, front-end, frontend, back-end, security, technical, test, code, analyst, angular, drupal, leader, strategy, operations, operational, engineer, recruitment, educational, digital nomad	https://remoteok.comhttps://remoteOK.com/remote-jobs/remote-staff-software-engineer-acquia-1130091	2026-02-10 10:30:04.33236	2026-02-08 21:45:54.384296	t
846	remoteok_api	Implementation Specialist	Roofr		training, sales, non tech	https://remoteok.comhttps://remoteOK.com/remote-jobs/remote-implementation-specialist-roofr-1130090	2026-02-10 10:30:04.33236	2026-02-08 21:45:54.384296	t
847	remoteok_api	Security Engineer ISSO	Accenture Federal Services	Chantilly, VA	security, design, system, training, support, code, cloud, management, lead, health, engineer, engineering, digital nomad	https://remoteok.comhttps://remoteOK.com/remote-jobs/remote-security-engineer-isso-accenture-federal-services-1130089	2026-02-10 10:30:04.33236	2026-02-08 21:45:54.384296	t
848	remoteok_api	Application Security Engineer	Anthropic	San Francisco, CA	security, design, technical, support, developer, software, code, lead, engineer, educational, digital nomad	https://remoteok.comhttps://remoteOK.com/remote-jobs/remote-application-security-engineer-anthropic-1130088	2026-02-10 10:30:04.33236	2026-02-08 21:45:54.384296	t
849	remoteok_api	GenAI Security Engineer	Point72	New York, NY	security, training, technical, support, software, cloud, api, engineer, engineering	https://remoteok.comhttps://remoteOK.com/remote-jobs/remote-genai-security-engineer-point72-1130087	2026-02-10 10:30:04.33236	2026-02-08 21:45:54.384296	t
850	remoteok_api	Implementation Specialist Spanish Speaking	Roofr		training, sales, non tech	https://remoteok.comhttps://remoteOK.com/remote-jobs/remote-implementation-specialist-spanish-speaking-roofr-1130086	2026-02-10 10:30:04.33236	2026-02-08 21:45:54.384296	t
851	remoteok_api	DevOps Engineer	Higher Logic	Remote-Ontario, Quebec	saas, technical, devops, engineer, engineering, full-time	https://remoteok.comhttps://remoteOK.com/remote-jobs/remote-devops-engineer-higher-logic-1130083	2026-02-10 10:30:04.33236	2026-02-08 21:45:54.384296	t
852	remoteok_api	Senior Angular Software Engineer	Aiwyn		software, design, saas, accounting, angular, senior, engineer, digital nomad	https://remoteok.comhttps://remoteOK.com/remote-jobs/remote-senior-angular-software-engineer-aiwyn-1130082	2026-02-10 10:30:04.33236	2026-02-08 21:45:54.384296	t
878	remoteok_api	Bilingual Care Coordinator	Pair Team	Sacramento	coordinator, management, lead, operations, health, non tech	https://remoteok.comhttps://remoteOK.com/remote-jobs/remote-bilingual-care-coordinator-pair-team-1130053	2026-02-10 10:30:04.33236	2026-02-08 21:45:54.384296	t
853	remoteok_api	Machine Learning Engineer II Ad Forecasting	Spotify	New York, NY	technical, ads, lead, health, engineer, engineering	https://remoteok.comhttps://remoteOK.com/remote-jobs/remote-machine-learning-engineer-ii-ad-forecasting-spotify-1130081	2026-02-10 10:30:04.33236	2026-02-08 21:45:54.384296	t
854	remoteok_api	Copy Writer Advertising Agency	Affinitiv		writer, software, marketing	https://remoteok.comhttps://remoteOK.com/remote-jobs/remote-copy-writer-advertising-agency-affinitiv-1130079	2026-02-10 10:30:04.33236	2026-02-08 21:45:54.384296	t
855	remoteok_api	Staff Software Engineer Distributed Simulation	Anduril Industries	Seattle	software, design, system, security, 3d, cloud, lead, engineer, engineering, digital nomad	https://remoteok.comhttps://remoteOK.com/remote-jobs/remote-staff-software-engineer-distributed-simulation-anduril-industries-1130076	2026-02-10 10:30:04.33236	2026-02-08 21:45:54.384296	t
856	remoteok_api	Systems Engineer Enterprise Middleware	Spry Methods	Washington, DC	system, security, docker, technical, support, financial, java, cloud, management, senior, operations, operational, engineer, engineering, linux	https://remoteok.comhttps://remoteOK.com/remote-jobs/remote-systems-engineer-enterprise-middleware-spry-methods-1130075	2026-02-10 10:30:04.33236	2026-02-08 21:45:54.384296	t
857	remoteok_api	Senior Sales Engineer Data & AI Security	Veeam Software	Netherlands	security, dev, leader, senior, sales, go, engineer, digital nomad	https://remoteok.comhttps://remoteOK.com/remote-jobs/remote-senior-sales-engineer-data-ai-security-veeam-software-1130074	2026-02-10 10:30:04.33236	2026-02-08 21:45:54.384296	t
858	remoteok_api	Software Development Engineer Test Brazil	Platform Science	Londrina	software, test, design, growth, ui, code, engineer, digital nomad	https://remoteok.comhttps://remoteOK.com/remote-jobs/remote-software-development-engineer-test-brazil-platform-science-1130073	2026-02-10 10:30:04.33236	2026-02-08 21:45:54.384296	t
859	remoteok_api	Senior Enterprise Middleware Engineer	Spry Methods	Washington, DC	system, security, docker, technical, support, devops, financial, java, cloud, management, senior, operations, operational, engineer, engineering, linux	https://remoteok.comhttps://remoteOK.com/remote-jobs/remote-senior-enterprise-middleware-engineer-spry-methods-1130072	2026-02-10 10:30:04.33236	2026-02-08 21:45:54.384296	t
860	remoteok_api	Technical Account Manager	FireMon	UK, Remote	manager, design, hr, system, security, technical, support, software, banking, management, senior, health, digital nomad	https://remoteok.comhttps://remoteOK.com/remote-jobs/remote-technical-account-manager-firemon-1130071	2026-02-10 10:30:04.33236	2026-02-08 21:45:54.384296	t
861	remoteok_api	Senior Angular Software Engineer	Aiwyn	US based	software, design, saas, frontend, technical, support, code, web, travel, accounting, cloud, angular, management, senior, engineer, digital nomad	https://remoteok.comhttps://remoteOK.com/remote-jobs/remote-senior-angular-software-engineer-aiwyn-1130070	2026-02-10 10:30:04.33236	2026-02-08 21:45:54.384296	t
862	remoteok_api	Platform Architect .NET Full stack	Ubiminds	Remote	architect, hr, technical, recruiter, support, software, growth, angular, engineer, full-time	https://remoteok.comhttps://remoteOK.com/remote-jobs/remote-platform-architect-net-full-stack-ubiminds-1130069	2026-02-10 10:30:04.33236	2026-02-08 21:45:54.384296	t
863	remoteok_api	Licensed Customer Success Representative	Thimble	United States	technical, support, software, health	https://remoteok.comhttps://remoteOK.com/remote-jobs/remote-licensed-customer-success-representative-thimble-1130068	2026-02-10 10:30:04.33236	2026-02-08 21:45:54.384296	t
864	remoteok_api	Senior Curriculum Specialist Tax Staff Level Training	Colibri Group	1 Remote	training, design, technical, support, accounting, finance, microsoft, leader, management, content, senior, digital nomad	https://remoteok.comhttps://remoteOK.com/remote-jobs/remote-senior-curriculum-specialist-tax-staff-level-training-colibri-group-1130067	2026-02-10 10:30:04.33236	2026-02-08 21:45:54.384296	t
865	remoteok_api	SMM & Brand Communications Manager	Medier		manager, voice, content, marketing, non tech	https://remoteok.comhttps://remoteOK.com/remote-jobs/remote-smm-brand-communications-manager-medier-1130066	2026-02-10 10:30:04.33236	2026-02-08 21:45:54.384296	t
866	remoteok_api	Director of Business Development	Rocket Communications	Remote	director, design, security, technical, software, growth, ux, financial, lead, health, digital nomad	https://remoteok.comhttps://remoteOK.com/remote-jobs/remote-director-of-business-development-rocket-communications-1130065	2026-02-10 10:30:04.33236	2026-02-08 21:45:54.384296	t
867	remoteok_api	Director of Tax Operations	Whatnot		director, support, growth, accounting, financial, strategy, lead, operations, e-commerce	https://remoteok.comhttps://remoteOK.com/remote-jobs/remote-director-of-tax-operations-whatnot-1130064	2026-02-10 10:30:04.33236	2026-02-08 21:45:54.384296	t
868	remoteok_api	Cell Therapy Account Management North Carolina South Carolina	Iovance Biotherapeutics	North Carolina	growth, education, strategy, management, operational	https://remoteok.comhttps://remoteOK.com/remote-jobs/remote-cell-therapy-account-management-north-carolina-south-carolina-iovance-biotherapeutics-1130063	2026-02-10 10:30:04.33236	2026-02-08 21:45:54.384296	t
869	remoteok_api	NFL Data Scientist	Swish Analytics	San Francisco	technical, support, software, code, stats, analytics, engineering	https://remoteok.comhttps://remoteOK.com/remote-jobs/remote-nfl-data-scientist-swish-analytics-1130062	2026-02-10 10:30:04.33236	2026-02-08 21:45:54.384296	t
870	remoteok_api	Enterprise Product Manager	Accurate Background	Remote, United States	manager, recruiter, support, financial, education, investment, leader, strategy, management, lead, operations, operational, sales, executive, non tech	https://remoteok.comhttps://remoteOK.com/remote-jobs/remote-enterprise-product-manager-accurate-background-1130061	2026-02-10 10:30:04.33236	2026-02-08 21:45:54.384296	t
871	remoteok_api	Principal Product Designer Map Viewer	Esri		design, embedded, designer, technical, strategy, lead, digital nomad	https://remoteok.comhttps://remoteOK.com/remote-jobs/remote-principal-product-designer-map-viewer-esri-1130060	2026-02-10 10:30:04.33236	2026-02-08 21:45:54.384296	t
872	remoteok_api	Clinical Trial Budget and Contracts Manager	Natera	US Remote	manager, support, director, finance, management, lead, operations, legal, non tech	https://remoteok.comhttps://remoteOK.com/remote-jobs/remote-clinical-trial-budget-and-contracts-manager-natera-1130059	2026-02-10 10:30:04.33236	2026-02-08 21:45:54.384296	t
873	remoteok_api	Manager Technical Writing	Torc Robotics	Remote - US	manager, technical, software, robotics, leader, content	https://remoteok.comhttps://remoteOK.com/remote-jobs/remote-manager-technical-writing-torc-robotics-1130058	2026-02-10 10:30:04.33236	2026-02-08 21:45:54.384296	t
874	remoteok_api	Principal Product Manager Customer Experience and AI	Constant Contact	Remote - US	manager, happiness, assistant, lead	https://remoteok.comhttps://remoteOK.com/remote-jobs/remote-principal-product-manager-customer-experience-and-ai-constant-contact-1130057	2026-02-10 10:30:04.33236	2026-02-08 21:45:54.384296	t
875	remoteok_api	AI Automation Engineer Tech Lead	Myriad360		design, technical, manager, api, microsoft, lead, operations, engineer, digital nomad	https://remoteok.comhttps://remoteOK.com/remote-jobs/remote-ai-automation-engineer-tech-lead-myriad360-1130056	2026-02-10 10:30:04.33236	2026-02-08 21:45:54.384296	t
876	remoteok_api	Product Data Analyst	Big Health	Remote - US	analyst, python, supervisor, support, growth, code, git, management, lead, analytics, go, medical, health, healthcare, engineering	https://remoteok.comhttps://remoteOK.com/remote-jobs/remote-product-data-analyst-big-health-1130055	2026-02-10 10:30:04.33236	2026-02-08 21:45:54.384296	t
879	remoteok_api	Finance Expert Crypto	xAI	Remote	crypto, defi, cryptocurrency, technical, support, finance, management, engineering	https://remoteok.comhttps://remoteOK.com/remote-jobs/remote-finance-expert-crypto-xai-1130051	2026-02-10 10:30:04.33236	2026-02-08 21:45:54.384296	t
880	remoteok_api	Manager Web Project Management	GoFundMe		web, manager, system, support, growth, director, strategy, management, content	https://remoteok.comhttps://remoteOK.com/remote-jobs/remote-manager-web-project-management-gofundme-1130050	2026-02-10 10:30:04.33236	2026-02-08 21:45:54.384296	t
881	remoteok_api	Sales Solution Engineer	FlowFuse	Remote	security, training, technical, lead, sales, engineer, engineering	https://remoteok.comhttps://remoteOK.com/remote-jobs/remote-sales-solution-engineer-flowfuse-1130049	2026-02-10 10:30:04.33236	2026-02-08 21:45:54.384296	t
882	remoteok_api	Senior Python Software Engineer	Bloomreach	Slovakia	python, software, test, growth, financial, cloud, senior, analytics, engineer, engineering, backend	https://remoteok.comhttps://remoteOK.com/remote-jobs/remote-senior-python-software-engineer-bloomreach-1130047	2026-02-10 10:30:04.33236	2026-02-08 21:45:54.384296	t
883	remoteok_api	Implementation Specialist	Karbon	Remote, United States	training, software, accounting, cloud, leader, management, lead	https://remoteok.comhttps://remoteOK.com/remote-jobs/remote-implementation-specialist-karbon-1130046	2026-02-10 10:30:04.33236	2026-02-08 21:45:54.384296	t
884	remoteok_api	Finance Expert Crypto	xAI		crypto, defi, cryptocurrency, technical, support, finance, management, engineering	https://remoteok.comhttps://remoteOK.com/remote-jobs/remote-finance-expert-crypto-xai-1130045	2026-02-10 10:30:04.33236	2026-02-08 21:45:54.384296	t
885	remoteok_api	Sales Representative	InfStones	Texas	web3, crypto, support, software, node, management, sales, full-time	https://remoteok.comhttps://remoteOK.com/remote-jobs/remote-sales-representative-infstones-1130044	2026-02-10 10:30:04.33236	2026-02-08 21:45:54.384296	t
886	remoteok_api	Finance Expert Crypto	xAI		crypto, defi, cryptocurrency, technical, support, finance, management, engineering	https://remoteok.comhttps://remoteOK.com/remote-jobs/remote-finance-expert-crypto-xai-1130043	2026-02-10 10:30:04.33236	2026-02-08 21:45:54.384296	t
887	remoteok_api	Finance Expert Crypto	xAI		crypto, defi, cryptocurrency, technical, support, finance, management, engineering	https://remoteok.comhttps://remoteOK.com/remote-jobs/remote-finance-expert-crypto-xai-1130042	2026-02-10 10:30:04.33236	2026-02-08 21:45:54.384296	t
888	remoteok_api	Recruiting Operations Coordinator	Jerry.ai	Austin	recruiter, sourcer, coordinator, admin, operations, operational, health, recruiting, non tech	https://remoteok.comhttps://remoteOK.com/remote-jobs/remote-recruiting-operations-coordinator-jerry-ai-1130041	2026-02-10 10:30:04.33236	2026-02-08 21:45:54.384296	t
889	remoteok_api	Senior Account Executive	N2	Portsmouth, NH	support, content, senior, sales, executive	https://remoteok.comhttps://remoteOK.com/remote-jobs/remote-senior-account-executive-n2-1130040	2026-02-10 10:30:04.33236	2026-02-08 21:45:54.384296	t
1474	arbeitnow	YouTube Creative Director (m/w/d)	OnStage	Berlin	Remote, Marketing and Communication	https://www.arbeitnow.com/jobs/companies/onstage/youtube-creative-director-berlin-372944	2026-02-10 10:30:04.33236	2026-02-10 10:30:04.33236	t
1475	arbeitnow	YouTube Creative Strategist (m/w/d)	OnStage	Berlin	Remote, Marketing and Communication	https://www.arbeitnow.com/jobs/companies/onstage/youtube-creative-strategist-berlin-288984	2026-02-10 10:30:04.33236	2026-02-10 10:30:04.33236	t
1476	arbeitnow	Social Media Manager - YouTube (m/w/d)	OnStage	Berlin	Remote, Marketing and Communication	https://www.arbeitnow.com/jobs/companies/onstage/social-media-manager-youtube-berlin-284540	2026-02-10 10:30:04.33236	2026-02-10 10:30:04.33236	t
1477	arbeitnow	Remote-Projekt-Assistenz / Junior Projektkoordinator (m/w/d) - Neustart mit Perspektive	Apiron Group	Grünwald	Remote, Product Management	https://www.arbeitnow.com/jobs/companies/apiron-group/remote-projekt-assistenz-junior-projektkoordinator-neustart-mit-perspektive-grunwald-243638	2026-02-10 10:30:04.33236	2026-02-10 10:30:04.33236	t
1478	arbeitnow	Performance Marketing Teamlead (m/w/d) im E-Commerce	Just Hiring	Berlin	Remote, Marketing and Communication	https://www.arbeitnow.com/jobs/companies/just-hiring/performance-marketing-teamlead-im-e-commerce-berlin-241695	2026-02-10 10:30:04.33236	2026-02-10 10:30:04.33236	t
1479	arbeitnow	Didn't find a suitable position? – Show Us What You’ve Got with an Unsolicited Application!	Amperecloud GmbH	Berlin	Remote, IT	https://www.arbeitnow.com/jobs/companies/amperecloud-gmbh/didnt-find-a-suitable-position-show-us-what-youve-got-with-an-unsolicited-application-berlin-402043	2026-02-10 10:30:04.33236	2026-02-10 10:30:04.33236	t
1480	arbeitnow	ERP-Consultant (m/w/d)	ALYF GmbH	Leipzig	Remote, SAP/ERP Consulting, Development	https://www.arbeitnow.com/jobs/companies/alyf-gmbh/erp-consultant-leipzig-372472	2026-02-10 10:30:04.33236	2026-02-10 10:30:04.33236	t
1481	arbeitnow	HR Business Partner im Recruiting (m/w/d) zu 100 % remote (im Ehrenamt)	Bundesverbraucherhilfe e.V.	Berlin	Remote, Recruitment and Selection	https://www.arbeitnow.com/jobs/companies/bundesverbraucherhilfe-ev/hr-business-partner-im-recruiting-zu-100-remote-im-ehrenamt-berlin-109261	2026-02-10 10:30:04.33236	2026-02-10 10:30:04.33236	t
1482	arbeitnow	Head of Recruiting (m/w/d) zu 100 % remote (im Ehrenamt)	Bundesverbraucherhilfe e.V.	Berlin	Remote, Management, Team Leader	https://www.arbeitnow.com/jobs/companies/bundesverbraucherhilfe-ev/head-of-recruiting-zu-100-remote-im-ehrenamt-berlin-276369	2026-02-10 10:30:04.33236	2026-02-10 10:30:04.33236	t
1483	arbeitnow	Machine Learning Engineer	[commutator,studios]	Düsseldorf	Remote, Data Scientist	https://www.arbeitnow.com/jobs/companies/commutatorstudios/machine-learning-engineer-dusseldorf-196629	2026-02-10 10:30:04.33236	2026-02-10 10:30:04.33236	t
1484	arbeitnow	Viral Short-Form Copywriter (m/w/d) – Reels, TikToks & YouTube Shorts	Teaching Socials	Hockenheim	Remote, Business Consulting	https://www.arbeitnow.com/jobs/companies/teaching-socials/viral-short-form-copywriter-reels-tiktoks-youtube-shorts-hockenheim-297517	2026-02-10 10:30:04.33236	2026-02-10 10:30:04.33236	t
1485	arbeitnow	Creative Strategist (m/w/d) für große E-Commerce Kunden	Just Hiring	Berlin	Remote, Marketing and Communication	https://www.arbeitnow.com/jobs/companies/just-hiring/creative-strategist-fur-grosse-e-commerce-kunden-berlin-273349	2026-02-10 10:30:04.33236	2026-02-10 10:30:04.33236	t
1486	arbeitnow	IT Operations Freelancer (m/w/d)	Cultural Hire	Hamburg	Remote, System and Network Administration	https://www.arbeitnow.com/jobs/companies/cultural-hire/it-operations-freelancer-hamburg-108130	2026-02-10 10:30:04.33236	2026-02-10 10:30:04.33236	t
1487	arbeitnow	Werkstudent IT Operations (m/w/d)	Cultural Hire	Hamburg	Remote, System and Network Administration	https://www.arbeitnow.com/jobs/companies/cultural-hire/werkstudent-it-operations-hamburg-489065	2026-02-10 10:30:04.33236	2026-02-10 10:30:04.33236	t
1488	arbeitnow	Partner Success Manager - (all genders) - 100% Homeoffice	fino data services GmbH	Kassel	Remote, Directors, Chief Executives	https://www.arbeitnow.com/jobs/companies/fino-data-services-gmbh/partner-success-manager-all-genders-100-homeoffice-kassel-411824	2026-02-10 10:30:04.33236	2026-02-10 10:30:04.33236	t
1489	arbeitnow	Backend Softwareentwickler (m/w/d)	TecFox GmbH	Braunschweig	Remote, IT	https://www.arbeitnow.com/jobs/companies/tecfox-gmbh/backend-softwareentwickler-braunschweig-391680	2026-02-10 10:30:04.33236	2026-02-10 10:30:04.33236	t
1490	arbeitnow	Frontend Softwareentwickler (m/w/d)	TecFox GmbH	Braunschweig	Remote, IT	https://www.arbeitnow.com/jobs/companies/tecfox-gmbh/frontend-softwareentwickler-braunschweig-215735	2026-02-10 10:30:04.33236	2026-02-10 10:30:04.33236	t
1491	arbeitnow	TikTok Livestream / Live Host	AYLASHES	Pleidelsheim	Remote, Social Media Manager	https://www.arbeitnow.com/jobs/companies/aylashes/tiktok-livestream-live-host-pleidelsheim-340611	2026-02-10 10:30:04.33236	2026-02-10 10:30:04.33236	t
1492	arbeitnow	(Senior) Platform Engineer (all genders) e*star	E-Star Trading GmbH	Frankfurt am Main	Remote, IT	https://www.arbeitnow.com/jobs/companies/e-star-trading-gmbh/senior-platform-engineer-all-genders-estar-frankfurt-am-main-308970	2026-02-10 10:30:04.33236	2026-02-10 10:30:04.33236	t
1493	arbeitnow	Technical Account Manager - DACH	SolarEdge	Munich	Remote	https://www.arbeitnow.com/jobs/companies/solaredge/remote-technical-account-manager-dach-munich-263830	2026-02-10 10:30:04.33236	2026-02-10 10:30:04.33236	t
1494	arbeitnow	Senior UX-/UI-Designer (Figma) - MES-Anwendungen (m/w/d)	nakami lounge GmbH	Munich	Remote, Media, Screen and Web Design	https://www.arbeitnow.com/jobs/companies/nakami-lounge-gmbh/senior-ux-ui-designer-figma-mes-anwendungen-munich-32610	2026-02-10 10:30:04.33236	2026-02-10 10:30:04.33236	t
1495	arbeitnow	Content Strategist für Paid Ads (m/w/d)	VIVIENDO GmbH	Biberach	Remote, Business Development	https://www.arbeitnow.com/jobs/companies/viviendo-gmbh/content-strategist-fur-paid-ads-biberach-55392	2026-02-10 10:30:04.33236	2026-02-10 10:30:04.33236	t
1496	weworkremotely	Remote Customer Support - $20/hr - United States	Remote Talent Cloud	Remote		https://weworkremotely.com/remote-jobs/remote-talent-cloud-remote-customer-support-20-hr-united-states-3	2026-02-10 10:30:58.222808	2026-02-10 10:30:58.222808	t
1500	weworkremotely	CRM Marketer / SMM Specialist (Junior–Mid)	Baby Doge	Remote		https://weworkremotely.com/remote-jobs/baby-doge-crm-marketer-smm-specialist-junior-mid	2026-02-10 10:30:58.222808	2026-02-10 10:30:58.222808	t
1501	weworkremotely	(Senior) CRM Admin (f/m/d)	Career @ plancraft	Remote		https://weworkremotely.com/remote-jobs/career-plancraft-senior-crm-admin-f-m-d	2026-02-10 10:30:58.222808	2026-02-10 10:30:58.222808	t
1502	weworkremotely	CRM Manager (Bilingue Français/Anglais - 100% Remote)	EmailClub	Remote		https://weworkremotely.com/remote-jobs/emailclub-crm-manager-bilingue-francais-anglais-100-remote	2026-02-10 10:30:58.222808	2026-02-10 10:30:58.222808	t
1503	weworkremotely	Account Executive, Mid Market - France	HubSpot	Remote		https://weworkremotely.com/remote-jobs/hubspot-account-executive-mid-market-france-2	2026-02-10 10:30:58.222808	2026-02-10 10:30:58.222808	t
1521	weworkremotely	Werkstudent (w/m/d) - DevOps & Cloud Support	CROZ DACH	Remote		https://weworkremotely.com/remote-jobs/croz-dach-werkstudent-w-m-d-devops-cloud-support	2026-02-10 10:30:58.222808	2026-02-10 10:30:58.222808	t
1522	weworkremotely	Senior Solutions Engineer	AutoRABIT Holding	Remote		https://weworkremotely.com/remote-jobs/autorabit-holding-senior-solutions-engineer	2026-02-10 10:30:58.222808	2026-02-10 10:30:58.222808	t
1523	weworkremotely	DevOps Engineer - Remote, Latin America	Bluelight Consulting	Remote		https://weworkremotely.com/remote-jobs/bluelight-consulting-devops-engineer-remote-latin-america	2026-02-10 10:30:58.222808	2026-02-10 10:30:58.222808	t
1524	weworkremotely	Développeur.se fullstack - DevOps	Akinox Solutions	Remote		https://weworkremotely.com/remote-jobs/akinox-solutions-developpeur-se-fullstack-devops	2026-02-10 10:30:58.222808	2026-02-10 10:30:58.222808	t
1545	weworkremotely	Full stack developer for a unique company	Cliniko	Remote		https://weworkremotely.com/remote-jobs/cliniko-full-stack-developer-for-a-unique-company	2026-02-10 10:30:58.222808	2026-02-10 10:30:58.222808	t
1551	weworkremotely	Software Engineer (WordPress Developer)	RebelCode	Remote		https://weworkremotely.com/remote-jobs/rebelcode-software-engineer-wordpress-developer	2026-02-10 10:30:58.222808	2026-02-10 10:30:58.222808	t
1570	weworkremotely	Expert React developer for a unique company	Cliniko	Remote		https://weworkremotely.com/remote-jobs/cliniko-expert-react-developer-for-a-unique-company	2026-02-10 10:30:58.222808	2026-02-10 10:30:58.222808	t
1591	weworkremotely	Content Writer Course	OnTheGoSystems	Remote		https://weworkremotely.com/remote-jobs/onthegosystems-content-writer-course	2026-02-10 10:30:58.222808	2026-02-10 10:30:58.222808	t
1593	weworkremotely	AI Trainer (Multiple Roles) | $50-$200/hr	Helix Recruit	Remote		https://weworkremotely.com/remote-jobs/helix-recruit-ai-trainer-multiple-roles-50-200-hr-3	2026-02-10 10:30:58.222808	2026-02-10 10:30:58.222808	t
1616	weworkremotely	Senior RoR Developer	OnTheGoSystems	Remote		https://weworkremotely.com/remote-jobs/onthegosystems-senior-ror-developer	2026-02-10 10:30:58.222808	2026-02-10 10:30:58.222808	t
1621	weworkremotely	GIS Web Developer - Esri/React Specialist (Remote)	Codvo.ai	Remote		https://weworkremotely.com/remote-jobs/codvo-ai-gis-web-developer-esri-react-specialist-remote	2026-02-10 10:30:58.222808	2026-02-10 10:30:58.222808	t
1622	weworkremotely	Senior Ruby Engineer	Leobit	Remote		https://weworkremotely.com/remote-jobs/leobit-senior-ruby-engineer	2026-02-10 10:30:58.222808	2026-02-10 10:30:58.222808	t
1623	weworkremotely	HubSpot Developer	Smartbug Media	Remote		https://weworkremotely.com/remote-jobs/smartbug-media-hubspot-developer	2026-02-10 10:30:58.222808	2026-02-10 10:30:58.222808	t
1624	weworkremotely	Clinical Trial Web Application Developer	Everest Clinical Research	Remote		https://weworkremotely.com/remote-jobs/everest-clinical-research-clinical-trial-web-application-developer-1	2026-02-10 10:30:58.222808	2026-02-10 10:30:58.222808	t
1654	weworkremotely	Sales Operations Specialist	Qase	Remote		https://weworkremotely.com/remote-jobs/qase-sales-operations-specialist	2026-02-10 10:30:58.222808	2026-02-10 10:30:58.222808	t
1669	weworkremotely	Data Analyst (Tech job example)	Inter IKEA Group	Remote		https://weworkremotely.com/remote-jobs/inter-ikea-group-data-analyst-tech-job-example	2026-02-10 10:30:58.222808	2026-02-10 10:30:58.222808	t
1670	weworkremotely	Memory Design Engineer	sanherjobhr	Remote		https://weworkremotely.com/remote-jobs/sanherjobhr-memory-design-engineer	2026-02-10 10:30:58.222808	2026-02-10 10:30:58.222808	t
1671	weworkremotely	Senior Design Engineer	Westinghouse	Remote		https://weworkremotely.com/remote-jobs/westinghouse-senior-design-engineer	2026-02-10 10:30:58.222808	2026-02-10 10:30:58.222808	t
1672	weworkremotely	Product Design Lead	Moniepoint	Remote		https://weworkremotely.com/remote-jobs/moniepoint-product-design-lead	2026-02-10 10:30:58.222808	2026-02-10 10:30:58.222808	t
1673	weworkremotely	Senior Legal Counsel (m/f/x)* – Labor and Employment, EMEA	Solventum	Remote		https://weworkremotely.com/remote-jobs/solventum-senior-legal-counsel-m-f-x-labor-and-employment-emea	2026-02-10 10:30:58.222808	2026-02-10 10:30:58.222808	t
1713	weworkremotely	Default Prevention Associate (Collections)	loanDepot	Remote		https://weworkremotely.com/remote-jobs/loandepot-default-prevention-associate-collections	2026-02-10 10:30:58.222808	2026-02-10 10:30:58.222808	t
1714	weworkremotely	Director, Finance Systems	Dropbox	Remote		https://weworkremotely.com/remote-jobs/dropbox-director-finance-systems	2026-02-10 10:30:58.222808	2026-02-10 10:30:58.222808	t
1715	weworkremotely	Strategic Account Director	TransUnion	Remote		https://weworkremotely.com/remote-jobs/transunion-strategic-account-director	2026-02-10 10:30:58.222808	2026-02-10 10:30:58.222808	t
1716	weworkremotely	Accountant	OneMCI	Remote		https://weworkremotely.com/remote-jobs/onemci-accountant	2026-02-10 10:30:58.222808	2026-02-10 10:30:58.222808	t
1717	weworkremotely	Account Executive, Majors	Zscaler	Remote		https://weworkremotely.com/remote-jobs/zscaler-account-executive-majors	2026-02-10 10:30:58.222808	2026-02-10 10:30:58.222808	t
1917	powertofly	Medior SAAS Sales Account Manager	PowerToFly	Remote		https://powertofly.com/jobs/detail/2432317	2026-02-10 10:30:58.222808	2026-02-10 10:30:58.222808	t
1918	powertofly	Leadgeneratie	PowerToFly	Remote		https://powertofly.com/jobs/?keywords=Leadgeneratie	2026-02-10 10:30:58.222808	2026-02-10 10:30:58.222808	t
1919	powertofly	Klantgerichtheid	PowerToFly	Remote		https://powertofly.com/jobs/?keywords=Klantgerichtheid	2026-02-10 10:30:58.222808	2026-02-10 10:30:58.222808	t
1920	powertofly	Klantwerving	PowerToFly	Remote		https://powertofly.com/jobs/?keywords=Klantwerving	2026-02-10 10:30:58.222808	2026-02-10 10:30:58.222808	t
1921	powertofly	Relatiebeheer	PowerToFly	Remote		https://powertofly.com/jobs/?keywords=Relatiebeheer	2026-02-10 10:30:58.222808	2026-02-10 10:30:58.222808	t
1922	powertofly	Verkoopvaardigheden	PowerToFly	Remote		https://powertofly.com/jobs/?keywords=Verkoopvaardigheden	2026-02-10 10:30:58.222808	2026-02-10 10:30:58.222808	t
1923	powertofly	CRM-beheer	PowerToFly	Remote		https://powertofly.com/jobs/?keywords=CRM-beheer	2026-02-10 10:30:58.222808	2026-02-10 10:30:58.222808	t
1924	linkedin	HR Generalist (Operations)	LinkedIn	Remote		https://www.linkedin.com/jobs/view/hr-generalist-operations-at-hims-hers-4370561186?position=1&pageNum=0&refId=SWTWYJJKBkWZqYlzkURehw%3D%3D&trackingId=BONZ7GxKzAsx6rbg1NyI1Q%3D%3D	2026-02-10 10:30:58.222808	2026-02-10 10:30:58.222808	t
1925	linkedin	Strategic Account Specialist - Orlando	LinkedIn	Remote		https://www.linkedin.com/jobs/view/strategic-account-specialist-orlando-at-phathom-pharmaceuticals-4370429868?position=2&pageNum=0&refId=SWTWYJJKBkWZqYlzkURehw%3D%3D&trackingId=pxRo1GPNSs5H1HkQoY%2BqIg%3D%3D	2026-02-10 10:30:58.222808	2026-02-10 10:30:58.222808	t
1926	linkedin	Digital Designer	LinkedIn	Remote		https://www.linkedin.com/jobs/view/digital-designer-at-under-armour-4370523123?position=3&pageNum=0&refId=SWTWYJJKBkWZqYlzkURehw%3D%3D&trackingId=Rd1LKdSondgRZA2JZWDhwg%3D%3D	2026-02-10 10:30:58.222808	2026-02-10 10:30:58.222808	t
1927	linkedin	Senior Human Resources Specialist	LinkedIn	Remote		https://www.linkedin.com/jobs/view/senior-human-resources-specialist-at-cinemark-4370910108?position=4&pageNum=0&refId=SWTWYJJKBkWZqYlzkURehw%3D%3D&trackingId=48%2BncG8y4h5wwbZ4SBPsWg%3D%3D	2026-02-10 10:30:58.222808	2026-02-10 10:30:58.222808	t
1928	linkedin	Category Manager - Sneakers	LinkedIn	Remote		https://www.linkedin.com/jobs/view/category-manager-sneakers-at-stockx-4370429788?position=5&pageNum=0&refId=SWTWYJJKBkWZqYlzkURehw%3D%3D&trackingId=43fbfncric7kx3Fm7QYlWQ%3D%3D	2026-02-10 10:30:58.222808	2026-02-10 10:30:58.222808	t
1929	linkedin	Paralegal (Remote, US)	LinkedIn	Remote		https://www.linkedin.com/jobs/view/paralegal-remote-us-at-renew-home-4370559619?position=6&pageNum=0&refId=SWTWYJJKBkWZqYlzkURehw%3D%3D&trackingId=FgGvIhW%2F8UmdTnqwPF%2FXnA%3D%3D	2026-02-10 10:30:58.222808	2026-02-10 10:30:58.222808	t
1930	linkedin	Human Resources Specialist | Remote	LinkedIn	Remote		https://www.linkedin.com/jobs/view/human-resources-specialist-remote-at-crossing-hurdles-4370408840?position=7&pageNum=0&refId=SWTWYJJKBkWZqYlzkURehw%3D%3D&trackingId=79As6neoYxdZK08E67lEEA%3D%3D	2026-02-10 10:30:58.222808	2026-02-10 10:30:58.222808	t
1931	linkedin	Medical Scheduler (Remote)	LinkedIn	Remote		https://www.linkedin.com/jobs/view/medical-scheduler-remote-at-cyber-focus-ai-4370082149?position=8&pageNum=0&refId=SWTWYJJKBkWZqYlzkURehw%3D%3D&trackingId=GncaVVbAIpNoUMBxMmUzXg%3D%3D	2026-02-10 10:30:58.222808	2026-02-10 10:30:58.222808	t
1932	linkedin	Category Manager - Apparel	LinkedIn	Remote		https://www.linkedin.com/jobs/view/category-manager-apparel-at-stockx-4370438124?position=9&pageNum=0&refId=SWTWYJJKBkWZqYlzkURehw%3D%3D&trackingId=H2jpajVg98zzDocCoQ%2BmLw%3D%3D	2026-02-10 10:30:58.222808	2026-02-10 10:30:58.222808	t
1933	linkedin	File Clerk | Remote	LinkedIn	Remote		https://www.linkedin.com/jobs/view/file-clerk-remote-at-crossing-hurdles-4370069658?position=10&pageNum=0&refId=SWTWYJJKBkWZqYlzkURehw%3D%3D&trackingId=nqaElyh1jLMKA4ed6hehVQ%3D%3D	2026-02-10 10:30:58.222808	2026-02-10 10:30:58.222808	t
1934	linkedin	Category Manager	LinkedIn	Remote		https://www.linkedin.com/jobs/view/category-manager-at-stockx-4370433642?position=11&pageNum=0&refId=SWTWYJJKBkWZqYlzkURehw%3D%3D&trackingId=re%2F3Oz%2Bx96LagBIA925zzg%3D%3D	2026-02-10 10:30:58.222808	2026-02-10 10:30:58.222808	t
1935	linkedin	Director of Customer Success	LinkedIn	Remote		https://www.linkedin.com/jobs/view/director-of-customer-success-at-sword-health-4370869256?position=12&pageNum=0&refId=SWTWYJJKBkWZqYlzkURehw%3D%3D&trackingId=WGHVp%2F43CMLvV97G1N1DqA%3D%3D	2026-02-10 10:30:58.222808	2026-02-10 10:30:58.222808	t
1936	linkedin	Director of Operations	LinkedIn	Remote		https://www.linkedin.com/jobs/view/director-of-operations-at-house-of-leon-4370493273?position=13&pageNum=0&refId=SWTWYJJKBkWZqYlzkURehw%3D%3D&trackingId=sZaWKrhtg%2FTXNh9A%2B5DTgg%3D%3D	2026-02-10 10:30:58.222808	2026-02-10 10:30:58.222808	t
1937	linkedin	Office Assistant / Scheduler	LinkedIn	Remote		https://www.linkedin.com/jobs/view/office-assistant-scheduler-at-orchestrate-consulting-group-4370235321?position=14&pageNum=0&refId=SWTWYJJKBkWZqYlzkURehw%3D%3D&trackingId=HVj5xvF%2BWoPnTUBc7YHlMg%3D%3D	2026-02-10 10:30:58.222808	2026-02-10 10:30:58.222808	t
1938	linkedin	Casting Director, UGC Creators	LinkedIn	Remote		https://www.linkedin.com/jobs/view/casting-director-ugc-creators-at-everyday-dose-4370175989?position=15&pageNum=0&refId=SWTWYJJKBkWZqYlzkURehw%3D%3D&trackingId=qfiVMT9rvLK1blgjdu0Iug%3D%3D	2026-02-10 10:30:58.222808	2026-02-10 10:30:58.222808	t
1939	linkedin	Procurement Specialist | Remote	LinkedIn	Remote		https://www.linkedin.com/jobs/view/procurement-specialist-remote-at-crossing-hurdles-4370086489?position=16&pageNum=0&refId=SWTWYJJKBkWZqYlzkURehw%3D%3D&trackingId=85dT37HZqlUwtQPt5zQAcw%3D%3D	2026-02-10 10:30:58.222808	2026-02-10 10:30:58.222808	t
1940	linkedin	Executive Assistant	LinkedIn	Remote		https://www.linkedin.com/jobs/view/executive-assistant-at-swooped-4370562446?position=17&pageNum=0&refId=SWTWYJJKBkWZqYlzkURehw%3D%3D&trackingId=EsT3a82eNfsErsipqgAzhg%3D%3D	2026-02-10 10:30:58.222808	2026-02-10 10:30:58.222808	t
1941	linkedin	Procurement Operations Associate	LinkedIn	Remote		https://www.linkedin.com/jobs/view/procurement-operations-associate-at-sundays-for-dogs-4370953112?position=18&pageNum=0&refId=SWTWYJJKBkWZqYlzkURehw%3D%3D&trackingId=TkHptfTIkDKeBR0W637WdQ%3D%3D	2026-02-10 10:30:58.222808	2026-02-10 10:30:58.222808	t
1942	linkedin	Director of Customer Success	LinkedIn	Remote		https://www.linkedin.com/jobs/view/director-of-customer-success-at-pacemate%C2%AE-4370897712?position=19&pageNum=0&refId=SWTWYJJKBkWZqYlzkURehw%3D%3D&trackingId=o2bntj85GEPRDAdH1T2MKg%3D%3D	2026-02-10 10:30:58.222808	2026-02-10 10:30:58.222808	t
1943	linkedin	Executive Assistant	LinkedIn	Remote		https://www.linkedin.com/jobs/view/executive-assistant-at-swooped-4370572151?position=20&pageNum=0&refId=SWTWYJJKBkWZqYlzkURehw%3D%3D&trackingId=HC9AUkIXfrQ4w9%2BFOwA%2FtQ%3D%3D	2026-02-10 10:30:58.222808	2026-02-10 10:30:58.222808	t
1944	linkedin	Human Resources Assistant	LinkedIn	Remote		https://www.linkedin.com/jobs/view/human-resources-assistant-at-helic-co-4370548993?position=21&pageNum=0&refId=SWTWYJJKBkWZqYlzkURehw%3D%3D&trackingId=UPKO%2Bh8ndizAcsPFQk6R7w%3D%3D	2026-02-10 10:30:58.222808	2026-02-10 10:30:58.222808	t
1945	linkedin	Senior Talent Acquisition Partner	LinkedIn	Remote		https://www.linkedin.com/jobs/view/senior-talent-acquisition-partner-at-everbridge-4370499613?position=22&pageNum=0&refId=SWTWYJJKBkWZqYlzkURehw%3D%3D&trackingId=CEqA8y5KAXjB9PhUCuWK%2Bw%3D%3D	2026-02-10 10:30:58.222808	2026-02-10 10:30:58.222808	t
1946	linkedin	Director Continuous Improvement	LinkedIn	Remote		https://www.linkedin.com/jobs/view/director-continuous-improvement-at-nsi-industries-4370801916?position=23&pageNum=0&refId=SWTWYJJKBkWZqYlzkURehw%3D%3D&trackingId=aLhwCEBTfvjcUYdGIjKiWQ%3D%3D	2026-02-10 10:30:58.222808	2026-02-10 10:30:58.222808	t
1947	linkedin	Social Media Assistant	LinkedIn	Remote		https://www.linkedin.com/jobs/view/social-media-assistant-at-spago-medspa-4370438407?position=24&pageNum=0&refId=SWTWYJJKBkWZqYlzkURehw%3D%3D&trackingId=%2FN21cWXoZ2uAh%2BMk7RY0Yw%3D%3D	2026-02-10 10:30:58.222808	2026-02-10 10:30:58.222808	t
\.


--
-- Name: jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.jobs_id_seq', 1947, true);


--
-- Name: jobs jobs_job_url_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.jobs
    ADD CONSTRAINT jobs_job_url_key UNIQUE (job_url);


--
-- Name: jobs jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.jobs
    ADD CONSTRAINT jobs_pkey PRIMARY KEY (id);


--
-- Name: idx_jobs_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_jobs_active ON public.jobs USING btree (is_active) WHERE (is_active = true);


--
-- Name: idx_jobs_company; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_jobs_company ON public.jobs USING btree (company);


--
-- Name: idx_jobs_scraped; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_jobs_scraped ON public.jobs USING btree (scraped_at DESC);


--
-- Name: idx_jobs_source; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_jobs_source ON public.jobs USING btree (source);


--
-- Name: idx_jobs_url; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_jobs_url ON public.jobs USING btree (job_url);


--
-- PostgreSQL database dump complete
--

\unrestrict z67HVPgNFpih6NvLR7NTHOBuhCGotxb2hrhkeFC6WQCo7zvKOkI8OrgtlYKmKkg

