"""
Matching module for skill similarity matching.
"""

from .similarity import match_skills

__all__ = ['match_skills']
