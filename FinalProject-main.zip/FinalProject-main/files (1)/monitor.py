"""
Job Scraper Monitoring and Statistics
View real-time statistics about your scraped jobs
"""

from database import get_connection
from datetime import datetime, timedelta
import sys

def print_header(title):
    """Print a formatted header"""
    print(f"\n{'='*70}")
    print(f"  {title}")
    print(f"{'='*70}\n")

def get_total_stats(cur):
    """Get overall statistics"""
    print_header("OVERALL STATISTICS")
    
    cur.execute("SELECT COUNT(*) FROM jobs WHERE is_active = TRUE")
    total = cur.fetchone()[0]
    print(f"Total Active Jobs: {total:,}")
    
    cur.execute("SELECT COUNT(DISTINCT company) FROM jobs WHERE is_active = TRUE")
    companies = cur.fetchone()[0]
    print(f"Unique Companies: {companies:,}")
    
    cur.execute("SELECT COUNT(DISTINCT source) FROM jobs WHERE is_active = TRUE")
    sources = cur.fetchone()[0]
    print(f"Job Sources: {sources}")
    
    cur.execute("SELECT MIN(created_at), MAX(scraped_at) FROM jobs")
    first, last = cur.fetchone()
    if first and last:
        print(f"First Job Added: {first.strftime('%Y-%m-%d %H:%M')}")
        print(f"Last Scrape: {last.strftime('%Y-%m-%d %H:%M')}")

def get_source_stats(cur):
    """Get statistics by source"""
    print_header("JOBS BY SOURCE")
    
    cur.execute("""
        SELECT 
            source,
            COUNT(*) as total,
            COUNT(CASE WHEN scraped_at > NOW() - INTERVAL '24 hours' THEN 1 END) as last_24h,
            MAX(scraped_at) as last_scrape
        FROM jobs
        WHERE is_active = TRUE
        GROUP BY source
        ORDER BY total DESC
    """)
    
    print(f"{'Source':<20} {'Total':<10} {'Last 24h':<12} {'Last Scraped'}")
    print("-" * 70)
    
    for source, total, last_24h, last_scrape in cur.fetchall():
        last_str = last_scrape.strftime('%Y-%m-%d %H:%M') if last_scrape else 'Never'
        print(f"{source:<20} {total:<10} {last_24h:<12} {last_str}")

def get_recent_jobs(cur, limit=10):
    """Get most recent jobs"""
    print_header(f"MOST RECENT {limit} jobs")
    
    cur.execute("""
        SELECT job_title, company, source, scraped_at
        FROM jobs
        WHERE is_active = TRUE
        ORDER BY scraped_at DESC
        LIMIT %s
    """, (limit,))
    
    for i, (title, company, source, scraped) in enumerate(cur.fetchall(), 1):
        time_ago = datetime.now() - scraped
        hours_ago = int(time_ago.total_seconds() / 3600)
        
        if hours_ago < 1:
            time_str = f"{int(time_ago.total_seconds() / 60)}m ago"
        elif hours_ago < 24:
            time_str = f"{hours_ago}h ago"
        else:
            time_str = f"{int(hours_ago / 24)}d ago"
        
        print(f"{i}. {title[:50]:<50}")
        print(f"   {company[:30]} | {source} | {time_str}\n")

def get_top_companies(cur, limit=10):
    """Get companies with most job postings"""
    print_header(f"TOP {limit} COMPANIES BY JOB COUNT")
    
    cur.execute("""
        SELECT company, COUNT(*) as job_count
        FROM jobs
        WHERE is_active = TRUE
        GROUP BY company
        HAVING COUNT(*) > 1
        ORDER BY job_count DESC
        LIMIT %s
    """, (limit,))
    
    print(f"{'Company':<40} {'Jobs'}")
    print("-" * 50)
    
    for company, count in cur.fetchall():
        print(f"{company[:40]:<40} {count}")

def get_activity_timeline(cur):
    """Get scraping activity over time"""
    print_header("SCRAPING ACTIVITY (Last 7 Days)")
    
    cur.execute("""
        SELECT 
            DATE(scraped_at) as scrape_date,
            COUNT(*) as jobs_scraped
        FROM jobs
        WHERE scraped_at > NOW() - INTERVAL '7 days'
        GROUP BY DATE(scraped_at)
        ORDER BY scrape_date DESC
    """)
    
    print(f"{'Date':<15} {'Jobs Scraped'}")
    print("-" * 30)
    
    results = cur.fetchall()
    if results:
        for date, count in results:
            print(f"{date.strftime('%Y-%m-%d'):<15} {count}")
    else:
        print("No scraping activity in the last 7 days")

def search_jobs(cur, keyword):
    """Search jobs by keyword"""
    print_header(f"SEARCH RESULTS FOR: '{keyword}'")
    
    cur.execute("""
        SELECT job_title, company, source, job_url
        FROM jobs
        WHERE is_active = TRUE
            AND (
                LOWER(job_title) LIKE LOWER(%s)
                OR LOWER(company) LIKE LOWER(%s)
                OR LOWER(description) LIKE LOWER(%s)
            )
        ORDER BY scraped_at DESC
        LIMIT 20
    """, (f'%{keyword}%', f'%{keyword}%', f'%{keyword}%'))
    
    results = cur.fetchall()
    
    if results:
        print(f"Found {len(results)} matching jobs:\n")
        for i, (title, company, source, url) in enumerate(results, 1):
            print(f"{i}. {title}")
            print(f"   Company: {company} | Source: {source}")
            print(f"   URL: {url}\n")
    else:
        print(f"No jobs found matching '{keyword}'")

def interactive_mode(cur):
    """Interactive search mode"""
    print_header("INTERACTIVE SEARCH MODE")
    print("Enter keywords to search (or 'quit' to exit)")
    print("Examples: 'python', 'senior developer', 'remote marketing'\n")
    
    while True:
        try:
            keyword = input("Search: ").strip()
            if keyword.lower() in ['quit', 'exit', 'q']:
                break
            if keyword:
                search_jobs(cur, keyword)
        except KeyboardInterrupt:
            print("\n\nExiting...")
            break

def main():
    """Main monitoring function"""
    conn = get_connection()
    cur = conn.cursor()
    
    # Check if we're in search mode
    if len(sys.argv) > 1:
        if sys.argv[1] == '--search':
            if len(sys.argv) > 2:
                keyword = ' '.join(sys.argv[2:])
                search_jobs(cur, keyword)
            else:
                interactive_mode(cur)
        elif sys.argv[1] == '--help':
            print("\nJob Scraper Monitoring Tool")
            print("\nUsage:")
            print("  python monitor.py              - Show all statistics")
            print("  python monitor.py --search     - Interactive search mode")
            print("  python monitor.py --search python - Search for 'python' jobs")
            print()
        else:
            print(f"Unknown option: {sys.argv[1]}")
            print("Use --help for usage information")
    else:
        # Show all statistics
        print(f"\n{'#'*70}")
        print(f"#  JOB SCRAPER MONITORING DASHBOARD")
        print(f"#  Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        print(f"{'#'*70}")
        
        get_total_stats(cur)
        get_source_stats(cur)
        get_activity_timeline(cur)
        get_top_companies(cur)
        get_recent_jobs(cur)
        
        print(f"\n{'='*70}")
        print("  TIP: Use 'python monitor.py --search' for job search")
        print(f"{'='*70}\n")
    
    cur.close()
    conn.close()

if __name__ == "__main__":
    main()
