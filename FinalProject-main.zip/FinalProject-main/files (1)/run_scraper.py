"""
Main Job Scraper Runner
Combines web scraping and API scraping with scheduling capabilities
"""

import schedule
import time
from datetime import datetime
import argparse
from job_scraper import JobScraper
from api_job_scraper import APIJobScraper

def run_all_scrapers(use_apis=True, api_keys=None):
    """Run both web scrapers and API scrapers"""
    print(f"\n{'#'*70}")
    print(f"# STARTING COMPLETE JOB SCRAPING RUN")
    print(f"# Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"{'#'*70}\n")
    
    # Run web scrapers
    try:
        print("\n--- PHASE 1: Web Scraping ---")
        web_scraper = JobScraper()
        web_scraper.run_all()
    except Exception as e:
        print(f"Error in web scraping: {e}")
    
    # Run API scrapers if enabled
    if use_apis:
        try:
            print("\n--- PHASE 2: API Scraping ---")
            api_scraper = APIJobScraper()
            api_scraper.run_all(api_keys)
        except Exception as e:
            print(f"Error in API scraping: {e}")
    
    print(f"\n{'#'*70}")
    print(f"# SCRAPING RUN COMPLETE")
    print(f"# Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"{'#'*70}\n")

def run_web_scrapers_only():
    """Run only web scrapers (faster, no API keys needed)"""
    try:
        web_scraper = JobScraper()
        web_scraper.run_all()
    except Exception as e:
        print(f"Error: {e}")

def run_api_scrapers_only(api_keys=None):
    """Run only API scrapers"""
    try:
        api_scraper = APIJobScraper()
        api_scraper.run_all(api_keys)
    except Exception as e:
        print(f"Error: {e}")

def schedule_scraping(interval_hours=6):
    """Schedule scraping to run at regular intervals"""
    print(f"Scheduling job scraping every {interval_hours} hours")
    print(f"First run starting now...")
    
    # Run immediately
    run_all_scrapers()
    
    # Schedule future runs
    schedule.every(interval_hours).hours.do(run_all_scrapers)
    
    print(f"\nScheduled! Next run in {interval_hours} hours.")
    print("Press Ctrl+C to stop.\n")
    
    while True:
        schedule.run_pending()
        time.sleep(60)  # Check every minute

def main():
    parser = argparse.ArgumentParser(description='Remote Job Scraper')
    parser.add_argument('--mode', choices=['all', 'web', 'api', 'schedule'], 
                       default='all',
                       help='Scraping mode: all (web+api), web only, api only, or schedule')
    parser.add_argument('--interval', type=int, default=6,
                       help='Hours between scheduled runs (default: 6)')
    parser.add_argument('--adzuna-id', help='Adzuna API app ID')
    parser.add_argument('--adzuna-key', help='Adzuna API app key')
    parser.add_argument('--reed-key', help='Reed.co.uk API key')
    
    args = parser.parse_args()
    
    # Prepare API keys
    api_keys = {}
    if args.adzuna_id and args.adzuna_key:
        api_keys['adzuna_id'] = args.adzuna_id
        api_keys['adzuna_key'] = args.adzuna_key
    if args.reed_key:
        api_keys['reed_key'] = args.reed_key
    
    # Run based on mode
    if args.mode == 'all':
        run_all_scrapers(use_apis=True, api_keys=api_keys)
    elif args.mode == 'web':
        run_web_scrapers_only()
    elif args.mode == 'api':
        run_api_scrapers_only(api_keys)
    elif args.mode == 'schedule':
        try:
            schedule_scraping(args.interval)
        except KeyboardInterrupt:
            print("\n\nScheduler stopped by user.")

if __name__ == "__main__":
    main()
