"""
Vector-Based Skill Matcher using pgvector and Sentence Transformers

This provides semantic matching between CV skills and job requirements using
vector embeddings stored in PostgreSQL with pgvector extension.

MUCH better than keyword matching - understands meaning and context!
Example: "React.js" will match with "Frontend framework experience"
"""

import os
import numpy as np
from typing import List, Dict, Optional, Tuple
from dotenv import load_dotenv
from sentence_transformers import SentenceTransformer
from database import get_connection
import psycopg2
from psycopg2.extras import execute_values

load_dotenv()


class VectorSkillMatcher:
    """
    Advanced skill matcher using vector embeddings for semantic similarity.
    Uses sentence-transformers for encoding and pgvector for fast similarity search.
    """
    
    def __init__(self, model_name: str = 'all-MiniLM-L6-v2'):
        """
        Initialize the vector-based skill matcher.
        
        Args:
            model_name: Sentence transformer model name
                       'all-MiniLM-L6-v2' - Fast, lightweight (default)
                       'all-mpnet-base-v2' - More accurate, slower
        """
        print(f"Loading embedding model: {model_name}...")
        self.model = SentenceTransformer(model_name)
        self.embedding_dim = self.model.get_sentence_embedding_dimension()
        print(f"✓ Model loaded! Embedding dimension: {self.embedding_dim}")
        
        self.conn = get_connection()
        self.cur = self.conn.cursor()
        
        # Ensure pgvector extension is enabled
        self._setup_pgvector()
    
    def _setup_pgvector(self):
        """Set up pgvector extension and create necessary tables."""
        try:
            # Enable pgvector extension
            self.cur.execute("CREATE EXTENSION IF NOT EXISTS vector;")
            self.conn.commit()
            print("✓ pgvector extension enabled")
            
            # Create job_embeddings table
            self.cur.execute(f"""
                CREATE TABLE IF NOT EXISTS job_embeddings (
                    job_id INTEGER PRIMARY KEY REFERENCES jobs(id) ON DELETE CASCADE,
                    full_text TEXT NOT NULL,
                    skills_text TEXT,
                    embedding vector({self.embedding_dim}) NOT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                );
            """)
            
            # Create index for faster similarity search
            self.cur.execute("""
                CREATE INDEX IF NOT EXISTS job_embeddings_embedding_idx 
                ON job_embeddings 
                USING ivfflat (embedding vector_cosine_ops)
                WITH (lists = 100);
            """)
            
            # Create CV embeddings table
            self.cur.execute(f"""
                CREATE TABLE IF NOT EXISTS cv_embeddings (
                    id SERIAL PRIMARY KEY,
                    user_id VARCHAR(255),
                    skills_text TEXT NOT NULL,
                    embedding vector({self.embedding_dim}) NOT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                );
            """)
            
            self.conn.commit()
            print("✓ Vector tables and indexes created")
            
        except Exception as e:
            print(f"Warning setting up pgvector: {e}")
            print("Make sure pgvector is installed: https://github.com/pgvector/pgvector")
            self.conn.rollback()
    
    def embed_text(self, text: str) -> np.ndarray:
        """
        Convert text to vector embedding.
        
        Args:
            text: Text to embed
            
        Returns:
            Vector embedding as numpy array
        """
        embedding = self.model.encode(text, convert_to_numpy=True)
        return embedding
    
    def embed_skills(self, skills: List[str]) -> np.ndarray:
        """
        Convert list of skills to a single vector embedding.
        
        Args:
            skills: List of skill names
            
        Returns:
            Vector embedding representing all skills
        """
        # Combine skills into a sentence for better context
        skills_text = "Professional skills: " + ", ".join(skills)
        return self.embed_text(skills_text)
    
    def generate_job_embeddings(self, batch_size: int = 100, force_regenerate: bool = False):
        """
        Generate and store embeddings for all jobs in database.
        
        Args:
            batch_size: Number of jobs to process at once
            force_regenerate: If True, regenerate all embeddings
        """
        if force_regenerate:
            print("Clearing existing embeddings...")
            self.cur.execute("DELETE FROM job_embeddings")
            self.conn.commit()
        
        # Get jobs without embeddings
        self.cur.execute("""
            SELECT j.id, j.job_title, j.company, j.description
            FROM jobs j
            LEFT JOIN job_embeddings je ON j.id = je.job_id
            WHERE je.job_id IS NULL
                AND j.is_active = TRUE
                AND j.description IS NOT NULL
                AND j.description != ''
            ORDER BY j.scraped_at DESC
        """)
        
        jobs = self.cur.fetchall()
        total_jobs = len(jobs)
        
        if total_jobs == 0:
            print("✓ All jobs already have embeddings!")
            return
        
        print(f"\nGenerating embeddings for {total_jobs} jobs...")
        print("This may take a few minutes for the first run.")
        
        embeddings_to_insert = []
        
        for i, (job_id, title, company, description) in enumerate(jobs, 1):
            # Create comprehensive text representation
            full_text = f"""
            Job Title: {title}
            Company: {company}
            Description: {description[:2000]}
            """.strip()
            
            # Generate embedding
            embedding = self.embed_text(full_text)
            
            embeddings_to_insert.append((
                job_id,
                full_text,
                description[:1000],  # Store truncated version
                embedding.tolist()
            ))
            
            # Insert in batches
            if len(embeddings_to_insert) >= batch_size or i == total_jobs:
                execute_values(
                    self.cur,
                    """
                    INSERT INTO job_embeddings (job_id, full_text, skills_text, embedding)
                    VALUES %s
                    ON CONFLICT (job_id) DO NOTHING
                    """,
                    embeddings_to_insert
                )
                self.conn.commit()
                
                print(f"  Processed {i}/{total_jobs} jobs ({(i/total_jobs)*100:.1f}%)")
                embeddings_to_insert = []
        
        print(f"✓ Generated embeddings for {total_jobs} jobs!")
    
    def find_similar_jobs(self, 
                         cv_skills: List[str],
                         top_k: int = 50,
                         similarity_threshold: float = 0.3) -> List[Dict]:
        """
        Find jobs most similar to CV skills using vector similarity.
        
        Args:
            cv_skills: List of skills from user's CV
            top_k: Number of top matches to return
            similarity_threshold: Minimum similarity score (0-1)
            
        Returns:
            List of matching jobs with similarity scores
        """
        # Generate embedding for CV skills
        cv_embedding = self.embed_skills(cv_skills)
        
        # Find similar jobs using cosine similarity
        self.cur.execute("""
            SELECT 
                j.id,
                j.source,
                j.job_title,
                j.company,
                j.location,
                j.description,
                j.job_url,
                j.scraped_at,
                je.skills_text,
                1 - (je.embedding <=> %s::vector) as similarity
            FROM jobs j
            JOIN job_embeddings je ON j.id = je.job_id
            WHERE j.is_active = TRUE
                AND (1 - (je.embedding <=> %s::vector)) >= %s
            ORDER BY je.embedding <=> %s::vector
            LIMIT %s
        """, (cv_embedding.tolist(), cv_embedding.tolist(), similarity_threshold, 
              cv_embedding.tolist(), top_k))
        
        results = self.cur.fetchall()
        
        matching_jobs = []
        for row in results:
            (job_id, source, title, company, location, description, 
             url, scraped_at, skills_text, similarity) = row
            
            matching_jobs.append({
                'job_id': job_id,
                'source': source,
                'title': title,
                'company': company,
                'location': location,
                'description': description,
                'url': url,
                'scraped_at': scraped_at,
                'skills_text': skills_text,
                'similarity_score': float(similarity),
                'match_percentage': float(similarity * 100)
            })
        
        return matching_jobs
    
    def find_matching_jobs_hybrid(self,
                                  cv_skills: List[str],
                                  top_k: int = 50,
                                  vector_weight: float = 0.7,
                                  keyword_weight: float = 0.3) -> List[Dict]:
        """
        Hybrid matching: combines vector similarity with keyword matching.
        
        Args:
            cv_skills: List of skills from user's CV
            top_k: Number of top matches to return
            vector_weight: Weight for vector similarity (0-1)
            keyword_weight: Weight for keyword matching (0-1)
            
        Returns:
            List of matching jobs with combined scores
        """
        # Get vector matches
        cv_embedding = self.embed_skills(cv_skills)
        
        # Normalize skills for keyword matching
        cv_skills_lower = [s.lower().strip() for s in cv_skills]
        
        self.cur.execute("""
            SELECT 
                j.id,
                j.source,
                j.job_title,
                j.company,
                j.location,
                j.description,
                j.job_url,
                j.scraped_at,
                je.skills_text,
                1 - (je.embedding <=> %s::vector) as vector_similarity
            FROM jobs j
            JOIN job_embeddings je ON j.id = je.job_id
            WHERE j.is_active = TRUE
            ORDER BY je.embedding <=> %s::vector
            LIMIT %s
        """, (cv_embedding.tolist(), cv_embedding.tolist(), top_k * 2))
        
        results = self.cur.fetchall()
        
        matching_jobs = []
        
        for row in results:
            (job_id, source, title, company, location, description, 
             url, scraped_at, skills_text, vector_sim) = row
            
            # Calculate keyword matching score
            description_lower = description.lower() if description else ""
            keyword_matches = sum(1 for skill in cv_skills_lower 
                                 if skill in description_lower)
            keyword_score = keyword_matches / len(cv_skills) if cv_skills else 0
            
            # Combined score
            combined_score = (vector_weight * float(vector_sim)) + (keyword_weight * keyword_score)
            
            matching_jobs.append({
                'job_id': job_id,
                'source': source,
                'title': title,
                'company': company,
                'location': location,
                'description': description,
                'url': url,
                'scraped_at': scraped_at,
                'skills_text': skills_text,
                'vector_similarity': float(vector_sim),
                'keyword_score': keyword_score,
                'combined_score': combined_score,
                'match_percentage': combined_score * 100,
                'cv_skills': cv_skills
            })
        
        # Sort by combined score
        matching_jobs.sort(key=lambda x: x['combined_score'], reverse=True)
        
        return matching_jobs[:top_k]
    
    def explain_match(self, cv_skills: List[str], job_description: str, 
                     top_n_similar: int = 5) -> Dict:
        """
        Explain why a job matches the CV by finding most similar skills.
        
        Args:
            cv_skills: User's CV skills
            job_description: Job description text
            top_n_similar: Number of top similar skills to show
            
        Returns:
            Dictionary with match explanation
        """
        # Embed each skill individually
        skill_embeddings = {skill: self.embed_text(skill) for skill in cv_skills}
        job_embedding = self.embed_text(job_description[:2000])
        
        # Calculate similarity for each skill
        similarities = {}
        for skill, skill_emb in skill_embeddings.items():
            # Cosine similarity
            cos_sim = np.dot(skill_emb, job_embedding) / (
                np.linalg.norm(skill_emb) * np.linalg.norm(job_embedding)
            )
            similarities[skill] = float(cos_sim)
        
        # Sort by similarity
        sorted_skills = sorted(similarities.items(), key=lambda x: x[1], reverse=True)
        
        return {
            'top_relevant_skills': [
                {'skill': skill, 'relevance': round(score * 100, 1)}
                for skill, score in sorted_skills[:top_n_similar]
            ],
            'least_relevant_skills': [
                {'skill': skill, 'relevance': round(score * 100, 1)}
                for skill, score in sorted_skills[-top_n_similar:]
            ]
        }
    
    def get_skill_recommendations(self, cv_skills: List[str], 
                                 n_jobs: int = 50) -> Dict:
        """
        Get skill recommendations based on similar job postings.
        
        Args:
            cv_skills: User's current skills
            n_jobs: Number of jobs to analyze
            
        Returns:
            Dictionary with skill recommendations
        """
        matching_jobs = self.find_similar_jobs(cv_skills, top_k=n_jobs, 
                                              similarity_threshold=0.2)
        
        if not matching_jobs:
            return {
                'recommendations': [],
                'jobs_analyzed': 0
            }
        
        # Extract all text from job descriptions
        all_job_text = " ".join([j['description'][:1000] for j in matching_jobs 
                                if j.get('description')])
        
        # Common tech skills to check
        potential_skills = [
            'Python', 'JavaScript', 'TypeScript', 'Java', 'C++', 'Go', 'Rust',
            'React', 'Angular', 'Vue', 'Node.js', 'Django', 'Flask', 'Spring',
            'PostgreSQL', 'MongoDB', 'Redis', 'MySQL',
            'AWS', 'Azure', 'GCP', 'Docker', 'Kubernetes',
            'Machine Learning', 'Data Science', 'AI', 'Deep Learning',
            'REST API', 'GraphQL', 'Microservices',
            'Git', 'CI/CD', 'Agile', 'Scrum'
        ]
        
        # Filter out skills user already has
        cv_skills_lower = [s.lower() for s in cv_skills]
        new_skills = [s for s in potential_skills 
                     if s.lower() not in cv_skills_lower]
        
        # Count mentions
        skill_mentions = {}
        for skill in new_skills:
            count = all_job_text.lower().count(skill.lower())
            if count > 0:
                skill_mentions[skill] = count
        
        # Sort by frequency
        sorted_skills = sorted(skill_mentions.items(), key=lambda x: x[1], reverse=True)
        
        return {
            'recommendations': [
                {
                    'skill': skill,
                    'mentions': count,
                    'percentage': (count / len(matching_jobs)) * 100
                }
                for skill, count in sorted_skills[:15]
            ],
            'jobs_analyzed': len(matching_jobs)
        }
    
    def close(self):
        """Close database connection."""
        if self.cur:
            self.cur.close()
        if self.conn:
            self.conn.close()


def format_vector_match(job: Dict) -> str:
    """Format a vector match result for display."""
    output = []
    output.append(f"\n{'='*70}")
    output.append(f"Job: {job['title']}")
    output.append(f"Company: {job['company']}")
    output.append(f"Location: {job['location']}")
    output.append(f"Source: {job['source']}")
    
    if 'combined_score' in job:
        output.append(f"Match: {job['match_percentage']:.1f}% (Combined)")
        output.append(f"  Vector Similarity: {job['vector_similarity']*100:.1f}%")
        output.append(f"  Keyword Match: {job['keyword_score']*100:.1f}%")
    else:
        output.append(f"Similarity: {job['match_percentage']:.1f}%")
    
    output.append(f"URL: {job['url']}")
    output.append('='*70)
    
    return '\n'.join(output)


if __name__ == "__main__":
    # Example usage
    print("="*70)
    print("VECTOR-BASED SKILL MATCHER - Example")
    print("="*70)
    
    matcher = VectorSkillMatcher()
    
    # Generate embeddings for all jobs (first time only)
    print("\nStep 1: Generating embeddings for jobs...")
    matcher.generate_job_embeddings()
    
    # Example CV skills
    example_skills = [
        "Python", "JavaScript", "React", "Node.js", "Django",
        "PostgreSQL", "MongoDB", "Git", "Docker", "AWS"
    ]
    
    print(f"\nStep 2: Finding matches for skills: {', '.join(example_skills[:5])}...")
    
    # Find matches using hybrid approach
    matches = matcher.find_matching_jobs_hybrid(
        cv_skills=example_skills,
        top_k=10,
        vector_weight=0.7,
        keyword_weight=0.3
    )
    
    print(f"\n✓ Found {len(matches)} matches!")
    print("\nTop 5 matches:")
    
    for i, job in enumerate(matches[:5], 1):
        print(f"\n{i}. {job['title']} at {job['company']}")
        print(f"   Match: {job['match_percentage']:.1f}%")
        print(f"   Vector: {job['vector_similarity']*100:.1f}% | Keywords: {job['keyword_score']*100:.1f}%")
    
    # Get recommendations
    print("\nStep 3: Getting skill recommendations...")
    recs = matcher.get_skill_recommendations(example_skills, n_jobs=20)
    
    print(f"\nTop skills to learn (based on {recs['jobs_analyzed']} similar jobs):")
    for rec in recs['recommendations'][:10]:
        print(f"  • {rec['skill']}: mentioned in {rec['percentage']:.0f}% of jobs")
    
    matcher.close()
    
    print("\n" + "="*70)
    print("Example complete! Ready to integrate with Streamlit.")
    print("="*70)