"""
Test the FREE Skill Matcher
Quick test to make sure everything works before running the full app
"""

from skill_matcher import SkillMatcherFree

def test_matcher():
    print("\n" + "="*70)
    print("TESTING FREE SKILL MATCHER")
    print("="*70)
    
    # Test with example skills
    test_skills = [
       ""
    ]
    
    print(f"\nTest Skills: {', '.join(test_skills)}")
    print("\nInitializing matcher...")
    
    try:
        matcher = SkillMatcherFree()
        print("✓ Matcher initialized successfully")
        
        print(f"\nSearching for matching jobs (minimum 20% match)...")
        
        matching_jobs = matcher.find_matching_jobs(
            cv_skills=test_skills,
            min_match_percentage=20,
            limit=10
        )
        
        if matching_jobs:
            print(f"\n✓ SUCCESS! Found {len(matching_jobs)} matching jobs")
            print("\nTop 3 matches:")
            for i, job in enumerate(matching_jobs[:3], 1):
                print(f"\n{i}. {job['title']} at {job['company']}")
                print(f"   Match: {job['match_percentage']:.0f}% ({job['match_score']}/{job['total_required']} skills)")
                print(f"   Matching skills: {', '.join(job['exact_matches'][:5])}")
        else:
            print("\n⚠ No jobs found. This could mean:")
            print("  1. Database is empty - run: python run_scraper.py --mode web")
            print("  2. Match threshold too high - try 10% instead")
            print("  3. Database connection issue")
        
        matcher.close()
        
        print("\n" + "="*70)
        print("TEST COMPLETE - Ready to use!")
        print("="*70)
        print("\nNext step: Run the app with:")
        print("  streamlit run integrated_app_free.py")
        
    except Exception as e:
        print(f"\n✗ ERROR: {e}")
        print("\nPossible issues:")
        print("  1. Database not set up - run: python setup_database.py")
        print("  2. Wrong database credentials in database.py")
        print("  3. PostgreSQL not running")
        
        return False
    
    return True

if __name__ == "__main__":
    test_matcher()