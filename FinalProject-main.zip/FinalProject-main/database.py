import psycopg2

def get_connection():
    return psycopg2.connect(
        host="localhost",
        database="jobs_db",          # your database name
        user="postgres",              # or your username
        password="AliTlais@2004",     # your password
        port="5432"                   # default PostgreSQL port
    )