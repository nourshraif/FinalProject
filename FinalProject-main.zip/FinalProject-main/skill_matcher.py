"""
Cost-Free Skill Matcher Module

This version uses pattern matching and keyword extraction instead of API calls
for job skill extraction, making it completely free to use with unlimited matches.
"""

import os
import re
from typing import List, Dict, Optional, Set
from dotenv import load_dotenv
from openai import OpenAI
from database import get_connection

load_dotenv()


class SkillMatcherFree:
    """
    Matches user CV skills with job requirements using pattern matching.
    No API costs - uses keyword extraction from job descriptions.
    """
    
    def __init__(self):
        """Initialize the skill matcher."""
        self.conn = get_connection()
        self.cur = self.conn.cursor()
        
        # Comprehensive skill keywords database
        self.skill_keywords = self._build_skill_database()
    
    def _build_skill_database(self) -> Dict[str, List[str]]:
        """Build a comprehensive database of tech skills and their variations."""
        return {
            # Programming Languages
            'Python': ['python', 'py', 'python3'],
            'JavaScript': ['javascript', 'js', 'es6', 'ecmascript', 'node.js', 'nodejs'],
            'Java': ['java', 'jdk', 'jre', 'java se', 'java ee'],
            'TypeScript': ['typescript', 'ts'],
            'C++': ['c++', 'cpp', 'cplusplus'],
            'C#': ['c#', 'csharp', 'c sharp', '.net'],
            'Ruby': ['ruby', 'ruby on rails', 'rails'],
            'PHP': ['php', 'php7', 'php8'],
            'Go': ['go', 'golang'],
            'Rust': ['rust'],
            'Swift': ['swift', 'swiftui'],
            'Kotlin': ['kotlin'],
            'R': ['r programming', 'r language'],
            'Scala': ['scala'],
            
            # Frontend Frameworks
            'React': ['react', 'reactjs', 'react.js', 'react native'],
            'Angular': ['angular', 'angularjs', 'angular2+'],
            'Vue': ['vue', 'vuejs', 'vue.js'],
            'Svelte': ['svelte'],
            'Next.js': ['nextjs', 'next.js'],
            
            # Backend Frameworks
            'Django': ['django', 'django rest framework', 'drf'],
            'Flask': ['flask'],
            'FastAPI': ['fastapi'],
            'Express': ['express', 'expressjs', 'express.js'],
            'Spring': ['spring', 'spring boot', 'springboot'],
            'Laravel': ['laravel'],
            
            # Databases
            'PostgreSQL': ['postgresql', 'postgres', 'psql'],
            'MySQL': ['mysql'],
            'MongoDB': ['mongodb', 'mongo'],
            'Redis': ['redis'],
            'SQLite': ['sqlite'],
            'Oracle': ['oracle', 'oracle db'],
            'SQL Server': ['sql server', 'mssql', 'ms sql'],
            'Cassandra': ['cassandra'],
            'Elasticsearch': ['elasticsearch', 'elastic search'],
            
            # Cloud & DevOps
            'AWS': ['aws', 'amazon web services', 'ec2', 's3', 'lambda'],
            'Azure': ['azure', 'microsoft azure'],
            'GCP': ['gcp', 'google cloud', 'google cloud platform'],
            'Docker': ['docker', 'containerization', 'containers'],
            'Kubernetes': ['kubernetes', 'k8s'],
            'Jenkins': ['jenkins'],
            'Git': ['git', 'github', 'gitlab', 'bitbucket'],
            'CI/CD': ['ci/cd', 'cicd', 'continuous integration', 'continuous deployment'],
            'Terraform': ['terraform'],
            'Ansible': ['ansible'],
            
            # Data Science & ML
            'Machine Learning': ['machine learning', 'ml', 'deep learning', 'neural networks'],
            'TensorFlow': ['tensorflow', 'tf'],
            'PyTorch': ['pytorch', 'torch'],
            'Pandas': ['pandas'],
            'NumPy': ['numpy'],
            'Scikit-learn': ['scikit-learn', 'sklearn', 'scikit learn'],
            'Keras': ['keras'],
            
            # APIs & Protocols
            'REST API': ['rest api', 'restful', 'rest', 'rest apis'],
            'GraphQL': ['graphql', 'gql'],
            'gRPC': ['grpc'],
            'WebSocket': ['websocket', 'websockets'],
            
            # Testing
            'Jest': ['jest'],
            'Pytest': ['pytest'],
            'Selenium': ['selenium'],
            'Cypress': ['cypress'],
            'JUnit': ['junit'],
            
            # Other Tools
            'Linux': ['linux', 'unix'],
            'Agile': ['agile', 'scrum', 'kanban'],
            'Jira': ['jira'],
            'Microservices': ['microservices', 'micro services'],
            'API Design': ['api design', 'api development'],
        }
    
    def extract_skills_from_job(self, job_description: str) -> List[str]:
        """
        Extract skills from job description using pattern matching.
        This is FREE - no API calls!
        
        Args:
            job_description: The job description text
            
        Returns:
            List of extracted skills
        """
        if not job_description:
            return []
        
        job_lower = job_description.lower()
        found_skills = set()
        
        # Search for each skill and its variations
        for skill_name, variations in self.skill_keywords.items():
            for variation in variations:
                # Use word boundaries to avoid partial matches
                pattern = r'\b' + re.escape(variation) + r'\b'
                if re.search(pattern, job_lower, re.IGNORECASE):
                    found_skills.add(skill_name)
                    break  # Found this skill, move to next
        
        return list(found_skills)
    
    def normalize_skill(self, skill: str) -> str:
        """
        Normalize a skill name to match against our database.
        
        Args:
            skill: Raw skill name
            
        Returns:
            Normalized skill name
        """
        skill_lower = skill.lower().strip()
        
        # Check if this skill matches any in our database
        for standard_name, variations in self.skill_keywords.items():
            if skill_lower in [v.lower() for v in variations]:
                return standard_name
            if skill_lower == standard_name.lower():
                return standard_name
        
        # Return original if not found (capitalized)
        return skill.strip().title()
    
    def calculate_match_score(self, cv_skills: List[str], job_skills: List[str]) -> Dict:
        """
        Calculate match score between CV skills and job requirements.
        
        Args:
            cv_skills: List of skills from user's CV
            job_skills: List of required skills from job
            
        Returns:
            Dictionary with match details
        """
        if not job_skills:
            return {
                'score': 0,
                'percentage': 0,
                'exact_matches': [],
                'partial_matches': [],
                'missing_skills': [],
                'total_required': 0,
                'matched_count': 0
            }
        
        # Normalize skills
        cv_skills_normalized = [self.normalize_skill(s) for s in cv_skills]
        job_skills_normalized = [self.normalize_skill(s) for s in job_skills]
        
        cv_skills_lower = [s.lower() for s in cv_skills_normalized]
        job_skills_lower = [s.lower() for s in job_skills_normalized]
        
        # Find exact matches
        exact_matches = []
        for cv_skill in cv_skills_normalized:
            if cv_skill.lower() in job_skills_lower:
                exact_matches.append(cv_skill)
        
        # Find partial matches (substring matching)
        partial_matches = []
        matched_job_skills = set(s.lower() for s in exact_matches)
        
        for cv_skill in cv_skills_normalized:
            cv_lower = cv_skill.lower()
            if cv_lower in matched_job_skills:
                continue
                
            for job_skill in job_skills_normalized:
                job_lower = job_skill.lower()
                if job_lower in matched_job_skills:
                    continue
                
                # Check for substring match
                if (cv_lower in job_lower or job_lower in cv_lower) and cv_lower != job_lower:
                    partial_matches.append((cv_skill, job_skill))
                    matched_job_skills.add(job_lower)
                    break
        
        # Calculate score
        total_required = len(job_skills_normalized)
        exact_count = len(exact_matches)
        partial_count = len(partial_matches)
        
        score = exact_count + (partial_count * 0.5)
        percentage = (score / total_required) * 100 if total_required > 0 else 0
        
        # Find missing skills
        for cv_s, job_s in partial_matches:
            matched_job_skills.add(job_s.lower())
        
        missing_skills = [s for s in job_skills_normalized 
                         if s.lower() not in matched_job_skills]
        
        return {
            'score': round(score, 2),
            'percentage': round(percentage, 1),
            'exact_matches': list(set(exact_matches)),
            'partial_matches': partial_matches,
            'missing_skills': missing_skills,
            'total_required': total_required,
            'matched_count': exact_count + partial_count
        }
    
    def find_matching_jobs(self, cv_skills: List[str], 
                          min_match_percentage: float = 20,
                          limit: int = 50,
                          sources: Optional[List[str]] = None) -> List[Dict]:
        """
        Find jobs that match user's CV skills using FREE pattern matching.
        
        Args:
            cv_skills: List of skills from user's CV
            min_match_percentage: Minimum match percentage (default 20%)
            limit: Maximum number of jobs to return
            sources: Optional list of job sources to filter by
            
        Returns:
            List of matching jobs with match scores
        """
        # Build query
        query = """
            SELECT id, source, job_title, company, location, description, job_url, scraped_at
            FROM jobs
            WHERE is_active = TRUE
                AND description IS NOT NULL
                AND description != ''
        """
        
        params = []
        if sources:
            placeholders = ','.join(['%s'] * len(sources))
            query += f" AND source IN ({placeholders})"
            params.extend(sources)
        
        query += " ORDER BY scraped_at DESC LIMIT %s"
        params.append(limit * 3)  # Get more jobs initially for filtering
        
        self.cur.execute(query, params)
        jobs = self.cur.fetchall()
        
        matching_jobs = []
        
        print(f"\n{'='*70}")
        print(f"Analyzing {len(jobs)} jobs for skill matches (FREE - No API costs!)")
        print(f"Your skills: {', '.join(cv_skills[:10])}{'...' if len(cv_skills) > 10 else ''}")
        print('='*70)
        
        for i, (job_id, source, title, company, location, description, url, scraped_at) in enumerate(jobs):
            # Extract skills using FREE pattern matching
            job_skills = self.extract_skills_from_job(description)
            
            if not job_skills:
                continue
            
            # Calculate match
            match_result = self.calculate_match_score(cv_skills, job_skills)
            
            if match_result['percentage'] >= min_match_percentage:
                matching_jobs.append({
                    'job_id': job_id,
                    'source': source,
                    'title': title,
                    'company': company,
                    'location': location,
                    'url': url,
                    'scraped_at': scraped_at,
                    'required_skills': job_skills,
                    'match_score': match_result['score'],
                    'match_percentage': match_result['percentage'],
                    'exact_matches': match_result['exact_matches'],
                    'partial_matches': match_result['partial_matches'],
                    'missing_skills': match_result['missing_skills'],
                    'total_required': match_result['total_required']
                })
                
                print(f"✓ {title[:50]:<50} at {company[:20]:<20} - {match_result['percentage']:.0f}%")
            
            # Progress indicator
            if (i + 1) % 25 == 0:
                print(f"  Processed {i + 1}/{len(jobs)} jobs...")
        
        # Sort by match percentage
        matching_jobs.sort(key=lambda x: x['match_percentage'], reverse=True)
        
        print(f"\n{'='*70}")
        print(f"Found {len(matching_jobs)} matching jobs (>{min_match_percentage}% match)")
        print('='*70)
        
        return matching_jobs[:limit]
    
    def get_skill_gap_analysis(self, cv_skills: List[str], 
                               top_n_jobs: int = 50) -> Dict:
        """
        Analyze skill gaps based on top matching jobs.
        
        Args:
            cv_skills: List of user's CV skills
            top_n_jobs: Number of top jobs to analyze
            
        Returns:
            Dictionary with skill gap analysis
        """
        matching_jobs = self.find_matching_jobs(cv_skills, min_match_percentage=10, limit=top_n_jobs)
        
        if not matching_jobs:
            return {
                'total_jobs_analyzed': 0,
                'your_current_skills': cv_skills,
                'top_missing_skills': [],
                'average_match_percentage': 0
            }
        
        # Collect all missing skills
        all_missing = []
        for job in matching_jobs:
            all_missing.extend(job['missing_skills'])
        
        # Count frequency of missing skills
        skill_frequency = {}
        for skill in all_missing:
            skill_lower = skill.lower()
            skill_frequency[skill_lower] = skill_frequency.get(skill_lower, 0) + 1
        
        # Sort by frequency
        top_missing = sorted(skill_frequency.items(), key=lambda x: x[1], reverse=True)
        
        avg_match = sum(j['match_percentage'] for j in matching_jobs) / len(matching_jobs)
        
        return {
            'total_jobs_analyzed': len(matching_jobs),
            'your_current_skills': cv_skills,
            'top_missing_skills': [
                {
                    'skill': skill.title(),
                    'frequency': count,
                    'percentage': (count / len(matching_jobs)) * 100
                }
                for skill, count in top_missing[:15]
            ],
            'average_match_percentage': round(avg_match, 1)
        }
    
    def close(self):
        """Close database connection."""
        if self.cur:
            self.cur.close()
        if self.conn:
            self.conn.close()


def format_job_match(job: Dict) -> str:
    """Format a job match for display."""
    output = []
    output.append(f"\n{'='*70}")
    output.append(f"Job: {job['title']}")
    output.append(f"Company: {job['company']}")
    output.append(f"Location: {job['location']}")
    output.append(f"Source: {job['source']}")
    output.append(f"Match: {job['match_percentage']:.1f}% ({job['match_score']:.1f}/{job['total_required']} skills)")
    output.append(f"URL: {job['url']}")
    
    if job['exact_matches']:
        output.append(f"\n✓ Your Matching Skills ({len(job['exact_matches'])}):")
        for skill in job['exact_matches'][:10]:
            output.append(f"  • {skill}")
        if len(job['exact_matches']) > 10:
            output.append(f"  ... and {len(job['exact_matches']) - 10} more")
    
    if job['partial_matches']:
        output.append(f"\n≈ Partial Matches ({len(job['partial_matches'])}):")
        for cv_skill, job_skill in job['partial_matches'][:5]:
            output.append(f"  • You: {cv_skill} ≈ Required: {job_skill}")
    
    if job['missing_skills']:
        output.append(f"\n✗ Missing Skills ({len(job['missing_skills'])}):")
        for skill in job['missing_skills'][:8]:
            output.append(f"  • {skill}")
        if len(job['missing_skills']) > 8:
            output.append(f"  ... and {len(job['missing_skills']) - 8} more")
    
    output.append('='*70)
    return '\n'.join(output)


if __name__ == "__main__":
    # Example usage
    matcher = SkillMatcherFree()
    
    # Example CV skills
    example_skills = [
        "Python", "JavaScript", "React", "Node.js", "Django",
        "PostgreSQL", "MongoDB", "Git", "Docker", "AWS",
        "REST APIs", "GraphQL", "Machine Learning", "TensorFlow", "Pandas"
    ]
    
    print("="*70)
    print("FREE SKILL MATCHER - Example Usage (No API Costs!)")
    print("="*70)
    
    # Find matching jobs
    matching_jobs = matcher.find_matching_jobs(
        cv_skills=example_skills,
        min_match_percentage=30,
        limit=10
    )
    
    # Display top 5 matches
    print("\n\nTOP MATCHING JOBS:\n")
    for job in matching_jobs[:5]:
        print(format_job_match(job))
    
    # Get skill gap analysis
    print("\n\nSKILL GAP ANALYSIS:\n")
    gap_analysis = matcher.get_skill_gap_analysis(example_skills, top_n_jobs=30)
    
    print(f"Analyzed {gap_analysis['total_jobs_analyzed']} jobs")
    print(f"Average match: {gap_analysis['average_match_percentage']:.1f}%")
    print(f"\nTop Skills to Learn:")
    for item in gap_analysis['top_missing_skills'][:10]:
        print(f"  • {item['skill']}: appears in {item['percentage']:.0f}% of jobs")
    
    matcher.close()