import requests
from bs4 import BeautifulSoup
import time
from datetime import datetime
from database import get_connection
import warnings
from bs4 import XMLParsedAsHTMLWarning
import re

warnings.filterwarnings("ignore", category=XMLParsedAsHTMLWarning)

class ComprehensiveJobScraper:
    def __init__(self):
        self.headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
        }
        self.conn = get_connection()
        self.cur = self.conn.cursor()
        self.jobs_saved = 0
    
    def clean_text(self, text):
        """Clean and validate text"""
        if not text:
            return ""
        text = text.strip()
        noise_patterns = [
            r'^\d+[dhms]$', r'^new$', r'^featured$', r'^hiring$', 
            r'^remote$', r'^\d+$', r'^apply$', r'^view job$'
        ]
        for pattern in noise_patterns:
            if re.match(pattern, text.lower()):
                return ""
        return text
    
    def is_valid_company(self, company):
        """Check if company name is valid"""
        if not company or len(company) < 2:
            return False
        company_lower = company.lower()
        invalid = ['new', 'featured', 'hiring', 'remote', 'apply', 'view job', 'easy apply']
        if company_lower in invalid:
            return False
        if re.match(r'^\d+[dhms]$', company_lower) or company.isdigit():
            return False
        return True
    
    # ==================== EXISTING SCRAPERS ====================
    
    def scrape_weworkremotely(self):
        """WeWorkRemotely - One of the largest remote job boards"""
        print("\n=== Scraping WeWorkRemotely ===")
        try:
            url = "https://weworkremotely.com/remote-jobs"
            response = requests.get(url, headers=self.headers, timeout=15)
            soup = BeautifulSoup(response.text, "html.parser")
            
            all_links = soup.find_all("a", href=True)
            processed = 0
            
            for link in all_links:
                href = link.get("href", "")
                if not href.startswith("/remote-jobs/") or "/remote-jobs/search" in href:
                    continue
                
                try:
                    text_parts = [part.strip() for part in link.get_text(separator="\n").split("\n") if part.strip()]
                    cleaned_parts = [self.clean_text(p) for p in text_parts if self.clean_text(p) and len(self.clean_text(p)) > 2]
                    
                    if len(cleaned_parts) < 2:
                        continue
                    
                    title = cleaned_parts[0]
                    company = None
                    for part in cleaned_parts[1:]:
                        if self.is_valid_company(part):
                            company = part
                            break
                    
                    if not company:
                        company = "WeWorkRemotely"
                    
                    skip_titles = ['remote jobs', 'categories', 'companies', 'post a job', 'log in', 'sign up']
                    if any(skip in title.lower() for skip in skip_titles):
                        continue
                    
                    full_url = "https://weworkremotely.com" + href
                    
                    if len(title) > 5 and len(company) > 2:
                        self.save_job("weworkremotely", title, company, "Remote", None, full_url)
                        processed += 1
                except:
                    continue
            
            print(f"Processed {processed} jobs from WeWorkRemotely")
        except Exception as e:
            print(f"Error scraping WeWorkRemotely: {e}")
    
    def scrape_remoteok_api(self):
        """Remote OK API - FREE, reliable"""
        print("\n=== Scraping Remote OK API ===")
        try:
            url = "https://remoteok.com/api"
            response = requests.get(url, headers=self.headers, timeout=15)
            jobs = response.json()[1:101]  # Skip metadata, get 100 jobs
            
            processed = 0
            for job in jobs:
                try:
                    title = job.get('position', '').strip()
                    company = job.get('company', 'Remote OK').strip()
                    location = job.get('location', 'Remote').strip()
                    tags = ', '.join(job.get('tags', [])[:5])
                    url_path = job.get('url', '')
                    job_url = f"https://remoteok.com{url_path}" if url_path else ""
                    
                    if len(title) > 5 and job_url:
                        self.save_job("remoteok_api", title, company, location, tags, job_url)
                        processed += 1
                except:
                    continue
            
            print(f"Processed {processed} jobs from Remote OK API")
        except Exception as e:
            print(f"Error scraping Remote OK API: {e}")
    
    def scrape_arbeitnow_api(self):
        """Arbeitnow API - FREE, European focus"""
        print("\n=== Scraping Arbeitnow API ===")
        try:
            url = "https://www.arbeitnow.com/api/job-board-api"
            response = requests.get(url, headers=self.headers, timeout=15)
            jobs = response.json().get('data', [])
            
            processed = 0
            for job in jobs:
                try:
                    title = job.get('title', '').strip()
                    company = job.get('company_name', 'Arbeitnow').strip()
                    location = job.get('location', 'Remote').strip()
                    tags = ', '.join(job.get('tags', []))
                    job_url = job.get('url', '')
                    
                    if 'remote' in location.lower() or 'remote' in tags.lower() or not location:
                        if len(title) > 5 and job_url:
                            self.save_job("arbeitnow", title, company, location, tags, job_url)
                            processed += 1
                except:
                    continue
            
            print(f"Processed {processed} jobs from Arbeitnow")
        except Exception as e:
            print(f"Error scraping Arbeitnow: {e}")
    
    # ==================== NEW SCRAPERS ====================
    
    def scrape_remotive(self):
        """Remotive - Curated remote jobs"""
        print("\n=== Scraping Remotive ===")
        try:
            url = "https://remotive.com/remote-jobs"
            response = requests.get(url, headers=self.headers, timeout=15)
            soup = BeautifulSoup(response.text, "html.parser")
            
            all_links = soup.find_all("a", href=True)
            processed = 0
            seen_urls = set()
            
            for link in all_links:
                href = link.get("href", "")
                if not href.startswith("/remote-jobs/") or href == "/remote-jobs":
                    continue
                
                full_url = "https://remotive.com" + href
                if full_url in seen_urls:
                    continue
                seen_urls.add(full_url)
                
                try:
                    link_text = self.clean_text(link.get_text(strip=True))
                    if len(link_text) < 5:
                        continue
                    
                    parent = link.parent
                    company = "Remotive"
                    if parent:
                        parent_text = parent.get_text(separator="|").split("|")
                        for text in parent_text:
                            cleaned = self.clean_text(text)
                            if self.is_valid_company(cleaned) and cleaned != link_text:
                                company = cleaned
                                break
                    
                    if len(link_text) > 5:
                        self.save_job("remotive", link_text, company, "Remote", None, full_url)
                        processed += 1
                except:
                    continue
            
            print(f"Processed {processed} jobs from Remotive")
        except Exception as e:
            print(f"Error scraping Remotive: {e}")
    
    def scrape_himalayas(self):
        """Himalayas - Clean, modern remote job board"""
        print("\n=== Scraping Himalayas ===")
        try:
            url = "https://himalayas.app/jobs"
            response = requests.get(url, headers=self.headers, timeout=15)
            soup = BeautifulSoup(response.text, "html.parser")
            
            job_links = soup.find_all("a", href=True)
            processed = 0
            seen_urls = set()
            
            for link in job_links:
                href = link.get("href", "")
                if not href.startswith("/jobs/") or len(href) < 10:
                    continue
                
                full_url = "https://himalayas.app" + href
                if full_url in seen_urls:
                    continue
                seen_urls.add(full_url)
                
                try:
                    title = self.clean_text(link.get_text(strip=True))
                    if len(title) < 5 or len(title) > 150:
                        continue
                    
                    # Find company in parent
                    company = "Himalayas"
                    parent = link.parent
                    if parent:
                        company_elem = parent.find(class_="company") or parent.find("span")
                        if company_elem:
                            comp_text = self.clean_text(company_elem.get_text(strip=True))
                            if self.is_valid_company(comp_text):
                                company = comp_text
                    
                    self.save_job("himalayas", title, company, "Remote", None, full_url)
                    processed += 1
                    
                    if processed >= 50:
                        break
                except:
                    continue
            
            print(f"Processed {processed} jobs from Himalayas")
        except Exception as e:
            print(f"Error scraping Himalayas: {e}")
    
    def scrape_justremote(self):
        """JustRemote - Remote jobs board"""
        print("\n=== Scraping JustRemote ===")
        try:
            url = "https://justremote.co/remote-jobs"
            response = requests.get(url, headers=self.headers, timeout=15)
            soup = BeautifulSoup(response.text, "html.parser")
            
            job_links = soup.find_all("a", href=True)
            processed = 0
            seen_urls = set()
            
            for link in job_links:
                href = link.get("href", "")
                if "/remote-" not in href or len(href) < 15:
                    continue
                
                if href.startswith("/"):
                    full_url = "https://justremote.co" + href
                else:
                    full_url = href
                
                if full_url in seen_urls or "remote-jobs" == href.strip("/"):
                    continue
                seen_urls.add(full_url)
                
                try:
                    title = self.clean_text(link.get_text(strip=True))
                    if len(title) < 5 or len(title) > 200:
                        continue
                    
                    company = "JustRemote"
                    parent = link.parent
                    if parent:
                        text_parts = parent.get_text(separator="|").split("|")
                        for part in text_parts:
                            cleaned = self.clean_text(part)
                            if self.is_valid_company(cleaned) and cleaned != title:
                                company = cleaned
                                break
                    
                    self.save_job("justremote", title, company, "Remote", None, full_url)
                    processed += 1
                    
                    if processed >= 50:
                        break
                except:
                    continue
            
            print(f"Processed {processed} jobs from JustRemote")
        except Exception as e:
            print(f"Error scraping JustRemote: {e}")
    
    def scrape_workingnomads(self):
        """Working Nomads - Digital nomad jobs"""
        print("\n=== Scraping Working Nomads ===")
        try:
            url = "https://www.workingnomads.com/jobs"
            response = requests.get(url, headers=self.headers, timeout=15)
            soup = BeautifulSoup(response.text, "html.parser")
            
            job_links = soup.find_all("a", href=True)
            processed = 0
            seen_urls = set()
            
            for link in job_links:
                href = link.get("href", "")
                if not href.startswith("/jobs?") or "company" in href:
                    continue
                
                full_url = "https://www.workingnomads.com" + href
                if full_url in seen_urls:
                    continue
                seen_urls.add(full_url)
                
                try:
                    title = self.clean_text(link.get_text(strip=True))
                    if len(title) < 5 or len(title) > 200:
                        continue
                    
                    company = "Working Nomads"
                    
                    self.save_job("workingnomads", title, company, "Remote", None, full_url)
                    processed += 1
                    
                    if processed >= 40:
                        break
                except:
                    continue
            
            print(f"Processed {processed} jobs from Working Nomads")
        except Exception as e:
            print(f"Error scraping Working Nomads: {e}")
    
    def scrape_pangian(self):
        """Pangian - Global remote jobs"""
        print("\n=== Scraping Pangian ===")
        try:
            url = "https://pangian.com/job-travel-remote/"
            response = requests.get(url, headers=self.headers, timeout=15)
            soup = BeautifulSoup(response.text, "html.parser")
            
            job_cards = soup.find_all(["article", "div"], class_=lambda x: x and "job" in str(x).lower())
            processed = 0
            
            for card in job_cards[:50]:
                try:
                    link = card.find("a", href=True)
                    if not link:
                        continue
                    
                    href = link.get("href", "")
                    if not href or len(href) < 10:
                        continue
                    
                    if not href.startswith("http"):
                        href = "https://pangian.com" + href
                    
                    title = self.clean_text(link.get_text(strip=True))
                    if len(title) < 5:
                        title_elem = card.find(["h2", "h3", "h4"])
                        if title_elem:
                            title = self.clean_text(title_elem.get_text(strip=True))
                    
                    company = "Pangian"
                    company_elem = card.find(class_=lambda x: x and "company" in str(x).lower())
                    if company_elem:
                        comp_text = self.clean_text(company_elem.get_text(strip=True))
                        if self.is_valid_company(comp_text):
                            company = comp_text
                    
                    if len(title) > 5:
                        self.save_job("pangian", title, company, "Remote", None, href)
                        processed += 1
                except:
                    continue
            
            print(f"Processed {processed} jobs from Pangian")
        except Exception as e:
            print(f"Error scraping Pangian: {e}")
    
    def scrape_remoteco(self):
        """Remote.co - Remote work resources and jobs"""
        print("\n=== Scraping Remote.co ===")
        try:
            url = "https://remote.co/remote-jobs/"
            response = requests.get(url, headers=self.headers, timeout=15)
            soup = BeautifulSoup(response.text, "html.parser")
            
            job_links = soup.find_all("a", href=True)
            processed = 0
            seen_urls = set()
            
            for link in job_links:
                href = link.get("href", "")
                
                if "/remote-jobs/" not in href or href.endswith("/remote-jobs/"):
                    continue
                
                if href.startswith("http"):
                    full_url = href
                else:
                    full_url = "https://remote.co" + href
                
                if full_url in seen_urls:
                    continue
                seen_urls.add(full_url)
                
                try:
                    title = self.clean_text(link.get_text(strip=True))
                    if len(title) < 5 or len(title) > 150:
                        continue
                    
                    company = "Remote.co"
                    parent = link.parent
                    if parent:
                        text_parts = parent.get_text(separator="|").split("|")
                        for part in text_parts:
                            cleaned = self.clean_text(part)
                            if self.is_valid_company(cleaned) and cleaned != title:
                                company = cleaned
                                break
                    
                    self.save_job("remoteco", title, company, "Remote", None, full_url)
                    processed += 1
                    
                    if processed >= 40:
                        break
                except:
                    continue
            
            print(f"Processed {processed} jobs from Remote.co")
        except Exception as e:
            print(f"Error scraping Remote.co: {e}")
    
    def scrape_nodesk(self):
        """NoDesk - Digital nomad remote jobs"""
        print("\n=== Scraping NoDesk ===")
        try:
            url = "https://nodesk.co/remote-jobs/"
            response = requests.get(url, headers=self.headers, timeout=15)
            soup = BeautifulSoup(response.text, "html.parser")
            
            job_cards = soup.find_all(["div", "article"], class_=lambda x: x and "job" in str(x).lower())
            processed = 0
            
            for card in job_cards[:50]:
                try:
                    link = card.find("a", href=True)
                    if not link:
                        continue
                    
                    href = link.get("href", "")
                    if not href.startswith("http"):
                        href = "https://nodesk.co" + href
                    
                    title = self.clean_text(link.get_text(strip=True))
                    if len(title) < 5:
                        continue
                    
                    company = "NoDesk"
                    company_elem = card.find(class_="company")
                    if company_elem:
                        comp_text = self.clean_text(company_elem.get_text(strip=True))
                        if self.is_valid_company(comp_text):
                            company = comp_text
                    
                    self.save_job("nodesk", title, company, "Remote", None, href)
                    processed += 1
                except:
                    continue
            
            print(f"Processed {processed} jobs from NoDesk")
        except Exception as e:
            print(f"Error scraping NoDesk: {e}")
    
    def scrape_remoters(self):
        """Remoters - Remote job listings"""
        print("\n=== Scraping Remoters ===")
        try:
            url = "https://remoters.net/jobs/"
            response = requests.get(url, headers=self.headers, timeout=15)
            soup = BeautifulSoup(response.text, "html.parser")
            
            job_links = soup.find_all("a", href=True)
            processed = 0
            seen_urls = set()
            
            for link in job_links:
                href = link.get("href", "")
                if "/jobs/" not in href or href == "/jobs/":
                    continue
                
                full_url = "https://remoters.net" + href if href.startswith("/") else href
                if full_url in seen_urls:
                    continue
                seen_urls.add(full_url)
                
                try:
                    title = self.clean_text(link.get_text(strip=True))
                    if len(title) < 5 or len(title) > 200:
                        continue
                    
                    company = "Remoters"
                    
                    self.save_job("remoters", title, company, "Remote", None, full_url)
                    processed += 1
                    
                    if processed >= 30:
                        break
                except:
                    continue
            
            print(f"Processed {processed} jobs from Remoters")
        except Exception as e:
            print(f"Error scraping Remoters: {e}")
    
    def scrape_powertofly(self):
        """PowerToFly - Diversity-focused remote jobs"""
        print("\n=== Scraping PowerToFly ===")
        try:
            url = "https://powertofly.com/jobs/"
            response = requests.get(url, headers=self.headers, timeout=15)
            soup = BeautifulSoup(response.text, "html.parser")
            
            job_links = soup.find_all("a", href=True)
            processed = 0
            seen_urls = set()
            
            for link in job_links:
                href = link.get("href", "")
                if "/jobs/" not in href or len(href) < 15:
                    continue
                
                full_url = "https://powertofly.com" + href if href.startswith("/") else href
                if full_url in seen_urls:
                    continue
                seen_urls.add(full_url)
                
                try:
                    title = self.clean_text(link.get_text(strip=True))
                    if len(title) < 5 or len(title) > 200:
                        continue
                    
                    company = "PowerToFly"
                    parent = link.parent
                    if parent:
                        company_elem = parent.find(class_=lambda x: x and "company" in str(x).lower())
                        if company_elem:
                            comp_text = self.clean_text(company_elem.get_text(strip=True))
                            if self.is_valid_company(comp_text):
                                company = comp_text
                    
                    self.save_job("powertofly", title, company, "Remote", None, full_url)
                    processed += 1
                    
                    if processed >= 40:
                        break
                except:
                    continue
            
            print(f"Processed {processed} jobs from PowerToFly")
        except Exception as e:
            print(f"Error scraping PowerToFly: {e}")
    
    # ==================== MIDDLE EAST / MENA SOURCES ====================
    
    def scrape_bayt(self):
        """Bayt.com - Leading Middle East job site"""
        print("\n=== Scraping Bayt.com ===")
        try:
            # Search for remote jobs
            url = "https://www.bayt.com/en/international/jobs/remote-jobs/"
            response = requests.get(url, headers=self.headers, timeout=15)
            soup = BeautifulSoup(response.text, "html.parser")
            
            job_cards = soup.find_all(["li", "div"], class_=lambda x: x and "job" in str(x).lower())
            processed = 0
            
            for card in job_cards[:60]:
                try:
                    link = card.find("a", href=True)
                    if not link:
                        continue
                    
                    href = link.get("href", "")
                    if not href or "bayt.com" not in href:
                        if href.startswith("/"):
                            href = "https://www.bayt.com" + href
                        else:
                            continue
                    
                    title = self.clean_text(link.get_text(strip=True))
                    if len(title) < 5:
                        title_elem = card.find(["h2", "h3"])
                        if title_elem:
                            title = self.clean_text(title_elem.get_text(strip=True))
                    
                    company = "Bayt.com"
                    company_elem = card.find(class_=lambda x: x and "company" in str(x).lower())
                    if company_elem:
                        comp_text = self.clean_text(company_elem.get_text(strip=True))
                        if self.is_valid_company(comp_text):
                            company = comp_text
                    
                    if len(title) > 5:
                        self.save_job("bayt", title, company, "Middle East/Remote", None, href)
                        processed += 1
                except:
                    continue
            
            print(f"Processed {processed} jobs from Bayt.com")
        except Exception as e:
            print(f"Error scraping Bayt: {e}")
    
    def scrape_linkedin_remote(self):
        """LinkedIn - Remote jobs (limited scraping, respectful)"""
        print("\n=== Scraping LinkedIn Remote Jobs ===")
        try:
            # LinkedIn f_WT parameter filters for remote jobs
            url = "https://www.linkedin.com/jobs/search?f_WT=2"
            response = requests.get(url, headers=self.headers, timeout=15)
            soup = BeautifulSoup(response.text, "html.parser")
            
            job_cards = soup.find_all(["li", "div"], class_=lambda x: x and "job" in str(x).lower())
            processed = 0
            
            for card in job_cards[:30]:  # Limit to be respectful
                try:
                    link = card.find("a", href=True)
                    if not link or "linkedin.com/jobs" not in link.get("href", ""):
                        continue
                    
                    href = link.get("href", "")
                    
                    title = self.clean_text(link.get_text(strip=True))
                    if len(title) < 5:
                        title_elem = card.find(["h3", "h4"])
                        if title_elem:
                            title = self.clean_text(title_elem.get_text(strip=True))
                    
                    company = "LinkedIn"
                    company_elem = card.find(class_=lambda x: x and "company" in str(x).lower())
                    if company_elem:
                        comp_text = self.clean_text(company_elem.get_text(strip=True))
                        if self.is_valid_company(comp_text):
                            company = comp_text
                    
                    if len(title) > 5 and href:
                        self.save_job("linkedin", title, company, "Remote", None, href)
                        processed += 1
                except:
                    continue
            
            print(f"Processed {processed} jobs from LinkedIn")
        except Exception as e:
            print(f"Error scraping LinkedIn: {e}")
    
    def scrape_indeed_remote(self):
        """Indeed - Remote jobs"""
        print("\n=== Scraping Indeed Remote Jobs ===")
        try:
            url = "https://www.indeed.com/jobs?q=remote&l=&remotejob=032b3046-06a3-4876-8dfd-474eb5e7ed11"
            response = requests.get(url, headers=self.headers, timeout=15)
            soup = BeautifulSoup(response.text, "html.parser")
            
            job_cards = soup.find_all(["div", "td"], class_=lambda x: x and "job" in str(x).lower())
            processed = 0
            
            for card in job_cards[:50]:
                try:
                    link = card.find("a", href=True)
                    if not link:
                        continue
                    
                    href = link.get("href", "")
                    if "/rc/clk" in href or "/viewjob" in href or "/pagead" in href:
                        if not href.startswith("http"):
                            href = "https://www.indeed.com" + href
                    else:
                        continue
                    
                    title = self.clean_text(link.get_text(strip=True))
                    if len(title) < 5:
                        title_elem = card.find(["h2", "span"])
                        if title_elem:
                            title = self.clean_text(title_elem.get_text(strip=True))
                    
                    company = "Indeed"
                    company_elem = card.find(class_=lambda x: x and "company" in str(x).lower())
                    if company_elem:
                        comp_text = self.clean_text(company_elem.get_text(strip=True))
                        if self.is_valid_company(comp_text):
                            company = comp_text
                    
                    if len(title) > 5:
                        self.save_job("indeed", title, company, "Remote", None, href)
                        processed += 1
                except:
                    continue
            
            print(f"Processed {processed} jobs from Indeed")
        except Exception as e:
            print(f"Error scraping Indeed: {e}")
    
    def save_job(self, source, title, company, location, description, job_url):
        """Save job to database"""
        try:
            if not job_url or not title or not company:
                return
            
            title = title.strip()[:255]
            company = company.strip()[:255]
            location = (location or "Remote").strip()[:255]
            description = (description or "")[:500]
            
            if not self.is_valid_company(company):
                company = source.title()
            
            self.cur.execute("""
                INSERT INTO jobs (source, job_title, company, location, description, job_url, scraped_at)
                VALUES (%s, %s, %s, %s, %s, %s, NOW())
                ON CONFLICT (job_url) DO NOTHING;
            """, (source, title, company, location, description, job_url))
            
            if self.cur.rowcount > 0:
                self.jobs_saved += 1
                if self.jobs_saved % 25 == 0:
                    print(f"  ✓ Saved {self.jobs_saved} jobs so far...")
        except:
            pass
    
    def run_all(self):
        """Run all scrapers"""
        start_time = time.time()
        print(f"\n{'='*70}")
        print(f"🌍 COMPREHENSIVE JOB SCRAPING - 20+ SOURCES")
        print(f"Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        print(f"{'='*70}")
        
        # Core reliable sources
        self.scrape_weworkremotely()
        time.sleep(2)
        
        # API sources (most reliable)
        self.scrape_remoteok_api()
        time.sleep(2)
        
        self.scrape_arbeitnow_api()
        time.sleep(2)
        
        # Additional web sources
        self.scrape_remotive()
        time.sleep(2)
        
        self.scrape_himalayas()
        time.sleep(2)
        
        self.scrape_justremote()
        time.sleep(2)
        
        self.scrape_workingnomads()
        time.sleep(2)
        
        self.scrape_pangian()
        time.sleep(2)
        
        self.scrape_remoteco()
        time.sleep(2)
        
        self.scrape_nodesk()
        time.sleep(2)
        
        self.scrape_remoters()
        time.sleep(2)
        
        self.scrape_powertofly()
        time.sleep(2)
        
        # Major job boards
        self.scrape_linkedin_remote()
        time.sleep(3)
        
        self.scrape_indeed_remote()
        time.sleep(3)
        
        # Middle East / MENA
        self.scrape_bayt()
        
        # Commit
        print(f"\n{'='*70}")
        print(f"💾 Committing {self.jobs_saved} jobs to database...")
        self.conn.commit()
        
        # Statistics
        self.cur.execute("SELECT source, COUNT(*) FROM jobs GROUP BY source ORDER BY COUNT(*) DESC")
        stats = self.cur.fetchall()
        
        print(f"\n{'='*70}")
        print("✅ SCRAPING COMPLETE - Final Statistics:")
        print(f"{'='*70}")
        
        if stats:
            for source, count in stats:
                print(f"{source:20s}: {count:4d} jobs")
        
        self.cur.execute("SELECT COUNT(*) FROM jobs")
        total = self.cur.fetchone()[0]
        
        self.cur.execute("SELECT COUNT(DISTINCT company) FROM jobs")
        companies = self.cur.fetchone()[0]
        
        print(f"\n{'='*70}")
        print(f"📊 TOTAL JOBS IN DATABASE: {total}")
        print(f"📊 UNIQUE COMPANIES: {companies}")
        print(f"📊 JOBS SAVED THIS RUN: {self.jobs_saved}")
        print(f"⏱️  TIME ELAPSED: {time.time() - start_time:.2f} seconds")
        print(f"{'='*70}\n")
        
        self.conn.close()

if __name__ == "__main__":
    scraper = ComprehensiveJobScraper()
    scraper.run_all()