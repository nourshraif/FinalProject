"""
Compare Keyword Matching vs Vector Matching

This script demonstrates why vector matching is superior.
"""

import time
from skill_matcher import SkillMatcherFree
from vector_skill_matcher import VectorSkillMatcher


def compare_matchers():
    """Compare keyword and vector matching side-by-side."""
    
    print("\n" + "="*80)
    print(" "*25 + "KEYWORD vs VECTOR MATCHING")
    print("="*80)
    
    # Test skills
    test_skills = [
        "Python",
        "React", 
        "PostgreSQL",
        "Docker",
        "REST API"
    ]
    
    print(f"\nTest Skills: {', '.join(test_skills)}")
    print("-"*80)
    
    # ============== KEYWORD MATCHING ==============
    print("\n" + "="*80)
    print("METHOD 1: KEYWORD MATCHING (Pattern-based)")
    print("="*80)
    
    print("\nHow it works:")
    print("  • Searches for exact skill names in job descriptions")
    print("  • Uses regex patterns for variations (e.g., 'React' matches 'ReactJS')")
    print("  • Fast but limited - can't understand context")
    
    print("\nRunning keyword matcher...")
    start_time = time.time()
    
    try:
        keyword_matcher = SkillMatcherFree()
        keyword_matches = keyword_matcher.find_matching_jobs(
            cv_skills=test_skills,
            min_match_percentage=30,
            limit=10
        )
        keyword_time = time.time() - start_time
        keyword_matcher.close()
        
        print(f"\n✓ Found {len(keyword_matches)} matches in {keyword_time:.2f}s")
        
        if keyword_matches:
            print("\nTop 3 Keyword Matches:")
            for i, job in enumerate(keyword_matches[:3], 1):
                print(f"\n{i}. {job['title'][:60]}")
                print(f"   Company: {job['company'][:40]}")
                print(f"   Match: {job['match_percentage']:.1f}%")
                print(f"   Exact matches: {', '.join(job['exact_matches'][:3])}")
    
    except Exception as e:
        print(f"❌ Keyword matcher error: {e}")
        keyword_matches = []
        keyword_time = 0
    
    # ============== VECTOR MATCHING ==============
    print("\n\n" + "="*80)
    print("METHOD 2: VECTOR MATCHING (Semantic AI)")
    print("="*80)
    
    print("\nHow it works:")
    print("  • Converts skills and jobs to numerical vectors (embeddings)")
    print("  • Understands meaning and context, not just exact words")
    print("  • Finds semantically similar jobs even with different terminology")
    
    print("\nRunning vector matcher...")
    start_time = time.time()
    
    try:
        vector_matcher = VectorSkillMatcher()
        
        # Check if embeddings exist
        vector_matcher.cur.execute("SELECT COUNT(*) FROM job_embeddings")
        embedding_count = vector_matcher.cur.fetchone()[0]
        
        if embedding_count == 0:
            print("\n⚠️  No embeddings found. Generating now (one-time, ~2 minutes)...")
            vector_matcher.generate_job_embeddings()
        else:
            print(f"✓ Using existing embeddings for {embedding_count} jobs")
        
        vector_matches = vector_matcher.find_matching_jobs_hybrid(
            cv_skills=test_skills,
            top_k=10,
            vector_weight=0.7,
            keyword_weight=0.3
        )
        vector_time = time.time() - start_time
        vector_matcher.close()
        
        print(f"\n✓ Found {len(vector_matches)} matches in {vector_time:.2f}s")
        
        if vector_matches:
            print("\nTop 3 Vector Matches:")
            for i, job in enumerate(vector_matches[:3], 1):
                print(f"\n{i}. {job['title'][:60]}")
                print(f"   Company: {job['company'][:40]}")
                print(f"   Overall: {job['match_percentage']:.1f}%")
                print(f"   Vector: {job['vector_similarity']*100:.1f}% | Keywords: {job['keyword_score']*100:.1f}%")
    
    except Exception as e:
        print(f"❌ Vector matcher error: {e}")
        print("\nMake sure you have:")
        print("  1. Installed: pip install sentence-transformers pgvector")
        print("  2. Enabled pgvector in PostgreSQL")
        vector_matches = []
        vector_time = 0
    
    # ============== COMPARISON ==============
    print("\n\n" + "="*80)
    print("COMPARISON & ANALYSIS")
    print("="*80)
    
    print(f"\n{'Metric':<30} {'Keyword':<20} {'Vector':<20}")
    print("-"*70)
    print(f"{'Matches Found':<30} {len(keyword_matches):<20} {len(vector_matches):<20}")
    print(f"{'Speed':<30} {keyword_time:.2f}s{'':<17} {vector_time:.2f}s")
    
    if keyword_matches and vector_matches:
        keyword_avg = sum(j['match_percentage'] for j in keyword_matches) / len(keyword_matches)
        vector_avg = sum(j['match_percentage'] for j in vector_matches) / len(vector_matches)
        print(f"{'Avg Match Score':<30} {keyword_avg:.1f}%{'':<16} {vector_avg:.1f}%")
        
        # Find unique matches
        keyword_jobs = set(j['job_id'] for j in keyword_matches)
        vector_jobs = set(j['job_id'] for j in vector_matches)
        
        only_keyword = len(keyword_jobs - vector_jobs)
        only_vector = len(vector_jobs - keyword_jobs)
        both = len(keyword_jobs & vector_jobs)
        
        print(f"\n{'Match Overlap:':<30}")
        print(f"  Found by both methods: {both}")
        print(f"  Only keyword: {only_keyword}")
        print(f"  Only vector: {only_vector} ← Semantic understanding found these!")
    
    # ============== EXAMPLES ==============
    print("\n\n" + "="*80)
    print("WHY VECTOR MATCHING IS BETTER")
    print("="*80)
    
    print("""
Example Scenarios:

1. Different Terminology:
   Your Skill: "React"
   
   Keyword: Only finds exact "React", "ReactJS", "React.js"
   Vector:  Also finds "Frontend framework", "Component-based UI", 
            "Modern JavaScript library" ✓

2. Related Skills:
   Your Skill: "PostgreSQL"
   
   Keyword: Only finds "PostgreSQL", "Postgres"
   Vector:  Also finds "Relational database", "SQL database experience",
            "Database administration" ✓

3. Context Understanding:
   Your Skill: "Docker"
   
   Keyword: Only finds "Docker"
   Vector:  Also finds "Containerization", "Container orchestration",
            "Microservices deployment" ✓

4. Experience Levels:
   Your Skill: "Python"
   
   Keyword: Finds any mention of "Python" (junior or senior)
   Vector:  Understands context and can differentiate between
            "Python basics" vs "Advanced Python architecture" ✓
""")
    
    # ============== RECOMMENDATIONS ==============
    print("\n" + "="*80)
    print("RECOMMENDATIONS")
    print("="*80)
    
    print("""
When to use KEYWORD matching:
  ✓ Need fast results (no setup time)
  ✓ Looking for specific, well-defined skills
  ✓ No pgvector setup available
  ✓ Prototyping/testing

When to use VECTOR matching:
  ✓ Want best possible matches (recommended!)
  ✓ Open to jobs with different terminology
  ✓ Looking for career growth opportunities
  ✓ Production use with recurring searches
  ✓ Want to discover jobs you didn't think to search for

Best Approach: HYBRID (70% vector + 30% keyword)
  ✓ Combines semantic understanding with exact matches
  ✓ Finds both obvious and hidden opportunities
  ✓ Most recommended for job searching
""")
    
    print("="*80)
    print("Comparison complete!")
    print("="*80 + "\n")
    
    return {
        'keyword_count': len(keyword_matches),
        'vector_count': len(vector_matches),
        'keyword_time': keyword_time,
        'vector_time': vector_time
    }


if __name__ == "__main__":
    print("""
╔══════════════════════════════════════════════════════════════════════════════╗
║                                                                              ║
║                   KEYWORD vs VECTOR MATCHING COMPARISON                      ║
║                                                                              ║
║  This script compares traditional keyword matching with advanced vector      ║
║  semantic matching to show you why vector embeddings are superior.          ║
║                                                                              ║
╚══════════════════════════════════════════════════════════════════════════════╝
    """)
    
    proceed = input("Ready to run comparison? (y/n): ").lower()
    
    if proceed == 'y':
        results = compare_matchers()
        
        print("\n💡 Next Steps:")
        print("   1. Run 'streamlit run vector_app.py' for the full experience")
        print("   2. Try different skills to see the difference")
        print("   3. Adjust hybrid weights (70/30, 80/20, etc.)")
    else:
        print("\nOkay! Run this script when you're ready to see the comparison.")