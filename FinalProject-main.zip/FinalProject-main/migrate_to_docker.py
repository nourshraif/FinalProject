"""
Automated PostgreSQL to Docker Migration Script

This script automates the entire migration process:
1. Backs up your current database
2. Starts Docker container with pgvector
3. Restores data to Docker
4. Enables pgvector extension
5. Verifies everything works

Run this and your migration is done!
"""

import subprocess
import sys
import time
import os

def print_header(text):
    """Print formatted header"""
    print("\n" + "="*70)
    print(f"  {text}")
    print("="*70)

def print_step(step_num, text):
    """Print step header"""
    print(f"\n{'─'*70}")
    print(f"Step {step_num}: {text}")
    print(f"{'─'*70}")

def run_command(cmd, shell=True, check=False):
    """Run shell command and return success status"""
    try:
        result = subprocess.run(
            cmd, 
            shell=shell, 
            capture_output=True, 
            text=True,
            check=check
        )
        if result.stdout:
            print(result.stdout)
        if result.stderr and result.returncode != 0:
            print(f"Error: {result.stderr}")
        return result.returncode == 0
    except Exception as e:
        print(f"Error running command: {e}")
        return False

def check_docker():
    """Check if Docker is installed and running"""
    print_step(1, "Checking Docker Installation")
    
    # Check Docker is installed
    if not run_command("docker --version"):
        print("\n❌ Docker is not installed!")
        print("\nPlease install Docker Desktop:")
        print("https://www.docker.com/products/docker-desktop/")
        return False
    
    # Check Docker is running
    if not run_command("docker ps"):
        print("\n❌ Docker is not running!")
        print("\nPlease start Docker Desktop and try again.")
        return False
    
    print("✓ Docker is installed and running")
    return True

def backup_database():
    """Backup current PostgreSQL database"""
    print_step(2, "Backing Up Current Database")
    
    backup_file = "jobs_db_backup.sql"
    
    # Try to find pg_dump
    pg_dump_paths = [
        r"C:\Program Files\PostgreSQL\16\bin\pg_dump.exe",
        r"C:\Program Files\PostgreSQL\15\bin\pg_dump.exe",
        r"C:\Program Files\PostgreSQL\14\bin\pg_dump.exe",
        r"C:\Program Files (x86)\PostgreSQL\16\bin\pg_dump.exe",
    ]
    
    pg_dump = None
    for path in pg_dump_paths:
        if os.path.exists(path):
            pg_dump = path
            break
    
    if not pg_dump:
        print("❌ Could not find pg_dump.exe")
        print("\nPlease backup manually:")
        print('pg_dump -h localhost -U postgres -d jobs_db > jobs_db_backup.sql')
        return False
    
    print(f"Found pg_dump at: {pg_dump}")
    print(f"\nBacking up to: {backup_file}")
    print("You may be prompted for password: AliTlais@2004")
    
    cmd = f'"{pg_dump}" -h localhost -U postgres -d jobs_db > {backup_file}'
    
    # This might prompt for password interactively
    os.system(cmd)
    
    if os.path.exists(backup_file):
        size = os.path.getsize(backup_file)
        print(f"✓ Backup created: {backup_file} ({size:,} bytes)")
        return True
    else:
        print("❌ Backup failed!")
        return False

def setup_docker_container():
    """Set up Docker PostgreSQL container with pgvector"""
    print_step(3, "Setting Up Docker Container")
    
    # Check if container already exists
    result = subprocess.run(
        "docker ps -a --filter name=postgres-vector --format {{.Names}}", 
        shell=True, 
        capture_output=True, 
        text=True
    )
    
    if "postgres-vector" in result.stdout:
        print("Container 'postgres-vector' already exists.")
        
        # Check if it's running
        result = subprocess.run(
            "docker ps --filter name=postgres-vector --format {{.Names}}", 
            shell=True, 
            capture_output=True, 
            text=True
        )
        
        if "postgres-vector" in result.stdout:
            print("✓ Container is already running")
        else:
            print("Starting existing container...")
            run_command("docker start postgres-vector")
            print("✓ Container started")
    else:
        print("Creating new Docker container with pgvector...")
        
        cmd = (
            "docker run -d "
            "--name postgres-vector "
            "-e POSTGRES_PASSWORD=AliTlais@2004 "
            "-e POSTGRES_USER=postgres "
            "-e POSTGRES_DB=jobs_db "
            "-p 5432:5432 "
            "-v pgvector-data:/var/lib/postgresql/data "
            "pgvector/pgvector:pg16"
        )
        
        if run_command(cmd):
            print("✓ Container created successfully")
        else:
            print("❌ Failed to create container")
            print("\nIf port 5432 is in use, you need to:")
            print("1. Stop your current PostgreSQL: net stop postgresql-x64-16")
            print("2. Or use a different port (see MIGRATION_GUIDE.md)")
            return False
    
    # Wait for PostgreSQL to be ready
    print("\nWaiting for PostgreSQL to start...")
    for i in range(10):
        time.sleep(2)
        result = subprocess.run(
            'docker exec postgres-vector psql -U postgres -d jobs_db -c "SELECT 1"',
            shell=True,
            capture_output=True,
            text=True
        )
        if result.returncode == 0:
            print("✓ PostgreSQL is ready")
            return True
        print(f"  Waiting... ({i+1}/10)")
    
    print("⚠️  PostgreSQL might not be ready yet, continuing anyway...")
    return True

def restore_database():
    """Restore database to Docker container"""
    print_step(4, "Restoring Database to Docker")
    
    backup_file = "jobs_db_backup.sql"
    
    if not os.path.exists(backup_file):
        print(f"❌ Backup file not found: {backup_file}")
        return False
    
    print(f"Restoring from: {backup_file}")
    
    # Copy backup file to container
    print("Copying backup to container...")
    if not run_command(f"docker cp {backup_file} postgres-vector:/tmp/backup.sql"):
        print("❌ Failed to copy backup file")
        return False
    print("✓ Backup copied")
    
    # Restore the backup
    print("\nRestoring data (this may take a minute)...")
    cmd = 'docker exec postgres-vector psql -U postgres -d jobs_db -f /tmp/backup.sql'
    
    # This might produce warnings, that's okay
    os.system(cmd + " 2>nul")  # Suppress stderr on Windows
    
    print("✓ Data restored")
    return True

def enable_pgvector():
    """Enable pgvector extension"""
    print_step(5, "Enabling pgvector Extension")
    
    cmd = 'docker exec postgres-vector psql -U postgres -d jobs_db -c "CREATE EXTENSION IF NOT EXISTS vector;"'
    
    if run_command(cmd):
        print("✓ pgvector extension enabled")
        return True
    else:
        print("❌ Failed to enable pgvector")
        return False

def verify_migration():
    """Verify migration was successful"""
    print_step(6, "Verifying Migration")
    
    try:
        # Import here to avoid issues if database.py doesn't exist yet
        from database import get_connection
        
        print("Connecting to Docker database...")
        conn = get_connection()
        cur = conn.cursor()
        
        # Check job count
        cur.execute("SELECT COUNT(*) FROM jobs")
        job_count = cur.fetchone()[0]
        print(f"✓ Found {job_count} jobs in database")
        
        # Check pgvector
        cur.execute("SELECT extname FROM pg_extension WHERE extname = 'vector'")
        if cur.fetchone():
            print("✓ pgvector extension is enabled")
        else:
            print("⚠️  pgvector extension not found")
        
        # Check tables
        cur.execute("""
            SELECT table_name 
            FROM information_schema.tables 
            WHERE table_schema = 'public'
            ORDER BY table_name
        """)
        tables = [row[0] for row in cur.fetchall()]
        print(f"✓ Found {len(tables)} tables: {', '.join(tables)}")
        
        conn.close()
        return True
        
    except Exception as e:
        print(f"❌ Verification failed: {e}")
        print("\nTroubleshooting:")
        print("1. Make sure database.py has correct connection settings")
        print("2. Check container is running: docker ps")
        print("3. Check logs: docker logs postgres-vector")
        return False

def print_success_message():
    """Print success message and next steps"""
    print_header("✅ MIGRATION COMPLETE!")
    
    print("""
Your PostgreSQL database has been successfully migrated to Docker!

📊 Summary:
  • Database: jobs_db
  • Container: postgres-vector  
  • Port: 5432
  • pgvector: Enabled ✓
  • Data: Persisted in Docker volume 'pgvector-data'

🎯 Next Steps:

1. Test vector matching:
   python vector_skill_matcher.py

2. Run the vector app:
   streamlit run vector_app.py

3. Generate embeddings (first time):
   In the app, click "Generate Job Embeddings"

📝 Useful Commands:

  docker ps                        # Check container status
  docker logs postgres-vector      # View logs
  docker stop postgres-vector      # Stop container
  docker start postgres-vector     # Start container
  
  # Connect to database:
  docker exec -it postgres-vector psql -U postgres -d jobs_db

⚠️  Your Original PostgreSQL:
  If you stopped it, you can restart with:
  net start postgresql-x64-16
  
  Your data is safe in both places!

🎉 You're all set! Enjoy semantic job matching with pgvector!
    """)

def main():
    """Main migration process"""
    print_header("🚀 PostgreSQL to Docker Migration Script")
    
    print("""
This script will:
1. Backup your current jobs_db database
2. Create a Docker container with PostgreSQL + pgvector
3. Restore your data to the Docker container
4. Enable the pgvector extension
5. Verify everything works

Your original database will NOT be deleted or modified.
The backup file will be saved as: jobs_db_backup.sql

Press Ctrl+C to cancel at any time.
    """)
    
    input("Press Enter to start migration...")
    
    # Run migration steps
    steps = [
        (check_docker, "Docker check"),
        (backup_database, "Database backup"),
        (setup_docker_container, "Docker setup"),
        (restore_database, "Data restore"),
        (enable_pgvector, "pgvector setup"),
        (verify_migration, "Verification"),
    ]
    
    for step_func, step_name in steps:
        if not step_func():
            print(f"\n❌ Migration failed at: {step_name}")
            print("\nPlease check the errors above and try again.")
            print("See MIGRATION_GUIDE.md for manual instructions.")
            return False
    
    # Success!
    print_success_message()
    return True

if __name__ == "__main__":
    try:
        success = main()
        sys.exit(0 if success else 1)
    except KeyboardInterrupt:
        print("\n\n⚠️  Migration cancelled by user.")
        sys.exit(1)
    except Exception as e:
        print(f"\n❌ Unexpected error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)