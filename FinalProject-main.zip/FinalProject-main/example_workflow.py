"""
Complete Workflow Example
Demonstrates the full CV skill matching pipeline
"""

from skill_matcher import SkillMatcher, format_job_match
import sys

def example_workflow():
    """
    Complete example of the CV skill matching workflow.
    This demonstrates how to use the system programmatically.
    """
    
    print("="*70)
    print("CV SKILL MATCHER - Complete Workflow Example")
    print("="*70)
    
    # Example: Skills extracted from a user's CV
    # In reality, these would come from the CV extraction process
    cv_skills = [
        "Python",
        "JavaScript", 
        "React",
        "Node.js",
        "Django",
        "PostgreSQL",
        "MongoDB",
        "Git",
        "Docker",
        "AWS",
        "REST APIs",
        "GraphQL",
        "Machine Learning",
        "TensorFlow",
        "Pandas"
    ]
    
    print(f"\nYour CV Skills ({len(cv_skills)}):")
    print("-" * 70)
    for i, skill in enumerate(cv_skills, 1):
        print(f"{i:2}. {skill}")
    
    print("\n" + "="*70)
    print("STEP 1: Initialize Skill Matcher")
    print("="*70)
    
    try:
        matcher = SkillMatcher(model_name="openai/gpt-oss-120b:groq")
        print("✓ Skill matcher initialized successfully")
    except Exception as e:
        print(f"✗ Error initializing matcher: {e}")
        print("\nMake sure you have:")
        print("  1. Set HF_TOKEN in your .env file")
        print("  2. Run 'python setup_database.py' to create tables")
        print("  3. Run 'python run_scraper.py --mode web' to get jobs")
        return
    
    print("\n" + "="*70)
    print("STEP 2: Find Matching Jobs")
    print("="*70)
    print(f"Searching database for jobs matching your skills...")
    print(f"Minimum match threshold: 40%")
    print(f"Maximum jobs to analyze: 25")
    
    try:
        matching_jobs = matcher.find_matching_jobs(
            cv_skills=cv_skills,
            min_match_percentage=40,
            limit=25
        )
        
        if not matching_jobs:
            print("\n✗ No matching jobs found!")
            print("\nTips:")
            print("  - Lower the min_match_percentage (e.g., 30%)")
            print("  - Run scrapers to get more jobs: python run_scraper.py --mode web")
            print("  - Check database has jobs: python monitor.py")
            matcher.close()
            return
        
        print(f"\n✓ Found {len(matching_jobs)} matching jobs!")
        
    except Exception as e:
        print(f"\n✗ Error finding jobs: {e}")
        matcher.close()
        return
    
    print("\n" + "="*70)
    print("STEP 3: Display Top Matches")
    print("="*70)
    
    # Show top 5 matches
    print(f"\nShowing top 5 matches out of {len(matching_jobs)} total:\n")
    
    for i, job in enumerate(matching_jobs[:5], 1):
        print(f"\n{'#'*70}")
        print(f"# MATCH {i} - {job['match_percentage']:.0f}% MATCH")
        print(f"{'#'*70}")
        print(f"\n📋 Job Title: {job['title']}")
        print(f"🏢 Company: {job['company']}")
        print(f"📍 Location: {job['location']}")
        print(f"🌐 Source: {job['source']}")
        print(f"🔗 URL: {job['url']}")
        
        print(f"\n📊 Match Details:")
        print(f"   Score: {job['match_score']:.1f} / {job['total_required']} skills")
        print(f"   Percentage: {job['match_percentage']:.1f}%")
        
        if job['exact_matches']:
            print(f"\n✅ Your Matching Skills ({len(job['exact_matches'])}):")
            for skill in job['exact_matches'][:8]:
                print(f"   • {skill}")
            if len(job['exact_matches']) > 8:
                print(f"   ... and {len(job['exact_matches']) - 8} more")
        
        if job['partial_matches']:
            print(f"\n≈ Partial Matches ({len(job['partial_matches'])}):")
            for cv_skill, job_skill in job['partial_matches'][:3]:
                print(f"   • You: {cv_skill} ≈ Required: {job_skill}")
        
        if job['missing_skills']:
            print(f"\n❌ Skills to Learn ({len(job['missing_skills'])}):")
            for skill in job['missing_skills'][:5]:
                print(f"   • {skill}")
            if len(job['missing_skills']) > 5:
                print(f"   ... and {len(job['missing_skills']) - 5} more")
    
    print("\n" + "="*70)
    print("STEP 4: Skill Gap Analysis")
    print("="*70)
    
    print("\nAnalyzing top 20 jobs to identify skill gaps...")
    
    try:
        gap_analysis = matcher.get_skill_gap_analysis(
            cv_skills=cv_skills,
            top_n_jobs=20
        )
        
        print(f"\n📈 Analysis Results:")
        print(f"   Jobs Analyzed: {gap_analysis['total_jobs_analyzed']}")
        print(f"   Average Match: {gap_analysis['average_match_percentage']:.1f}%")
        
        print(f"\n💡 Top Skills to Learn (Most Requested):")
        print(f"   These skills appear most frequently in your target jobs\n")
        
        for i, item in enumerate(gap_analysis['top_missing_skills'][:12], 1):
            bar_length = int(item['percentage'] / 5)  # Scale for display
            bar = "█" * bar_length + "░" * (20 - bar_length)
            print(f"   {i:2}. {item['skill']:<25} {bar} {item['percentage']:.0f}%")
        
        print(f"\n📚 Learning Recommendation:")
        top_3 = gap_analysis['top_missing_skills'][:3]
        if top_3:
            print(f"   Focus on these skills to maximize your job matches:")
            for i, item in enumerate(top_3, 1):
                print(f"   {i}. {item['skill'].title()} (appears in {item['percentage']:.0f}% of jobs)")
        
    except Exception as e:
        print(f"\n✗ Error in gap analysis: {e}")
    
    print("\n" + "="*70)
    print("STEP 5: Save Results (Optional)")
    print("="*70)
    
    save_choice = input("\nDo you want to save these matches to the database? (y/n): ").lower()
    
    if save_choice == 'y':
        user_id = input("Enter your user ID or email: ").strip()
        if user_id:
            try:
                matcher.save_match_results(user_id, cv_skills, matching_jobs)
                print(f"\n✓ Successfully saved {len(matching_jobs)} job matches!")
            except Exception as e:
                print(f"\n✗ Error saving results: {e}")
        else:
            print("\n✗ User ID required to save results")
    else:
        print("\n✓ Results not saved")
    
    # Clean up
    matcher.close()
    
    print("\n" + "="*70)
    print("WORKFLOW COMPLETE!")
    print("="*70)
    print("\nNext Steps:")
    print("  1. Run 'streamlit run integrated_app.py' for the full UI")
    print("  2. Use 'python monitor.py --search <keyword>' to search jobs")
    print("  3. Schedule regular scraping: 'python run_scraper.py --mode schedule'")
    print("\nGood luck with your job search! 🎯")
    print("="*70 + "\n")


def quick_stats():
    """Show quick statistics about jobs in database"""
    from database import get_connection
    
    print("\n" + "="*70)
    print("DATABASE STATISTICS")
    print("="*70)
    
    try:
        conn = get_connection()
        cur = conn.cursor()
        
        # Total jobs
        cur.execute("SELECT COUNT(*) FROM jobs WHERE is_active = TRUE")
        total = cur.fetchone()[0]
        print(f"\nTotal Active Jobs: {total:,}")
        
        if total == 0:
            print("\n⚠️  No jobs in database!")
            print("Run: python run_scraper.py --mode web")
            cur.close()
            conn.close()
            return
        
        # Jobs by source
        cur.execute("""
            SELECT source, COUNT(*) 
            FROM jobs 
            WHERE is_active = TRUE
            GROUP BY source 
            ORDER BY COUNT(*) DESC
        """)
        
        print("\nJobs by Source:")
        for source, count in cur.fetchall():
            print(f"  {source:<25} {count:>5} jobs")
        
        # Recent activity
        cur.execute("""
            SELECT COUNT(*) 
            FROM jobs 
            WHERE scraped_at > NOW() - INTERVAL '24 hours'
        """)
        recent = cur.fetchone()[0]
        print(f"\nJobs Added (Last 24h): {recent}")
        
        cur.close()
        conn.close()
        
        print("="*70)
        
    except Exception as e:
        print(f"\n✗ Error accessing database: {e}")
        print("\nMake sure:")
        print("  1. PostgreSQL is running")
        print("  2. Database credentials in database.py are correct")
        print("  3. Tables exist (run: python setup_database.py)")


if __name__ == "__main__":
    print("\n")
    print("█" * 70)
    print("█                                                                    █")
    print("█          CV SKILL MATCHER & JOB FINDER - DEMO                     █")
    print("█                                                                    █")
    print("█" * 70)
    
    # Check if user wants stats first
    if len(sys.argv) > 1 and sys.argv[1] == '--stats':
        quick_stats()
    else:
        # Show database stats first
        quick_stats()
        
        # Ask if they want to continue
        print("\n")
        proceed = input("Ready to run the matching example? (y/n): ").lower()
        
        if proceed == 'y':
            example_workflow()
        else:
            print("\n✓ Exiting. Run 'python example_workflow.py' when ready!")
            print("  Or run 'python example_workflow.py --stats' for quick stats\n")
