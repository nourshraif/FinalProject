import requests
from bs4 import BeautifulSoup
import time
from datetime import datetime
from database import get_connection
import warnings
from bs4 import XMLParsedAsHTMLWarning

warnings.filterwarnings("ignore", category=XMLParsedAsHTMLWarning)

class JobScraperWorking:
    def __init__(self):
        self.headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
        }
        self.conn = get_connection()
        self.cur = self.conn.cursor()
        self.jobs_saved = 0
    
    def scrape_weworkremotely(self):
        """Scrape WeWorkRemotely - FIXED VERSION"""
        print("\n=== Scraping WeWorkRemotely ===")
        try:
            url = "https://weworkremotely.com/remote-jobs"
            response = requests.get(url, headers=self.headers, timeout=15)
            soup = BeautifulSoup(response.text, "html.parser")
            
            # Find ALL job listings (both featured and regular)
            # Jobs are in <li> tags with links to /remote-jobs/
            all_links = soup.find_all("a", href=True)
            
            processed = 0
            for link in all_links:
                href = link.get("href", "")
                
                # Only process job links
                if not href.startswith("/remote-jobs/") or "/remote-jobs/search" in href:
                    continue
                
                try:
                    # Get all text from the link, split by newlines
                    text_parts = [part.strip() for part in link.get_text(separator="\n").split("\n") if part.strip()]
                    
                    # Filter out empty parts and common non-job text
                    text_parts = [p for p in text_parts if p and len(p) > 2]
                    
                    # Usually format is: [Job Title, Company Name, Location/Category, ...]
                    if len(text_parts) >= 2:
                        title = text_parts[0]
                        company = text_parts[1]
                        
                        # Skip if it looks like navigation or footer links
                        skip_words = ['remote jobs', 'categories', 'companies', 'post a job', 'log in', 'sign up']
                        if any(skip in title.lower() or skip in company.lower() for skip in skip_words):
                            continue
                        
                        full_url = "https://weworkremotely.com" + href
                        
                        # Additional validation
                        if len(title) > 5 and len(company) > 2:
                            self.save_job("weworkremotely", title, company, "Remote", None, full_url)
                            processed += 1
                            
                except Exception as e:
                    continue
            
            print(f"Processed {processed} jobs from WeWorkRemotely")
                    
        except Exception as e:
            print(f"Error scraping WeWorkRemotely: {e}")
    
    def scrape_remoteok(self):
        """Scrape Remote OK - FIXED VERSION"""
        print("\n=== Scraping Remote OK ===")
        try:
            url = "https://remoteok.com/"
            response = requests.get(url, headers=self.headers, timeout=15)
            soup = BeautifulSoup(response.text, "html.parser")
            
            # Jobs are in table rows with class containing "job"
            all_rows = soup.find_all("tr")
            
            processed = 0
            for row in all_rows:
                try:
                    # Check if this is a job row
                    row_class = row.get("class", [])
                    if not any("job" in str(c).lower() for c in row_class):
                        continue
                    
                    # Skip placeholder rows
                    if "placeholder" in str(row_class):
                        continue
                    
                    # Get the job ID from data attributes
                    job_id = row.get("data-id") or row.get("data-job-id")
                    if not job_id:
                        continue
                    
                    # Find all text in the row
                    text_parts = [p.strip() for p in row.get_text(separator="|").split("|") if p.strip()]
                    
                    # Filter out numbers, single chars, and common noise
                    text_parts = [p for p in text_parts if len(p) > 3 and not p.isdigit()]
                    
                    if len(text_parts) >= 2:
                        # First meaningful text is usually the position
                        title = text_parts[0]
                        
                        # Second is usually company or could be tags
                        # Look for company name (usually has proper capitalization)
                        company = "Remote OK"
                        for part in text_parts[1:5]:
                            if part[0].isupper() and len(part) > 3:
                                company = part
                                break
                        
                        # Build URL from job ID
                        job_url = f"https://remoteok.com/remote-jobs/{job_id}"
                        
                        # Get tags as description
                        tags = ", ".join(text_parts[1:6])
                        
                        if len(title) > 5:
                            self.save_job("remoteok", title, company, "Remote", tags, job_url)
                            processed += 1
                            
                except Exception as e:
                    continue
            
            print(f"Processed {processed} jobs from Remote OK")
                    
        except Exception as e:
            print(f"Error scraping Remote OK: {e}")
    
    def scrape_remotive(self):
        """Scrape Remotive - FIXED VERSION"""
        print("\n=== Scraping Remotive ===")
        try:
            url = "https://remotive.com/remote-jobs"
            response = requests.get(url, headers=self.headers, timeout=15)
            soup = BeautifulSoup(response.text, "html.parser")
            
            # Find all job links
            all_links = soup.find_all("a", href=True)
            
            processed = 0
            seen_urls = set()
            
            for link in all_links:
                href = link.get("href", "")
                
                # Only process job detail links
                if not href.startswith("/remote-jobs/") or href == "/remote-jobs":
                    continue
                
                # Avoid duplicates
                full_url = "https://remotive.com" + href
                if full_url in seen_urls:
                    continue
                seen_urls.add(full_url)
                
                try:
                    # Get text from the link
                    link_text = link.get_text(strip=True)
                    
                    # Skip if too short or looks like navigation
                    if len(link_text) < 5 or link_text.lower() in ['view job', 'apply now', 'remote jobs']:
                        continue
                    
                    # Try to find company in parent elements
                    parent = link.parent
                    company = "Remotive"
                    
                    # Look for company info in siblings or parent text
                    if parent:
                        parent_text = parent.get_text(separator="|").split("|")
                        for text in parent_text:
                            text = text.strip()
                            if len(text) > 3 and text != link_text and text[0].isupper():
                                company = text
                                break
                    
                    title = link_text
                    
                    if len(title) > 5:
                        self.save_job("remotive", title, company, "Remote", None, full_url)
                        processed += 1
                        
                except Exception as e:
                    continue
            
            print(f"Processed {processed} jobs from Remotive")
                    
        except Exception as e:
            print(f"Error scraping Remotive: {e}")
    
    def scrape_wellfound(self):
        """Scrape Wellfound (AngelList Talent) - Additional source"""
        print("\n=== Scraping Wellfound ===")
        try:
            url = "https://wellfound.com/jobs"
            response = requests.get(url, headers=self.headers, timeout=15)
            soup = BeautifulSoup(response.text, "html.parser")
            
            # Find job links
            job_links = soup.find_all("a", href=True)
            
            processed = 0
            seen_urls = set()
            
            for link in job_links:
                href = link.get("href", "")
                
                if not href.startswith("/jobs/") or len(href) < 10:
                    continue
                
                full_url = "https://wellfound.com" + href
                if full_url in seen_urls:
                    continue
                seen_urls.add(full_url)
                
                try:
                    title = link.get_text(strip=True)
                    
                    if len(title) > 5 and len(title) < 100:
                        company = "Wellfound"
                        
                        # Try to find company nearby
                        parent = link.parent
                        if parent:
                            siblings = parent.find_all(text=True)
                            for text in siblings:
                                text = str(text).strip()
                                if len(text) > 3 and text != title and text[0].isupper():
                                    company = text
                                    break
                        
                        self.save_job("wellfound", title, company, "Remote", None, full_url)
                        processed += 1
                        
                        if processed >= 50:  # Limit to 50
                            break
                            
                except Exception as e:
                    continue
            
            print(f"Processed {processed} jobs from Wellfound")
                    
        except Exception as e:
            print(f"Error scraping Wellfound: {e}")
    
    def scrape_remote_co(self):
        """Scrape Remote.co - Additional reliable source"""
        print("\n=== Scraping Remote.co ===")
        try:
            url = "https://remote.co/remote-jobs/"
            response = requests.get(url, headers=self.headers, timeout=15)
            soup = BeautifulSoup(response.text, "html.parser")
            
            # Find job links
            job_links = soup.find_all("a", href=True)
            
            processed = 0
            seen_urls = set()
            
            for link in job_links:
                href = link.get("href", "")
                
                # Look for job detail pages
                if "remote.co" not in href and not href.startswith("/"):
                    continue
                
                if "/remote-jobs/" not in href or href.endswith("/remote-jobs/"):
                    continue
                
                # Build full URL
                if href.startswith("http"):
                    full_url = href
                else:
                    full_url = "https://remote.co" + href
                
                if full_url in seen_urls:
                    continue
                seen_urls.add(full_url)
                
                try:
                    title = link.get_text(strip=True)
                    
                    if len(title) > 5 and len(title) < 150:
                        # Try to extract company
                        company = "Remote.co"
                        
                        # Look in parent for company info
                        parent = link.parent
                        if parent:
                            all_text = parent.get_text(separator="|").split("|")
                            for text in all_text:
                                text = text.strip()
                                if len(text) > 3 and text != title and not text.isdigit():
                                    company = text
                                    break
                        
                        self.save_job("remote_co", title, company, "Remote", None, full_url)
                        processed += 1
                        
                        if processed >= 50:
                            break
                            
                except Exception as e:
                    continue
            
            print(f"Processed {processed} jobs from Remote.co")
                    
        except Exception as e:
            print(f"Error scraping Remote.co: {e}")
    
    def save_job(self, source, title, company, location, description, job_url):
        """Save job to database"""
        try:
            if not job_url or not title or not company:
                return
            
            # Clean data
            title = title.strip()[:255]
            company = company.strip()[:255]
            location = (location or "Remote").strip()[:255]
            description = (description or "")[:500]
            
            self.cur.execute("""
                INSERT INTO jobs (source, job_title, company, location, description, job_url, scraped_at)
                VALUES (%s, %s, %s, %s, %s, %s, NOW())
                ON CONFLICT (job_url) DO NOTHING;
            """, (source, title, company, location, description, job_url))
            
            if self.cur.rowcount > 0:
                self.jobs_saved += 1
                if self.jobs_saved % 10 == 0:
                    print(f"  ✓ Saved {self.jobs_saved} jobs so far...")
                    
        except Exception as e:
            pass  # Silent fail for individual jobs
    
    def run_all(self):
        """Run all scrapers"""
        start_time = time.time()
        print(f"\n{'='*60}")
        print(f"Starting job scraping at {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        print(f"{'='*60}")
        
        # Run all scrapers
        self.scrape_weworkremotely()
        time.sleep(2)
        
        self.scrape_remoteok()
        time.sleep(2)
        
        self.scrape_remotive()
        time.sleep(2)
        
        self.scrape_wellfound()
        time.sleep(2)
        
        self.scrape_remote_co()
        
        # Commit
        print(f"\n{'='*60}")
        print(f"💾 Committing {self.jobs_saved} jobs to database...")
        self.conn.commit()
        
        # Statistics
        self.cur.execute("SELECT source, COUNT(*) FROM jobs GROUP BY source ORDER BY COUNT(*) DESC")
        stats = self.cur.fetchall()
        
        print(f"\n{'='*60}")
        print("SCRAPING COMPLETE - Statistics:")
        print(f"{'='*60}")
        
        if stats:
            for source, count in stats:
                print(f"{source}: {count} jobs")
        
        self.cur.execute("SELECT COUNT(*) FROM jobs")
        total = self.cur.fetchone()[0]
        print(f"\n✅ Total jobs in database: {total}")
        print(f"✅ Jobs saved this run: {self.jobs_saved}")
        
        elapsed = time.time() - start_time
        print(f"⏱️  Time elapsed: {elapsed:.2f} seconds")
        print(f"{'='*60}\n")
        
        self.conn.close()

if __name__ == "__main__":
    scraper = JobScraperWorking()
    scraper.run_all()