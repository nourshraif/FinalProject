# Remote Job Scraper - Complete Guide

A comprehensive Python-based job scraper that aggregates remote job listings from multiple reliable sources, both through web scraping and official APIs.

## 📊 Data Sources

### Web Scrapers (No API Key Required)
1. **WeWorkRemotely** - One of the largest remote job communities
   - Main page + 5 category-specific pages
   - Categories: Programming, DevOps, Design, Marketing, Customer Support

2. **Remote OK** - Large remote job board with diverse listings
   - 50+ jobs per scrape

3. **Remotive** - Curated high-quality remote positions
   - Hand-picked remote jobs

4. **FlexJobs** - Premium remote job board (public listings)
   - High-quality, vetted positions

5. **Jobspresso** - Hand-picked remote tech jobs
   - Quality over quantity

### API Scrapers (More Reliable, Some Require Keys)

6. **Remote OK API** (FREE - No key required)
   - JSON API with structured data
   - 100+ recent jobs per request

7. **Arbeitnow API** (FREE - No key required)
   - European-focused remote jobs
   - Clean, structured data

8. **Adzuna API** (Requires free API key)
   - Large job aggregator
   - 50 jobs per request
   - Get key: https://developer.adzuna.com/

9. **Reed.co.uk API** (Requires free API key)
   - UK-focused jobs with remote options
   - Get key: https://www.reed.co.uk/developers

## 🚀 Quick Start

### Prerequisites
```bash
pip install requests beautifulsoup4 schedule
```

### Database Setup
Make sure your database has this table:
```sql
CREATE TABLE jobs (
    id SERIAL PRIMARY KEY,
    source VARCHAR(50) NOT NULL,
    job_title VARCHAR(255) NOT NULL,
    company VARCHAR(255) NOT NULL,
    location VARCHAR(255),
    description TEXT,
    job_url VARCHAR(500) UNIQUE NOT NULL,
    scraped_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_jobs_url ON jobs(job_url);
CREATE INDEX idx_jobs_source ON jobs(source);
CREATE INDEX idx_jobs_scraped ON jobs(scraped_at DESC);
```

### Basic Usage

#### 1. Run All Scrapers (Web + Free APIs)
```bash
python run_scraper.py --mode all
```

#### 2. Run Only Web Scrapers
```bash
python run_scraper.py --mode web
```

#### 3. Run Only API Scrapers
```bash
python run_scraper.py --mode api
```

#### 4. Schedule Regular Scraping (Every 6 Hours)
```bash
python run_scraper.py --mode schedule --interval 6
```

## 🔑 Using API Keys (Optional but Recommended)

### Get Adzuna API Keys (FREE)
1. Sign up at: https://developer.adzuna.com/
2. Create an application
3. Get your `app_id` and `app_key`

Run with Adzuna:
```bash
python run_scraper.py --mode all \
    --adzuna-id YOUR_APP_ID \
    --adzuna-key YOUR_APP_KEY
```

### Get Reed API Key (FREE)
1. Sign up at: https://www.reed.co.uk/developers
2. Get your API key

Run with Reed:
```bash
python run_scraper.py --mode all \
    --reed-key YOUR_REED_KEY
```

### Use All APIs Together
```bash
python run_scraper.py --mode all \
    --adzuna-id YOUR_APP_ID \
    --adzuna-key YOUR_APP_KEY \
    --reed-key YOUR_REED_KEY
```

## 📅 Automation Options

### Option 1: Using Built-in Scheduler
```bash
# Run every 6 hours
python run_scraper.py --mode schedule --interval 6

# Run every 12 hours
python run_scraper.py --mode schedule --interval 12
```

### Option 2: Using Cron (Linux/Mac)
Add to crontab:
```bash
# Run every 6 hours
0 */6 * * * cd /path/to/scraper && python run_scraper.py --mode all

# Run daily at 9 AM
0 9 * * * cd /path/to/scraper && python run_scraper.py --mode all

# Run twice daily (9 AM and 9 PM)
0 9,21 * * * cd /path/to/scraper && python run_scraper.py --mode all
```

### Option 3: Using Windows Task Scheduler
1. Open Task Scheduler
2. Create Basic Task
3. Set trigger (daily, custom schedule)
4. Action: Start a program
   - Program: `python`
   - Arguments: `C:\path\to\run_scraper.py --mode all`

## 📈 Expected Results

Running all scrapers should give you:
- **200-500+ unique jobs** per run
- Mix of tech, design, marketing, and support roles
- Global remote opportunities
- Updated data on each run (duplicates are automatically skipped)

### Performance Metrics
- Web scrapers: ~30-60 seconds
- API scrapers: ~10-20 seconds
- Total runtime: ~1-2 minutes for complete scrape

## 🛠 Customization

### Add More Sources

Edit `job_scraper.py` to add new web sources:
```python
def scrape_new_source(self):
    print("\n=== Scraping New Source ===")
    try:
        url = "https://newsource.com/jobs"
        response = requests.get(url, headers=self.headers, timeout=10)
        soup = BeautifulSoup(response.text, "html.parser")
        
        # Your scraping logic here
        jobs = soup.find_all("div", class_="job-listing")
        
        for job in jobs:
            title = job.find("h2").get_text(strip=True)
            company = job.find("span", class_="company").get_text(strip=True)
            link = job.find("a")["href"]
            
            self.save_job("newsource", title, company, "Remote", None, link)
    except Exception as e:
        print(f"Error: {e}")
```

Then add to `run_all()` method:
```python
def run_all(self):
    # ... existing scrapers ...
    self.scrape_new_source()
    time.sleep(2)
```

## 🔍 Monitoring and Debugging

### Check Scraping Statistics
After running, you'll see output like:
```
====================================================================
SCRAPING COMPLETE - Statistics:
====================================================================
remoteok_api: 98 jobs
weworkremotely: 87 jobs
remoteok: 56 jobs
arbeitnow: 45 jobs
remotive: 34 jobs
...

Total jobs in database: 1,247
Time elapsed: 45.23 seconds
====================================================================
```

### Query Database for Recent Jobs
```sql
-- Jobs from last scrape
SELECT source, COUNT(*) 
FROM jobs 
WHERE scraped_at > NOW() - INTERVAL '1 hour'
GROUP BY source;

-- Most recent jobs
SELECT job_title, company, source, job_url 
FROM jobs 
ORDER BY scraped_at DESC 
LIMIT 20;

-- Jobs by company
SELECT company, COUNT(*) as job_count
FROM jobs
GROUP BY company
ORDER BY job_count DESC
LIMIT 10;
```

## ⚠️ Best Practices

1. **Rate Limiting**: Built-in 2-second delays between sources
2. **Error Handling**: Individual source failures won't stop the entire scrape
3. **Duplicate Prevention**: `ON CONFLICT DO NOTHING` prevents duplicate URLs
4. **User Agent**: Identifies as browser to avoid blocks
5. **Timeout**: 10-second timeout on requests prevents hanging

## 🐛 Troubleshooting

### Issue: "Connection refused" or timeouts
- **Solution**: Some sites may be temporarily down. The scraper will skip and continue.

### Issue: "No jobs found" from a specific source
- **Solution**: Website structure may have changed. Check the source website manually.

### Issue: API returning errors
- **Solution**: Verify your API keys are correct and active.

### Issue: Database errors
- **Solution**: Ensure your `db.py` connection is working and the table exists.

## 📝 Additional Resources to Consider

Here are more job boards you can add:

**Free API Options:**
- Remotive.io API (check their docs)
- Himalayas.app (scraping)
- Remote.co (scraping)
- JustRemote (scraping)
- Working Nomads (scraping)
- Pangian (scraping)

**Paid API Options (if budget allows):**
- Indeed API (via RapidAPI)
- LinkedIn Jobs API (official)
- Glassdoor API
- ZipRecruiter API

## 📊 Recommended Schedule

For most use cases:
- **Hobby project**: Run daily (24-hour interval)
- **Active job board**: Run every 6-8 hours
- **High-frequency updates**: Run every 2-4 hours

**Note**: Don't scrape more frequently than every 2 hours to be respectful to source websites.

## 🤝 Contributing

To add new sources:
1. Check if the site has a public API first (preferred)
2. If scraping, inspect the HTML structure
3. Add error handling for your scraper
4. Test thoroughly before adding to production

## 📄 License

This is a tool for educational and personal use. Please respect the terms of service of each job board you scrape.

---

**Happy Job Hunting! 🎯**
