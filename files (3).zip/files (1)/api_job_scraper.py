import requests
import time
from datetime import datetime
from database import get_connection

class APIJobScraper:
    """
    Scraper using official APIs and RSS feeds for more reliable job data.
    These sources are less likely to break and provide structured data.
    """
    
    def __init__(self):
        self.conn = get_connection()
        self.cur = self.conn.cursor()
        self.headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
        }
    
    def scrape_github_jobs_rss(self):
        """Scrape GitHub Jobs RSS feed (if available)"""
        print("\n=== Scraping GitHub Jobs ===")
        try:
            # Note: GitHub Jobs closed in 2021, but keeping structure for similar RSS feeds
            # You can replace with other RSS-based job boards
            pass
        except Exception as e:
            print(f"Error: {e}")
    
    def scrape_stackoverflow_jobs(self):
        """Scrape Stack Overflow Jobs"""
        print("\n=== Scraping Stack Overflow Jobs ===")
        try:
            url = "https://stackoverflow.com/jobs/feed"
            response = requests.get(url, headers=self.headers, timeout=10)
            
            # Parse RSS feed
            from xml.etree import ElementTree as ET
            root = ET.fromstring(response.content)
            
            for item in root.findall('.//item'):
                try:
                    title = item.find('title').text
                    link = item.find('link').text
                    description = item.find('description').text if item.find('description') is not None else ""
                    
                    # Extract company from description or title
                    company = "Stack Overflow Listing"
                    
                    self.save_job("stackoverflow", title, company, "Remote", description, link)
                except Exception as e:
                    continue
                    
        except Exception as e:
            print(f"Error scraping Stack Overflow: {e}")
    
    def scrape_remoteok_api(self):
        """Use Remote OK's JSON API for structured data"""
        print("\n=== Scraping Remote OK API ===")
        try:
            url = "https://remoteok.com/api"
            response = requests.get(url, headers=self.headers, timeout=10)
            jobs = response.json()
            
            # First item is metadata, skip it
            jobs = jobs[1:] if len(jobs) > 1 else []
            print(f"Found {len(jobs)} jobs via API")
            
            for job in jobs[:100]:  # Limit to 100 most recent
                try:
                    title = job.get('position', 'N/A')
                    company = job.get('company', 'N/A')
                    location = job.get('location', 'Remote')
                    tags = ', '.join(job.get('tags', []))
                    url_path = job.get('url', '')
                    job_url = f"https://remoteok.com{url_path}" if url_path else ""
                    
                    self.save_job("remoteok_api", title, company, location, tags, job_url)
                except Exception as e:
                    continue
                    
        except Exception as e:
            print(f"Error scraping Remote OK API: {e}")
    
    def scrape_adzuna_api(self, app_id=None, app_key=None):
        """
        Use Adzuna API for job listings
        You need to register at https://developer.adzuna.com/ for API keys
        """
        print("\n=== Scraping Adzuna API ===")
        
        if not app_id or not app_key:
            print("Adzuna API requires app_id and app_key. Skipping...")
            print("Get your keys at: https://developer.adzuna.com/")
            return
        
        try:
            url = f"https://api.adzuna.com/v1/api/jobs/us/search/1"
            params = {
                'app_id': app_id,
                'app_key': app_key,
                'results_per_page': 50,
                'what': 'remote',
                'content-type': 'application/json'
            }
            
            response = requests.get(url, params=params, timeout=10)
            data = response.json()
            
            jobs = data.get('results', [])
            print(f"Found {len(jobs)} jobs")
            
            for job in jobs:
                try:
                    title = job.get('title', 'N/A')
                    company = job.get('company', {}).get('display_name', 'N/A')
                    location = job.get('location', {}).get('display_name', 'Remote')
                    description = job.get('description', '')[:500]  # Limit description length
                    job_url = job.get('redirect_url', '')
                    
                    self.save_job("adzuna", title, company, location, description, job_url)
                except Exception as e:
                    continue
                    
        except Exception as e:
            print(f"Error scraping Adzuna API: {e}")
    
    def scrape_usajobs_api(self):
        """Scrape USAJobs.gov API for remote government jobs"""
        print("\n=== Scraping USAJobs.gov API ===")
        try:
            url = "https://data.usajobs.gov/api/search"
            headers = {
                "Host": "data.usajobs.gov",
                "User-Agent": self.headers["User-Agent"],
                "Authorization-Key": "YOUR_API_KEY"  # Get from https://developer.usajobs.gov/
            }
            
            params = {
                'Keyword': 'remote',
                'ResultsPerPage': 50
            }
            
            # Note: Requires API key
            # response = requests.get(url, headers=headers, params=params, timeout=10)
            # Skipping actual implementation without API key
            print("USAJobs requires API key. Get it at: https://developer.usajobs.gov/")
            
        except Exception as e:
            print(f"Error scraping USAJobs: {e}")
    
    def scrape_arbeitnow_api(self):
        """Scrape Arbeitnow free API for remote jobs"""
        print("\n=== Scraping Arbeitnow API ===")
        try:
            url = "https://www.arbeitnow.com/api/job-board-api"
            response = requests.get(url, headers=self.headers, timeout=10)
            data = response.json()
            
            jobs = data.get('data', [])
            print(f"Found {len(jobs)} jobs")
            
            for job in jobs:
                try:
                    title = job.get('title', 'N/A')
                    company = job.get('company_name', 'N/A')
                    location = job.get('location', 'Remote')
                    tags = ', '.join(job.get('tags', []))
                    job_url = job.get('url', '')
                    
                    # Only include remote jobs
                    if 'remote' in location.lower() or 'remote' in tags.lower():
                        self.save_job("arbeitnow", title, company, location, tags, job_url)
                except Exception as e:
                    continue
                    
        except Exception as e:
            print(f"Error scraping Arbeitnow API: {e}")
    
    def scrape_reed_api(self, api_key=None):
        """
        Scrape Reed.co.uk API for UK remote jobs
        Get API key from: https://www.reed.co.uk/developers
        """
        print("\n=== Scraping Reed.co.uk API ===")
        
        if not api_key:
            print("Reed API requires an API key. Skipping...")
            print("Get your key at: https://www.reed.co.uk/developers")
            return
        
        try:
            url = "https://www.reed.co.uk/api/1.0/search"
            auth = (api_key, '')
            params = {
                'keywords': 'remote',
                'resultsToTake': 50
            }
            
            response = requests.get(url, auth=auth, params=params, timeout=10)
            data = response.json()
            
            jobs = data.get('results', [])
            print(f"Found {len(jobs)} jobs")
            
            for job in jobs:
                try:
                    title = job.get('jobTitle', 'N/A')
                    company = job.get('employerName', 'N/A')
                    location = job.get('locationName', 'Remote')
                    description = job.get('jobDescription', '')[:500]
                    job_url = job.get('jobUrl', '')
                    
                    self.save_job("reed", title, company, location, description, job_url)
                except Exception as e:
                    continue
                    
        except Exception as e:
            print(f"Error scraping Reed API: {e}")
    
    def save_job(self, source, title, company, location, description, job_url):
        """Save job to database with duplicate check"""
        try:
            if not job_url or not title or not company:
                return
            
            self.cur.execute("""
                INSERT INTO jobs (source, job_title, company, location, description, job_url, scraped_at)
                VALUES (%s, %s, %s, %s, %s, %s, NOW())
                ON CONFLICT (job_url) DO UPDATE 
                SET scraped_at = NOW();
            """, (source, title, company, location, description, job_url))
            
            print(f"✓ Saved: {title} at {company}")
        except Exception as e:
            print(f"Error saving job: {e}")
    
    def run_all(self, api_keys=None):
        """Run all API scrapers"""
        start_time = time.time()
        print(f"\n{'='*60}")
        print(f"Starting API job scraping at {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        print(f"{'='*60}")
        
        api_keys = api_keys or {}
        
        # Run all API scrapers
        self.scrape_remoteok_api()
        time.sleep(2)
        
        self.scrape_arbeitnow_api()
        time.sleep(2)
        
        # API scrapers that require keys
        if api_keys.get('adzuna_id') and api_keys.get('adzuna_key'):
            self.scrape_adzuna_api(api_keys['adzuna_id'], api_keys['adzuna_key'])
            time.sleep(2)
        
        if api_keys.get('reed_key'):
            self.scrape_reed_api(api_keys['reed_key'])
            time.sleep(2)
        
        # Commit changes
        self.conn.commit()
        
        # Get statistics
        self.cur.execute("SELECT source, COUNT(*) FROM jobs GROUP BY source ORDER BY COUNT(*) DESC")
        stats = self.cur.fetchall()
        
        print(f"\n{'='*60}")
        print("API SCRAPING COMPLETE - Statistics:")
        print(f"{'='*60}")
        for source, count in stats:
            print(f"{source}: {count} jobs")
        
        self.cur.execute("SELECT COUNT(*) FROM jobs")
        total = self.cur.fetchone()[0]
        print(f"\nTotal jobs in database: {total}")
        
        elapsed = time.time() - start_time
        print(f"Time elapsed: {elapsed:.2f} seconds")
        print(f"{'='*60}\n")
        
        self.conn.close()

if __name__ == "__main__":
    # Example usage with API keys
    api_keys = {
        # 'adzuna_id': 'your_app_id',
        # 'adzuna_key': 'your_app_key',
        # 'reed_key': 'your_reed_key'
    }
    
    scraper = APIJobScraper()
    scraper.run_all(api_keys)
