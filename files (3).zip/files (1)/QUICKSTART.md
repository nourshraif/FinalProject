# Quick Start Guide - Remote Job Scraper

Get up and running in 5 minutes!

## Step 1: Install Dependencies (30 seconds)
```bash
pip install -r requirements.txt
```

## Step 2: Setup Database (1 minute)
```bash
python setup_database.py
```

## Step 3: Run Your First Scrape (2 minutes)
```bash
# Option A: Quick scrape (web only, no API keys needed)
python run_scraper.py --mode web

# Option B: Complete scrape (includes free APIs)
python run_scraper.py --mode all
```

That's it! You now have remote jobs in your database.

## Step 4: View Your Results
```bash
python monitor.py
```

## Step 5: Search for Specific Jobs
```bash
# Interactive search
python monitor.py --search

# Direct search
python monitor.py --search python developer
```

---

## What You Get (Without Any API Keys)

Running just `python run_scraper.py --mode web` gives you jobs from:
- ✓ WeWorkRemotely (80-100 jobs)
- ✓ Remote OK (50+ jobs)
- ✓ Remotive (30-40 jobs)
- ✓ FlexJobs (40+ jobs)
- ✓ Jobspresso (20+ jobs)

**Total: 200-300 unique jobs per run** - completely free!

---

## Optional: Add Free APIs for More Jobs (5 minutes)

### Get Adzuna API (FREE)
1. Go to: https://developer.adzuna.com/
2. Sign up (takes 2 minutes)
3. Create an app → Get `app_id` and `app_key`
4. Run with:
```bash
python run_scraper.py --mode all \
    --adzuna-id YOUR_APP_ID \
    --adzuna-key YOUR_APP_KEY
```

This adds 50+ more curated jobs!

### Get Reed API (FREE - UK Jobs)
1. Go to: https://www.reed.co.uk/developers
2. Sign up → Get API key
3. Run with:
```bash
python run_scraper.py --mode all --reed-key YOUR_KEY
```

---

## Automate It (Schedule Regular Scraping)

### Option 1: Built-in Scheduler
```bash
# Run every 6 hours automatically
python run_scraper.py --mode schedule --interval 6
```

### Option 2: Cron Job (Linux/Mac)
```bash
# Edit crontab
crontab -e

# Add this line to run every 6 hours
0 */6 * * * cd /path/to/scraper && python run_scraper.py --mode all
```

### Option 3: Windows Task Scheduler
1. Search for "Task Scheduler" in Windows
2. Create Basic Task
3. Set schedule (e.g., Daily at 9 AM)
4. Action: Start program → `python`
5. Arguments: `C:\path\to\run_scraper.py --mode all`

---

## Common Commands Cheat Sheet

```bash
# First time setup
python setup_database.py

# Run scraping
python run_scraper.py --mode web          # Fast (web only)
python run_scraper.py --mode all          # Complete (web + APIs)
python run_scraper.py --mode schedule     # Auto-run every 6 hours

# View statistics
python monitor.py                          # Full dashboard

# Search jobs
python monitor.py --search                 # Interactive search
python monitor.py --search "python"        # Search for Python jobs
python monitor.py --search "senior react"  # Search for senior React jobs
```

---

## Troubleshooting

**Problem**: "No module named 'requests'"
**Solution**: Run `pip install -r requirements.txt`

**Problem**: "Cannot connect to database"
**Solution**: Make sure your `db.py` has correct database credentials

**Problem**: "No jobs found"
**Solution**: Some websites might be temporarily down. The scraper continues with other sources.

**Problem**: API returning errors
**Solution**: Check your API keys are correct and active

---

## Expected Results

### First Run
```
====================================================================
SCRAPING COMPLETE - Statistics:
====================================================================
weworkremotely: 87 jobs
remoteok: 56 jobs
remotive: 34 jobs
flexjobs: 42 jobs
jobspresso: 23 jobs

Total jobs in database: 242
Time elapsed: 45.23 seconds
====================================================================
```

### With APIs
```
====================================================================
remoteok_api: 98 jobs
weworkremotely: 87 jobs
arbeitnow: 45 jobs
adzuna: 52 jobs
...

Total jobs in database: 387
====================================================================
```

---

## Next Steps

1. ✓ **Set up automated scraping** - Let it run every 6-12 hours
2. ✓ **Get API keys** - Adds 100+ more quality jobs
3. ✓ **Customize sources** - Add your favorite job boards
4. ✓ **Build a frontend** - Create a web interface to browse jobs

---

## Need Help?

Check the full README.md for:
- Detailed configuration options
- Adding new job sources
- Database queries and analytics
- Advanced customization

Happy job hunting! 🎯
