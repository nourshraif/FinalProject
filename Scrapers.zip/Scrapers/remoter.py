import requests
from bs4 import BeautifulSoup
from base_scraper import BaseScraper

class RemotersScraper(BaseScraper):
    def scrape(self):
        """Remoters - Remote job listings"""
        print("\n=== Scraping Remoters ===")
        try:
            url = "https://remoters.net/jobs/"
            response = requests.get(url, headers=self.headers, timeout=15)
            soup = BeautifulSoup(response.text, "html.parser")
            
            job_links = soup.find_all("a", href=True)
            processed = 0
            seen_urls = set()
            
            for link in job_links:
                href = link.get("href", "")
                if "/jobs/" not in href or href == "/jobs/":
                    continue
                
                full_url = "https://remoters.net" + href if href.startswith("/") else href
                if full_url in seen_urls:
                    continue
                seen_urls.add(full_url)
                
                try:
                    title = self.clean_text(link.get_text(strip=True))
                    if len(title) < 5 or len(title) > 200:
                        continue
                    
                    company = "Remoters"
                    
                    self.save_job("remoters", title, company, "Remote", None, full_url)
                    processed += 1
                    
                    if processed >= 30:
                        break
                except:
                    continue
            
            print(f"Processed {processed} jobs from Remoters")
            return processed
        except Exception as e:
            print(f"Error scraping Remoters: {e}")
            return 0

if __name__ == "__main__":
    scraper = RemotersScraper()
    scraper.scrape()
    scraper.commit()
    print(f"✅ Saved {scraper.jobs_saved} jobs")
    scraper.close()