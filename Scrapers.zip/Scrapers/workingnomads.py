import requests
from bs4 import BeautifulSoup
from base_scraper import BaseScraper

class WorkingNomadsScraper(BaseScraper):
    def scrape(self):
        """Working Nomads - Digital nomad jobs"""
        print("\n=== Scraping Working Nomads ===")
        try:
            url = "https://www.workingnomads.com/jobs"
            response = requests.get(url, headers=self.headers, timeout=15)
            soup = BeautifulSoup(response.text, "html.parser")
            
            job_links = soup.find_all("a", href=True)
            processed = 0
            seen_urls = set()
            
            for link in job_links:
                href = link.get("href", "")
                if not href.startswith("/jobs?") or "company" in href:
                    continue
                
                full_url = "https://www.workingnomads.com" + href
                if full_url in seen_urls:
                    continue
                seen_urls.add(full_url)
                
                try:
                    title = self.clean_text(link.get_text(strip=True))
                    if len(title) < 5 or len(title) > 200:
                        continue
                    
                    company = "Working Nomads"
                    
                    self.save_job("workingnomads", title, company, "Remote", None, full_url)
                    processed += 1
                    
                    if processed >= 40:
                        break
                except:
                    continue
            
            print(f"Processed {processed} jobs from Working Nomads")
            return processed
        except Exception as e:
            print(f"Error scraping Working Nomads: {e}")
            return 0

if __name__ == "__main__":
    scraper = WorkingNomadsScraper()
    scraper.scrape()
    scraper.commit()
    print(f"✅ Saved {scraper.jobs_saved} jobs")
    scraper.close()