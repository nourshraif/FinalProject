import requests
from bs4 import BeautifulSoup
import re
from Database.database import get_connection

class BaseScraper:
    def __init__(self):
        self.headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
        }
        self.conn = get_connection()
        self.cur = self.conn.cursor()
        self.jobs_saved = 0
    
    def clean_text(self, text):
        """Clean and validate text"""
        if not text:
            return ""
        text = text.strip()
        noise_patterns = [
            r'^\d+[dhms]$', r'^new$', r'^featured$', r'^hiring$', 
            r'^remote$', r'^\d+$', r'^apply$', r'^view job$'
        ]
        for pattern in noise_patterns:
            if re.match(pattern, text.lower()):
                return ""
        return text
    
    def is_valid_company(self, company):
        """Check if company name is valid"""
        if not company or len(company) < 2:
            return False
        company_lower = company.lower()
        invalid = ['new', 'featured', 'hiring', 'remote', 'apply', 'view job', 'easy apply']
        if company_lower in invalid:
            return False
        if re.match(r'^\d+[dhms]$', company_lower) or company.isdigit():
            return False
        return True
    
    def save_job(self, source, title, company, location, description, job_url):
        """Save job to database"""
        try:
            if not job_url or not title or not company:
                return
            
            title = title.strip()[:255]
            company = company.strip()[:255]
            location = (location or "Remote").strip()[:255]
            description = (description or "")[:500]
            
            if not self.is_valid_company(company):
                company = source.title()
            
            self.cur.execute("""
                INSERT INTO jobs (source, job_title, company, location, description, job_url, scraped_at)
                VALUES (%s, %s, %s, %s, %s, %s, NOW())
                ON CONFLICT (job_url) DO NOTHING;
            """, (source, title, company, location, description, job_url))
            
            if self.cur.rowcount > 0:
                self.jobs_saved += 1
        except:
            pass
    
    def commit(self):
        """Commit changes to database"""
        self.conn.commit()
    
    def close(self):
        """Close database connection"""
        self.conn.close()
