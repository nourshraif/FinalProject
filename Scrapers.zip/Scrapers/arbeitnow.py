import requests
from .base_scraper import BaseScraper

class ArbeitnowScraper(BaseScraper):
    def scrape(self):
        """Arbeitnow API - FREE, European focus"""
        print("\n=== Scraping Arbeitnow API ===")
        try:
            url = "https://www.arbeitnow.com/api/job-board-api"
            response = requests.get(url, headers=self.headers, timeout=15)
            jobs = response.json().get('data', [])
            
            processed = 0
            for job in jobs:
                try:
                    title = job.get('title', '').strip()
                    company = job.get('company_name', 'Arbeitnow').strip()
                    location = job.get('location', 'Remote').strip()
                    tags = ', '.join(job.get('tags', []))
                    job_url = job.get('url', '')
                    
                    if 'remote' in location.lower() or 'remote' in tags.lower() or not location:
                        if len(title) > 5 and job_url:
                            self.save_job("arbeitnow", title, company, location, tags, job_url)
                            processed += 1
                except:
                    continue
            
            print(f"Processed {processed} jobs from Arbeitnow")
            return processed
        except Exception as e:
            print(f"Error scraping Arbeitnow: {e}")
            return 0

if __name__ == "__main__":
    scraper = ArbeitnowScraper()
    scraper.scrape()
    scraper.commit()
    print(f"✅ Saved {scraper.jobs_saved} jobs")
    scraper.close()