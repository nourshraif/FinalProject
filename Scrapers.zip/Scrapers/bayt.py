import requests
from bs4 import BeautifulSoup
from base_scraper import BaseScraper

class BaytScraper(BaseScraper):
    def scrape(self):
        """Bayt.com - Leading Middle East job site"""
        print("\n=== Scraping Bayt.com ===")
        try:
            # Search for remote jobs
            url = "https://www.bayt.com/en/international/jobs/remote-jobs/"
            response = requests.get(url, headers=self.headers, timeout=15)
            soup = BeautifulSoup(response.text, "html.parser")
            
            job_cards = soup.find_all(["li", "div"], class_=lambda x: x and "job" in str(x).lower())
            processed = 0
            
            for card in job_cards[:60]:
                try:
                    link = card.find("a", href=True)
                    if not link:
                        continue
                    
                    href = link.get("href", "")
                    if not href or "bayt.com" not in href:
                        if href.startswith("/"):
                            href = "https://www.bayt.com" + href
                        else:
                            continue
                    
                    title = self.clean_text(link.get_text(strip=True))
                    if len(title) < 5:
                        title_elem = card.find(["h2", "h3"])
                        if title_elem:
                            title = self.clean_text(title_elem.get_text(strip=True))
                    
                    company = "Bayt.com"
                    company_elem = card.find(class_=lambda x: x and "company" in str(x).lower())
                    if company_elem:
                        comp_text = self.clean_text(company_elem.get_text(strip=True))
                        if self.is_valid_company(comp_text):
                            company = comp_text
                    
                    if len(title) > 5:
                        self.save_job("bayt", title, company, "Middle East/Remote", None, href)
                        processed += 1
                except:
                    continue
            
            print(f"Processed {processed} jobs from Bayt.com")
            return processed
        except Exception as e:
            print(f"Error scraping Bayt: {e}")
            return 0

if __name__ == "__main__":
    scraper = BaytScraper()
    scraper.scrape()
    scraper.commit()
    print(f"✅ Saved {scraper.jobs_saved} jobs")
    scraper.close()