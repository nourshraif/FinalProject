import requests
from bs4 import BeautifulSoup
from base_scraper import BaseScraper

class NoDeskScraper(BaseScraper):
    def scrape(self):
        """NoDesk - Digital nomad remote jobs"""
        print("\n=== Scraping NoDesk ===")
        try:
            url = "https://nodesk.co/remote-jobs/"
            response = requests.get(url, headers=self.headers, timeout=15)
            soup = BeautifulSoup(response.text, "html.parser")
            
            job_cards = soup.find_all(["div", "article"], class_=lambda x: x and "job" in str(x).lower())
            processed = 0
            
            for card in job_cards[:50]:
                try:
                    link = card.find("a", href=True)
                    if not link:
                        continue
                    
                    href = link.get("href", "")
                    if not href.startswith("http"):
                        href = "https://nodesk.co" + href
                    
                    title = self.clean_text(link.get_text(strip=True))
                    if len(title) < 5:
                        continue
                    
                    company = "NoDesk"
                    company_elem = card.find(class_="company")
                    if company_elem:
                        comp_text = self.clean_text(company_elem.get_text(strip=True))
                        if self.is_valid_company(comp_text):
                            company = comp_text
                    
                    self.save_job("nodesk", title, company, "Remote", None, href)
                    processed += 1
                except:
                    continue
            
            print(f"Processed {processed} jobs from NoDesk")
            return processed
        except Exception as e:
            print(f"Error scraping NoDesk: {e}")
            return 0

if __name__ == "__main__":
    scraper = NoDeskScraper()
    scraper.scrape()
    scraper.commit()
    print(f"✅ Saved {scraper.jobs_saved} jobs")
    scraper.close()