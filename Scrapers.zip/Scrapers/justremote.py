import requests
from bs4 import BeautifulSoup
from base_scraper import BaseScraper

class JustRemoteScraper(BaseScraper):
    def scrape(self):
        """JustRemote - Remote jobs board"""
        print("\n=== Scraping JustRemote ===")
        try:
            url = "https://justremote.co/remote-jobs"
            response = requests.get(url, headers=self.headers, timeout=15)
            soup = BeautifulSoup(response.text, "html.parser")
            
            job_links = soup.find_all("a", href=True)
            processed = 0
            seen_urls = set()
            
            for link in job_links:
                href = link.get("href", "")
                if "/remote-" not in href or len(href) < 15:
                    continue
                
                if href.startswith("/"):
                    full_url = "https://justremote.co" + href
                else:
                    full_url = href
                
                if full_url in seen_urls or "remote-jobs" == href.strip("/"):
                    continue
                seen_urls.add(full_url)
                
                try:
                    title = self.clean_text(link.get_text(strip=True))
                    if len(title) < 5 or len(title) > 200:
                        continue
                    
                    company = "JustRemote"
                    parent = link.parent
                    if parent:
                        text_parts = parent.get_text(separator="|").split("|")
                        for part in text_parts:
                            cleaned = self.clean_text(part)
                            if self.is_valid_company(cleaned) and cleaned != title:
                                company = cleaned
                                break
                    
                    self.save_job("justremote", title, company, "Remote", None, full_url)
                    processed += 1
                    
                    if processed >= 50:
                        break
                except:
                    continue
            
            print(f"Processed {processed} jobs from JustRemote")
            return processed
        except Exception as e:
            print(f"Error scraping JustRemote: {e}")
            return 0

if __name__ == "__main__":
    scraper = JustRemoteScraper()
    scraper.scrape()
    scraper.commit()
    print(f"✅ Saved {scraper.jobs_saved} jobs")
    scraper.close()