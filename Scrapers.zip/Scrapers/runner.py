#!/usr/bin/env python3
"""
Master Job Scraper Runner
Run all scrapers or individual ones
"""

import time
from datetime import datetime
import sys

# Import all scrapers
from weworkremotly import WeWorkRemotelyScraper
from remoteok import RemoteOKScraper
from arbeitnow import ArbeitnowScraper
from remotive import RemotiveScraper
from himalayas import HimalayasScraper
from justremote import JustRemoteScraper
from workingnomads import WorkingNomadsScraper
from pangian import PangianScraper
from remoteco import RemoteCoScraper
from nodesk import NoDeskScraper
from remoter import RemotersScraper
from powertofly import PowerToFlyScraper
from bayt import BaytScraper
from linkedin import LinkedInScraper
from indeed import IndeedScraper

# All available scrapers
SCRAPERS = {
    'weworkremotely': WeWorkRemotelyScraper,
    'remoteok': RemoteOKScraper,
    'arbeitnow': ArbeitnowScraper,
    'remotive': RemotiveScraper,
    'himalayas': HimalayasScraper,
    'justremote': JustRemoteScraper,
    'workingnomads': WorkingNomadsScraper,
    'pangian': PangianScraper,
    'remoteco': RemoteCoScraper,
    'nodesk': NoDeskScraper,
    'remoters': RemotersScraper,
    'powertofly': PowerToFlyScraper,
    'bayt': BaytScraper,
    'linkedin': LinkedInScraper,
    'indeed': IndeedScraper,
}

def run_all_scrapers():
    """Run all scrapers sequentially"""
    print(f"\n{'='*70}")
    print(f"🌍 COMPREHENSIVE JOB SCRAPING - {len(SCRAPERS)} SOURCES")
    print(f"Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"{'='*70}\n")
    
    start_time = time.time()
    total_saved = 0
    
    for name, ScraperClass in SCRAPERS.items():
        try:
            scraper = ScraperClass()
            scraper.scrape()
            scraper.commit()
            total_saved += scraper.jobs_saved
            print(f"✅ {name}: Saved {scraper.jobs_saved} jobs")
            scraper.close()
            time.sleep(2)  # Be respectful
        except Exception as e:
            print(f"❌ {name}: Error - {e}")
    
    print(f"\n{'='*70}")
    print(f"✅ SCRAPING COMPLETE")
    print(f"📊 TOTAL JOBS SAVED: {total_saved}")
    print(f"⏱️  TIME ELAPSED: {time.time() - start_time:.2f} seconds")
    print(f"{'='*70}\n")

def run_single_scraper(scraper_name):
    """Run a single scraper by name"""
    if scraper_name not in SCRAPERS:
        print(f"❌ Unknown scraper: {scraper_name}")
        print(f"Available scrapers: {', '.join(SCRAPERS.keys())}")
        return
    
    print(f"\n{'='*70}")
    print(f"🎯 Running single scraper: {scraper_name}")
    print(f"Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"{'='*70}\n")
    
    start_time = time.time()
    
    try:
        ScraperClass = SCRAPERS[scraper_name]
        scraper = ScraperClass()
        scraper.scrape()
        scraper.commit()
        print(f"\n✅ Saved {scraper.jobs_saved} jobs from {scraper_name}")
        scraper.close()
    except Exception as e:
        print(f"❌ Error: {e}")
    
    print(f"⏱️  Time elapsed: {time.time() - start_time:.2f} seconds\n")

def list_scrapers():
    """List all available scrapers"""
    print(f"\n{'='*70}")
    print("📋 AVAILABLE SCRAPERS:")
    print(f"{'='*70}")
    for i, name in enumerate(SCRAPERS.keys(), 1):
        print(f"{i:2d}. {name}")
    print(f"{'='*70}\n")

if __name__ == "__main__":
    if len(sys.argv) > 1:
        command = sys.argv[1].lower()
        
        if command == "list":
            list_scrapers()
        elif command == "all":
            run_all_scrapers()
        else:
            # Assume it's a scraper name
            run_single_scraper(command)
    else:
        print("\n" + "="*70)
        print("Job Scraper Runner")
        print("="*70)
        print("\nUsage:")
        print("  python run_scrapers.py all              # Run all scrapers")
        print("  python run_scrapers.py list             # List available scrapers")
        print("  python run_scrapers.py <scraper_name>   # Run specific scraper")
        print("\nExamples:")
        print("  python run_scrapers.py remoteok")
        print("  python run_scrapers.py weworkremotely")
        print("  python run_scrapers.py linkedin")
        print("="*70 + "\n")