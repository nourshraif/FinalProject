import requests
from bs4 import BeautifulSoup
from base_scraper import BaseScraper

class PangianScraper(BaseScraper):
    def scrape(self):
        """Pangian - Global remote jobs"""
        print("\n=== Scraping Pangian ===")
        try:
            url = "https://pangian.com/job-travel-remote/"
            response = requests.get(url, headers=self.headers, timeout=15)
            soup = BeautifulSoup(response.text, "html.parser")
            
            job_cards = soup.find_all(["article", "div"], class_=lambda x: x and "job" in str(x).lower())
            processed = 0
            
            for card in job_cards[:50]:
                try:
                    link = card.find("a", href=True)
                    if not link:
                        continue
                    
                    href = link.get("href", "")
                    if not href or len(href) < 10:
                        continue
                    
                    if not href.startswith("http"):
                        href = "https://pangian.com" + href
                    
                    title = self.clean_text(link.get_text(strip=True))
                    if len(title) < 5:
                        title_elem = card.find(["h2", "h3", "h4"])
                        if title_elem:
                            title = self.clean_text(title_elem.get_text(strip=True))
                    
                    company = "Pangian"
                    company_elem = card.find(class_=lambda x: x and "company" in str(x).lower())
                    if company_elem:
                        comp_text = self.clean_text(company_elem.get_text(strip=True))
                        if self.is_valid_company(comp_text):
                            company = comp_text
                    
                    if len(title) > 5:
                        self.save_job("pangian", title, company, "Remote", None, href)
                        processed += 1
                except:
                    continue
            
            print(f"Processed {processed} jobs from Pangian")
            return processed
        except Exception as e:
            print(f"Error scraping Pangian: {e}")
            return 0

if __name__ == "__main__":
    scraper = PangianScraper()
    scraper.scrape()
    scraper.commit()
    print(f"✅ Saved {scraper.jobs_saved} jobs")
    scraper.close()