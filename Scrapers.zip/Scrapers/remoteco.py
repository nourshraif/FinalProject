import requests
from bs4 import BeautifulSoup
from base_scraper import BaseScraper

class RemoteCoScraper(BaseScraper):
    def scrape(self):
        """Remote.co - Remote work resources and jobs"""
        print("\n=== Scraping Remote.co ===")
        try:
            url = "https://remote.co/remote-jobs/"
            response = requests.get(url, headers=self.headers, timeout=15)
            soup = BeautifulSoup(response.text, "html.parser")
            
            job_links = soup.find_all("a", href=True)
            processed = 0
            seen_urls = set()
            
            for link in job_links:
                href = link.get("href", "")
                
                if "/remote-jobs/" not in href or href.endswith("/remote-jobs/"):
                    continue
                
                if href.startswith("http"):
                    full_url = href
                else:
                    full_url = "https://remote.co" + href
                
                if full_url in seen_urls:
                    continue
                seen_urls.add(full_url)
                
                try:
                    title = self.clean_text(link.get_text(strip=True))
                    if len(title) < 5 or len(title) > 150:
                        continue
                    
                    company = "Remote.co"
                    parent = link.parent
                    if parent:
                        text_parts = parent.get_text(separator="|").split("|")
                        for part in text_parts:
                            cleaned = self.clean_text(part)
                            if self.is_valid_company(cleaned) and cleaned != title:
                                company = cleaned
                                break
                    
                    self.save_job("remoteco", title, company, "Remote", None, full_url)
                    processed += 1
                    
                    if processed >= 40:
                        break
                except:
                    continue
            
            print(f"Processed {processed} jobs from Remote.co")
            return processed
        except Exception as e:
            print(f"Error scraping Remote.co: {e}")
            return 0

if __name__ == "__main__":
    scraper = RemoteCoScraper()
    scraper.scrape()
    scraper.commit()
    print(f"✅ Saved {scraper.jobs_saved} jobs")
    scraper.close()