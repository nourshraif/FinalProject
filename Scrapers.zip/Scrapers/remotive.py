import requests
from bs4 import BeautifulSoup
from base_scraper import BaseScraper

class RemotiveScraper(BaseScraper):
    def scrape(self):
        """Remotive - Curated remote jobs"""
        print("\n=== Scraping Remotive ===")
        try:
            url = "https://remotive.com/remote-jobs"
            response = requests.get(url, headers=self.headers, timeout=15)
            soup = BeautifulSoup(response.text, "html.parser")
            
            all_links = soup.find_all("a", href=True)
            processed = 0
            seen_urls = set()
            
            for link in all_links:
                href = link.get("href", "")
                if not href.startswith("/remote-jobs/") or href == "/remote-jobs":
                    continue
                
                full_url = "https://remotive.com" + href
                if full_url in seen_urls:
                    continue
                seen_urls.add(full_url)
                
                try:
                    link_text = self.clean_text(link.get_text(strip=True))
                    if len(link_text) < 5:
                        continue
                    
                    parent = link.parent
                    company = "Remotive"
                    if parent:
                        parent_text = parent.get_text(separator="|").split("|")
                        for text in parent_text:
                            cleaned = self.clean_text(text)
                            if self.is_valid_company(cleaned) and cleaned != link_text:
                                company = cleaned
                                break
                    
                    if len(link_text) > 5:
                        self.save_job("remotive", link_text, company, "Remote", None, full_url)
                        processed += 1
                except:
                    continue
            
            print(f"Processed {processed} jobs from Remotive")
            return processed
        except Exception as e:
            print(f"Error scraping Remotive: {e}")
            return 0

if __name__ == "__main__":
    scraper = RemotiveScraper()
    scraper.scrape()
    scraper.commit()
    print(f"✅ Saved {scraper.jobs_saved} jobs")
    scraper.close()