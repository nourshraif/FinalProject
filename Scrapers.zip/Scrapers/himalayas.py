import requests
from bs4 import BeautifulSoup
from base_scraper import BaseScraper

class HimalayasScraper(BaseScraper):
    def scrape(self):
        """Himalayas - Clean, modern remote job board"""
        print("\n=== Scraping Himalayas ===")
        try:
            url = "https://himalayas.app/jobs"
            response = requests.get(url, headers=self.headers, timeout=15)
            soup = BeautifulSoup(response.text, "html.parser")
            
            job_links = soup.find_all("a", href=True)
            processed = 0
            seen_urls = set()
            
            for link in job_links:
                href = link.get("href", "")
                if not href.startswith("/jobs/") or len(href) < 10:
                    continue
                
                full_url = "https://himalayas.app" + href
                if full_url in seen_urls:
                    continue
                seen_urls.add(full_url)
                
                try:
                    title = self.clean_text(link.get_text(strip=True))
                    if len(title) < 5 or len(title) > 150:
                        continue
                    
                    # Find company in parent
                    company = "Himalayas"
                    parent = link.parent
                    if parent:
                        company_elem = parent.find(class_="company") or parent.find("span")
                        if company_elem:
                            comp_text = self.clean_text(company_elem.get_text(strip=True))
                            if self.is_valid_company(comp_text):
                                company = comp_text
                    
                    self.save_job("himalayas", title, company, "Remote", None, full_url)
                    processed += 1
                    
                    if processed >= 50:
                        break
                except:
                    continue
            
            print(f"Processed {processed} jobs from Himalayas")
            return processed
        except Exception as e:
            print(f"Error scraping Himalayas: {e}")
            return 0

if __name__ == "__main__":
    scraper = HimalayasScraper()
    scraper.scrape()
    scraper.commit()
    print(f"✅ Saved {scraper.jobs_saved} jobs")
    scraper.close()