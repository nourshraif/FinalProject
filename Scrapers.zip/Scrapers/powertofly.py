import requests
from bs4 import BeautifulSoup
from base_scraper import BaseScraper

class PowerToFlyScraper(BaseScraper):
    def scrape(self):
        """PowerToFly - Diversity-focused remote jobs"""
        print("\n=== Scraping PowerToFly ===")
        try:
            url = "https://powertofly.com/jobs/"
            response = requests.get(url, headers=self.headers, timeout=15)
            soup = BeautifulSoup(response.text, "html.parser")
            
            job_links = soup.find_all("a", href=True)
            processed = 0
            seen_urls = set()
            
            for link in job_links:
                href = link.get("href", "")
                if "/jobs/" not in href or len(href) < 15:
                    continue
                
                full_url = "https://powertofly.com" + href if href.startswith("/") else href
                if full_url in seen_urls:
                    continue
                seen_urls.add(full_url)
                
                try:
                    title = self.clean_text(link.get_text(strip=True))
                    if len(title) < 5 or len(title) > 200:
                        continue
                    
                    company = "PowerToFly"
                    parent = link.parent
                    if parent:
                        company_elem = parent.find(class_=lambda x: x and "company" in str(x).lower())
                        if company_elem:
                            comp_text = self.clean_text(company_elem.get_text(strip=True))
                            if self.is_valid_company(comp_text):
                                company = comp_text
                    
                    self.save_job("powertofly", title, company, "Remote", None, full_url)
                    processed += 1
                    
                    if processed >= 40:
                        break
                except:
                    continue
            
            print(f"Processed {processed} jobs from PowerToFly")
            return processed
        except Exception as e:
            print(f"Error scraping PowerToFly: {e}")
            return 0

if __name__ == "__main__":
    scraper = PowerToFlyScraper()
    scraper.scrape()
    scraper.commit()
    print(f"✅ Saved {scraper.jobs_saved} jobs")
    scraper.close()