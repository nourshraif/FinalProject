import requests
from bs4 import BeautifulSoup
from base_scraper import BaseScraper

class IndeedScraper(BaseScraper):
    def scrape(self):
        """Indeed - Remote jobs"""
        print("\n=== Scraping Indeed Remote Jobs ===")
        try:
            url = "https://www.indeed.com/jobs?q=remote&l=&remotejob=032b3046-06a3-4876-8dfd-474eb5e7ed11"
            response = requests.get(url, headers=self.headers, timeout=15)
            soup = BeautifulSoup(response.text, "html.parser")
            
            job_cards = soup.find_all(["div", "td"], class_=lambda x: x and "job" in str(x).lower())
            processed = 0
            
            for card in job_cards[:50]:
                try:
                    link = card.find("a", href=True)
                    if not link:
                        continue
                    
                    href = link.get("href", "")
                    if "/rc/clk" in href or "/viewjob" in href or "/pagead" in href:
                        if not href.startswith("http"):
                            href = "https://www.indeed.com" + href
                    else:
                        continue
                    
                    title = self.clean_text(link.get_text(strip=True))
                    if len(title) < 5:
                        title_elem = card.find(["h2", "span"])
                        if title_elem:
                            title = self.clean_text(title_elem.get_text(strip=True))
                    
                    company = "Indeed"
                    company_elem = card.find(class_=lambda x: x and "company" in str(x).lower())
                    if company_elem:
                        comp_text = self.clean_text(company_elem.get_text(strip=True))
                        if self.is_valid_company(comp_text):
                            company = comp_text
                    
                    if len(title) > 5:
                        self.save_job("indeed", title, company, "Remote", None, href)
                        processed += 1
                except:
                    continue
            
            print(f"Processed {processed} jobs from Indeed")
            return processed
        except Exception as e:
            print(f"Error scraping Indeed: {e}")
            return 0

if __name__ == "__main__":
    scraper = IndeedScraper()
    scraper.scrape()
    scraper.commit()
    print(f"✅ Saved {scraper.jobs_saved} jobs")
    scraper.close()