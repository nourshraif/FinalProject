import requests
from bs4 import BeautifulSoup
from base_scraper import BaseScraper

class WeWorkRemotelyScraper(BaseScraper):
    def scrape(self):
        """WeWorkRemotely - One of the largest remote job boards"""
        print("\n=== Scraping WeWorkRemotely ===")
        try:
            url = "https://weworkremotely.com/remote-jobs"
            response = requests.get(url, headers=self.headers, timeout=15)
            soup = BeautifulSoup(response.text, "html.parser")
            
            all_links = soup.find_all("a", href=True)
            processed = 0
            
            for link in all_links:
                href = link.get("href", "")
                if not href.startswith("/remote-jobs/") or "/remote-jobs/search" in href:
                    continue
                
                try:
                    text_parts = [part.strip() for part in link.get_text(separator="\n").split("\n") if part.strip()]
                    cleaned_parts = [self.clean_text(p) for p in text_parts if self.clean_text(p) and len(self.clean_text(p)) > 2]
                    
                    if len(cleaned_parts) < 2:
                        continue
                    
                    title = cleaned_parts[0]
                    company = None
                    for part in cleaned_parts[1:]:
                        if self.is_valid_company(part):
                            company = part
                            break
                    
                    if not company:
                        company = "WeWorkRemotely"
                    
                    skip_titles = ['remote jobs', 'categories', 'companies', 'post a job', 'log in', 'sign up']
                    if any(skip in title.lower() for skip in skip_titles):
                        continue
                    
                    full_url = "https://weworkremotely.com" + href
                    
                    if len(title) > 5 and len(company) > 2:
                        self.save_job("weworkremotely", title, company, "Remote", None, full_url)
                        processed += 1
                except:
                    continue
            
            print(f"Processed {processed} jobs from WeWorkRemotely")
            return processed
        except Exception as e:
            print(f"Error scraping WeWorkRemotely: {e}")
            return 0

if __name__ == "__main__":
    scraper = WeWorkRemotelyScraper()
    scraper.scrape()
    scraper.commit()
    print(f"✅ Saved {scraper.jobs_saved} jobs")
    scraper.close()