import requests
from bs4 import BeautifulSoup
from base_scraper import BaseScraper

class LinkedInScraper(BaseScraper):
    def scrape(self):
        """LinkedIn - Remote jobs (limited scraping, respectful)"""
        print("\n=== Scraping LinkedIn Remote Jobs ===")
        try:
            # LinkedIn f_WT parameter filters for remote jobs
            url = "https://www.linkedin.com/jobs/search?f_WT=2"
            response = requests.get(url, headers=self.headers, timeout=15)
            soup = BeautifulSoup(response.text, "html.parser")
            
            job_cards = soup.find_all(["li", "div"], class_=lambda x: x and "job" in str(x).lower())
            processed = 0
            
            for card in job_cards[:30]:  # Limit to be respectful
                try:
                    link = card.find("a", href=True)
                    if not link or "linkedin.com/jobs" not in link.get("href", ""):
                        continue
                    
                    href = link.get("href", "")
                    
                    title = self.clean_text(link.get_text(strip=True))
                    if len(title) < 5:
                        title_elem = card.find(["h3", "h4"])
                        if title_elem:
                            title = self.clean_text(title_elem.get_text(strip=True))
                    
                    company = "LinkedIn"
                    company_elem = card.find(class_=lambda x: x and "company" in str(x).lower())
                    if company_elem:
                        comp_text = self.clean_text(company_elem.get_text(strip=True))
                        if self.is_valid_company(comp_text):
                            company = comp_text
                    
                    if len(title) > 5 and href:
                        self.save_job("linkedin", title, company, "Remote", None, href)
                        processed += 1
                except:
                    continue
            
            print(f"Processed {processed} jobs from LinkedIn")
            return processed
        except Exception as e:
            print(f"Error scraping LinkedIn: {e}")
            return 0

if __name__ == "__main__":
    scraper = LinkedInScraper()
    scraper.scrape()
    scraper.commit()
    print(f"✅ Saved {scraper.jobs_saved} jobs")
    scraper.close()