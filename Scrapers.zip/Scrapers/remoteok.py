import requests
from base_scraper import BaseScraper

class RemoteOKScraper(BaseScraper):
    def scrape(self):
        """Remote OK API - FREE, reliable"""
        print("\n=== Scraping Remote OK API ===")
        try:
            url = "https://remoteok.com/api"
            response = requests.get(url, headers=self.headers, timeout=15)
            jobs = response.json()[1:101]  # Skip metadata, get 100 jobs
            
            processed = 0
            for job in jobs:
                try:
                    title = job.get('position', '').strip()
                    company = job.get('company', 'Remote OK').strip()
                    location = job.get('location', 'Remote').strip()
                    tags = ', '.join(job.get('tags', [])[:5])
                    url_path = job.get('url', '')
                    job_url = f"https://remoteok.com{url_path}" if url_path else ""
                    
                    if len(title) > 5 and job_url:
                        self.save_job("remoteok_api", title, company, location, tags, job_url)
                        processed += 1
                except:
                    continue
            
            print(f"Processed {processed} jobs from Remote OK API")
            return processed
        except Exception as e:
            print(f"Error scraping Remote OK API: {e}")
            return 0

if __name__ == "__main__":
    scraper = RemoteOKScraper()
    scraper.scrape()
    scraper.commit()
    print(f"✅ Saved {scraper.jobs_saved} jobs")
    scraper.close()