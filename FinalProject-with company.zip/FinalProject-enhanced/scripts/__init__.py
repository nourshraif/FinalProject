"""Entry scripts: scheduled_scraper, setup_vector_tables, integrated_job_matcher_app."""
