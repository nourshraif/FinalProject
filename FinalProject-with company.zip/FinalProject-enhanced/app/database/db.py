# app/database/db.py

import psycopg2
import os
from pathlib import Path

# Load .env from project root (folder containing app/)
if getattr(os, "_db_env_loaded", None) is None:
    try:
        from dotenv import load_dotenv
        root = Path(__file__).resolve().parent.parent.parent
        load_dotenv(root / ".env")
        os._db_env_loaded = True
    except Exception:
        pass


def get_connection():
    """Get database connection."""
    return psycopg2.connect(
        host=os.getenv('DB_HOST', 'localhost'),
        database=os.getenv('DB_NAME', 'jobs_db'),
        user=os.getenv('DB_USER', 'postgres'),
        password=os.getenv('DB_PASSWORD', '202211217nour'),
        port=int(os.getenv('DB_PORT', '5433'))  # 5433 = Docker Postgres
    )


def init_database():
    """Initialize database with required tables."""
    conn = get_connection()
    cur = conn.cursor()
    
    try:
        # Enable pgvector extension (needed for user profile embeddings)
        cur.execute("CREATE EXTENSION IF NOT EXISTS vector;")

        # Create jobs table
        cur.execute("""
            CREATE TABLE IF NOT EXISTS jobs (
                id SERIAL PRIMARY KEY,
                source VARCHAR(50) NOT NULL,
                job_title VARCHAR(255) NOT NULL,
                company VARCHAR(255) NOT NULL,
                location VARCHAR(255),
                description TEXT,
                job_url VARCHAR(500) UNIQUE NOT NULL,
                scraped_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                is_active BOOLEAN DEFAULT TRUE
            );
        """)
        
        # Create indexes
        cur.execute("""
            CREATE INDEX IF NOT EXISTS idx_jobs_source ON jobs(source);
            CREATE INDEX IF NOT EXISTS idx_jobs_scraped_at ON jobs(scraped_at DESC);
            CREATE INDEX IF NOT EXISTS idx_jobs_is_active ON jobs(is_active);
            CREATE INDEX IF NOT EXISTS idx_jobs_url ON jobs(job_url);
            CREATE INDEX IF NOT EXISTS idx_jobs_company ON jobs(company);
        """)
        
        # ── User profiles table (job seekers who uploaded a CV) ──────────────
        cur.execute("""
            CREATE TABLE IF NOT EXISTS user_profiles (
                id SERIAL PRIMARY KEY,
                email VARCHAR(255) UNIQUE NOT NULL,
                full_name VARCHAR(255),
                cv_text TEXT,
                skills TEXT[],                -- array of extracted skill strings
                skills_embedding vector(384), -- sentence-transformer embedding (all-MiniLM-L6-v2 = 384 dims)
                cv_filename VARCHAR(255),
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
        """)

        cur.execute("""
            CREATE INDEX IF NOT EXISTS idx_user_profiles_email
                ON user_profiles(email);
        """)

        # ── Company search log (optional audit trail) ─────────────────────────
        cur.execute("""
            CREATE TABLE IF NOT EXISTS company_searches (
                id SERIAL PRIMARY KEY,
                company_name VARCHAR(255),
                required_skills TEXT[],
                searched_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
        """)

        # Create views for easier querying
        cur.execute("""
            CREATE OR REPLACE VIEW recent_jobs AS
            SELECT 
                id,
                source,
                job_title,
                company,
                location,
                job_url,
                scraped_at,
                created_at
            FROM jobs
            WHERE is_active = TRUE
                AND scraped_at > NOW() - INTERVAL '7 days'
            ORDER BY scraped_at DESC;
        """)
        
        cur.execute("""
            CREATE OR REPLACE VIEW job_statistics AS
            SELECT 
                source,
                COUNT(*) as total_jobs,
                COUNT(CASE WHEN scraped_at > NOW() - INTERVAL '24 hours' THEN 1 END) as jobs_last_24h,
                COUNT(CASE WHEN scraped_at > NOW() - INTERVAL '7 days' THEN 1 END) as jobs_last_week,
                MAX(scraped_at) as last_scraped
            FROM jobs
            WHERE is_active = TRUE
            GROUP BY source
            ORDER BY total_jobs DESC;
        """)
        
        conn.commit()
        print("✅ Database initialized successfully")
        
        # Show current count
        cur.execute("SELECT COUNT(*) FROM jobs")
        count = cur.fetchone()[0]
        print(f"📊 Current jobs in database: {count}")
        
    except Exception as e:
        print(f"❌ Error: {e}")
        conn.rollback()
    finally:
        cur.close()
        conn.close()


if __name__ == "__main__":
    init_database()